<?php
session_start();
require_once './DbHandler.php';

$guestData = $_POST;

if (isset($guestData['type']) && $guestData['type'] == 'saveGuest') {
    $handler = new GuestHandler();
    $status = $handler->saveGuest($guestData);
    if ($status) echo 'success';
    else echo 'fail';
}

if (isset($guestData['type']) && $guestData['type'] == 'login') {

    $handler = new GuestHandler();
    $user = $handler->fetchUser($guestData);
    if ($user) {
        $_SESSION['id'] = $user[0]['id'];
        $_SESSION['status'] = 'loggedin';
        $_SESSION['edit'] = true;
        echo 'success';
    } else {
        $_SESSION['status'] = 'fail';
        echo 'failed';
    }

}

if (isset($guestData['type']) && $guestData['type'] == 'singleUserData') {
    $handler = new GuestHandler();
    $user = $handler->getUserById($guestData['guestId']);
    $user['status'] = 'success';
    echo json_encode($user);
}

function fetchGuests($offset)
{
    $handler = new GuestHandler();
    return $handler->fetchGuests($offset);
}

function getTotal()
{
    $handler = new GuestHandler();
    return $handler->getTotal()[0]['total'];
}