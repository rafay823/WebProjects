<?php

class Connection
{
    protected $config;

    public function __construct()
    {
        $this->config = [
            'host' => '127.0.0.1',
            'user' => 'root',
            'password' => 'root',
        ];
    }
    /**
     * Returns PDO instance.
     *
     * @return PDO
     */
    public function connect()
    {
        try {
            $dbh = new PDO(
                "mysql:host=" . $this->config['host'] . ";dbname=guestbook",
                $this->config['user'],
                $this->config['password']
            );
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        return $dbh;
    }
    /**
     * Closes PDO connection
     *
     * @param [PDO] $instance PDO connection instance
     * 
     * @return void
     */
    public function closeConnection($instance)
    {
        $instance = null;
    }

}