<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Guest Book</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<style>
		li{
			margin-left: 20px;
		}
	</style>
</head>
<body>
<?php

if (isset($_SESSION['id'])) {
	$id = $id = $_SESSION['id'];
} else {
	$id = 0;
}

?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand mb-0 h1" href="#">Guest Book</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="./index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><span class="sr-only">(current)</span> Add</a>
            </li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./edit.php">Edit</a>
						</li>
						<?php 
					if (isset($_SESSION['status']) && $_SESSION['status'] == 'loggedin') {
						?> 
            <li class="nav-item lg">
							<a class="btn btn-primary btn-sm nav-link" href="./logout.php">Logout</a>
            </li>
            <?php 
										} ?>
            </ul>
        </div>
    </nav>
	<div class="container">
		<div class="row">
			<section>
			<div class="alert alert-danger" id='loginFail' role="alert">
                Email already exists in our systems.
			</div>
			<div class="alert alert-success" id='success' role="alert">
                Guest Saved.
			</div>
				<input type="hidden" id="user" value="<?php echo $id ?>">
				<?php if (isset($_SESSION['status']) && $_SESSION['status'] == 'loggedin' && isset($_SESSION['edit'])) {
				unset($_SESSION['edit']);
				$value = 'send';
			} else $value = 'rest'; ?>
				<input type="hidden" id="action" value="<?php echo $value; ?>">
					<form id='saveGuest'>
				  <div class="form-group">
				    <label for="surname">Surname</label>
				    <input type="text" class="form-control" id="surname" placeholder="Enter surname">
				  </div>
				  <div class="form-group">
				    <label for="email">Email address</label>
				    <input type="email" class="form-control" id="email" placeholder="Enter email">
				  </div>
				  <div class="form-group">
				    <label for="title">Title</label>
				    <input type="text" class="form-control" id="title" placeholder="Enter title">
				  </div>
				  <div class="form-group">
				    <label for="password">Password</label>
				    <input type="password" class="form-control" id="password" placeholder="Password">
				  </div>
				  <div class="form-group">
                  <label for="comment">Text Area:</label>
                 <textarea class="form-control" rows="5" id="text"></textarea>
                </div>

				  
								<button type="submit" id='save' class="btn btn-primary">Save</button>
								<input type="reset" class = "btn btn-danger" value="Reset">
                </form>
			</section>
		</div>
	</div>
	<script type="text/javascript" src='./main.js'></script>
	<script type="text/javascript">
		$("body").on('click', '#save', function(){
						$('#loginFail').hide();
						$('#success').hide();
            post(event);
        });
	</script>
	<script>
		$(document).ready(function(){
				$('#loginFail').hide();
				$('#success').hide();
		});
		$(document).ready(function(){
			action = $('#action').val();
			if(action == 'send'){
				id=$('#user').val()
				loadUser(id);
			}
		});
	</script>
</body>
</html>