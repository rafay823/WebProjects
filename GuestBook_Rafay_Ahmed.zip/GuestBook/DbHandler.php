<?php
require_once './Connection.php';

class GuestHandler
{
    public function saveGuest($data)
    {
        $pdo = (new Connection)->connect();
        $q = "INSERT INTO guests(email, password, title, surname, text ) 
            VALUES(:email, :password, :title, :surname, :text)";
        $user = $this->getUserByEmail($data['email']);
        if ($user) {
            return false;
        }
        $query = $pdo->prepare($q);
        $query->bindParam(':email', $data['email']);
        $query->bindParam(':password', $data['password']);
        $query->bindParam(':title', $data['title']);
        $query->bindParam(':surname', $data['surname']);
        $query->bindParam(':text', $data['text']);
        $results = $query->execute();
        return $results;
    }

    public function fetchGuests($offset)
    {
        $pdo = (new Connection)->connect();
        $sql = "SELECT * FROM guests LIMIT 10 OFFSET $offset";
        $query = $pdo->prepare($sql);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function fetchUser($data)
    {
        $pdo = (new Connection)->connect();
        $sql = "SELECT * FROM guests WHERE email=:email AND password=:password";
        $query = $pdo->prepare($sql);
        $query->bindParam(':email', $data['email']);
        $query->bindParam(':password', $data['password']);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUserById($id)
    {
        $pdo = (new Connection)->connect();
        $sql = "SELECT * FROM guests WHERE id=:id";
        $query = $pdo->prepare($sql);
        $query->bindParam(':id', $id);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    public function getUserByEmail($id)
    {
        $pdo = (new Connection)->connect();
        $sql = "SELECT * FROM guests WHERE email=:id";
        $query = $pdo->prepare($sql);
        $query->bindParam(':id', $id);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    public function getTotal()
    {
        $pdo = (new Connection)->connect();
        $sth = $pdo->prepare("select count(*) as total from guests");
        $sth->execute();
        return $sth->fetchAll(PDO::FETCH_ASSOC);
    }
}