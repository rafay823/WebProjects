function post(event) {
    event.preventDefault();
    let surname = $('#surname').val();
    let email = $('#email').val();
    let password = $('#password').val();
    let title = $('#title').val();
    let text = $('#text').val();

    $.ajax({
        type: 'POST',
        url: './Guests.php',
        data: {
            surname: surname,
            email: email,
            password: password,
            title: title,
            text: text,
            type: 'saveGuest',
        },
        success: function (data, status) {
            if (data == 'fail') {
                $('#loginFail').show();
            } else {
                $('#success').show();
                $("#saveGuest")[0].reset();
            }
        }
    });
}

function login(event) {
    event.preventDefault();
    let email = $('#email').val();
    let password = $('#password').val();
    $.ajax({
        type: 'POST',
        url: './Guests.php',
        data: {
            email: email,
            password: password,
            type: 'login',
        },
        success: function (data, status) {
            if (data == 'failed') {
                $('#loginFail').show();
            }
            else {
                window.location.replace("./guest.php");
            }
        }
    });

}

function loadUser(id) {
    $.ajax({
        type: 'POST',
        url: './Guests.php',
        data: {
            guestId: id,
            type: 'singleUserData',
        },
        success: function (data, status) {
            data = JSON.parse(data);
            if (data.status == 'success') {
                $('#email').val(data.email);
                $('#password').val(data.password);
                $('#surname').val(data.surname);
                $('#title').val(data.title);
                $('#text').val(data.text);
            }
        }
    });
}