/**
 * Created by umair on 10-May-16.
 */
$(function () {
    // Toastr options
    toastr.options = {
        "debug": false,
        "newestOnTop": false,
        "positionClass": "toast-top-center",
        "closeButton": true,
        "toastClass": "animated fadeInDown",
    };

    $('body').on('click','#add-new-stud-fields',function(){
        var courses = '<option></option>';
        var managers = '<option></option>';
        var teachers = '<option></option>';
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_all_cmts",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                   $.each( data.courses, function( index, value ){
                        courses += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.managers, function( index, value ){
                        managers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.teachers, function( index, value ){
                        teachers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });    
                } 

                $('#extra-students').append('<div class="row"><div class="form-group col-lg-6"><label>Student Name</label><input type="text" class="form-control" name="student-name[]" required /></div><div class="form-group col-lg-6"><label>Skype ID</label><input type="text" class="form-control" name="student-skype[]" required /></div><div class="form-group col-lg-6"><label>Age</label><input type="text" class="form-control" name="student-age[]" required /></div><div class="form-group col-lg-6"><label>Gender</label><select class="form-control" name="student-gender[]" required="required"><option></option><option value="male">Male</option><option value="female">Female</option></select></div><div class="form-group col-lg-6"><label>Course</label><select class="form-control" name="course[]">'+courses+'</select></div><div class="form-group col-lg-6"><label>Number of Days </label><select class="form-control" name="days[]" required="required"><option></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div><div class="form-group col-lg-6"><label>Manager</label><select class="form-control" name="student-manager[]" required="">'+managers+'</select></div><div class="form-group col-lg-6"><label>Teacher</label><select class="form-control" name="student-teacher[]" required="">'+teachers+'</select></div><div class="form-group col-lg-6"><label>Status</label><select class="form-control" name="status[]" required ="required"><option></option><option value="active">Active</option><option value="deactive">Deactive</option><option value="trial">Trial</option><option value="holiday">On Holiday</option><option value="leaved">Leaved</option></select></div><div class="form-group col-lg-6"><label>Trial Class Remarks</label><textarea class="form-control" name="trial-class-remarks[]"></textarea></div></div>');                 
    
            }    
        });
    });
}); 

$(document).ready(function(){
    $("body").on('click','#go-to-lesson',function (e) { 
        e.preventDefault();
        var book = $(this).attr('data-book');
        var chap = $(this).attr('data-chap');
        var page = $(this).attr('data-page');
        var teacher = $(this).attr('data-teacher-id');
        var student = $(this).attr('data-student-id');
        $('#mydiv').css('display','block');
        $("#frame").attr("src", "https://learnquraan.co.uk/ci/index.php/lesson/slesson?book="+book+"&chapter="+chap+"&page="+page+"&teacher="+teacher+"&student="+student);
    });

    $("body").on('click','#read-book',function (e) { 
        e.preventDefault();
        var book = $(this).attr('data-book');
        $('#readbook').css('display','block');
        $('#readbookframe').css('display','block');
        $("#readbookframe").attr("src", "https://learnquraan.co.uk/ci/index.php/lesson/rlesson?book="+book);
    });

    $('#allunpaid').click(function(e) {
        $('.select_checkbox_to_pay').prop('checked', this.checked);
    });

    $('body').on('click','#pay_all_button_invoice',function(e) {
        $('.select_checkbox_to_pay').prop('checked', this.checked);
    });

    $('body').on('keyup','#complaint-comment',function(e)
    {
        if(e.keyCode == 13)
        {
        var comment = $(this).val();
        var comp_id = $(this).attr('data-complaint-id');
        var comp_name = $('#login-name').val();
        var selector = $('.social-form-'+comp_id);
        var date = new Date().toDateString();;
        var formdata = 'id='+comp_id+'&comment='+comment+'&complaint_name='+comp_name;
            if(comment == "")
            {
                alert("Please write something in comment.");
            }
            else
            {
                selector.before('<div class="social-talk"> \
                                <div class="media social-profile clearfix"> \
                                    <a class="pull-left"> \
                                        <!--<img src="images/a1.jpg" alt="profile-picture"> -->  \
                                    </a> \
                                    <div class="media-body"> \
                                        <span class="font-bold">'+ comp_name +'</span> \
                                        <small class="text-muted">'+ date +'</small> \
                                        <div class="social-content"> \
                                            '+ comment +' \
                                        </div> \
                                    </div></div></div>');
                $(this).val("");

                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/add_complaint_responce",
                    type: "POST",
                    dataType: "json",
                    data: formdata,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            
                        } else if (data.error) {
                        }
                    }    
                });
            }
        }
    });   
});

function closeIFrame(){
    $('#frame').remove();
}

function closeRFrame(){
    //$('#readbookframe').remove();
    $('#readbookframe').css('display','none');
}


$(function () {

    $('#student-classes-history-table').dataTable({
        "columns": [
            { "data": "Date" },
            { "data": "Class Time" },
            { "data": "Student" },
            { "data": "Teacher" },
            { "data": "Course" },
            { "data": "Start Time" },
            { "data": "End Time" },
            { "data": "Duration" },
            { "data": "Status" },
        ],
        "order": [[ 1, "desc" ]]
    });

    $('#classes-table').dataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
        "url": "https://learnquraan.co.uk/ci/index.php/parents/today_classes",
        "type": "POST"},
        "columns": [
            { "data": "Date" },
            { "data": "Student" },
            { "data": "Teacher" },
            { "data": "Course" },
            { "data": "Start Time" },
            { "data": "Duration" },
            { "data": "Status" },
            { "data": "Actions"},
        ],
    });
   
    $('#all-classes-table').dataTable({
        //"processing": true,
        //"serverSide": true,
        "ajax": {
        "url": "https://learnquraan.co.uk/ci/index.php/parents/all_classes",
        "type": "POST"
        },
        "columns": [
            { "data": "Date" },
            { "data": "Class Time" },
            { "data": "Student" },
            { "data": "Teacher" },
            { "data": "Course" },
            { "data": "Lesson" },
            { "data": "Remarks" },
            { "data": "Status" },
        ],
    });

    $('#student_class_history').on('show.bs.modal',function(event){
            //event.preventDefault();
        var button = $(event.relatedTarget);
        var student_id = button.data('id');
        var filters = 'student_id='+student_id;
        $('#student-classes-history-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/parents/classes_history?'+filters).load();
    });

    $('#view_class_remarks').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'class_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/parents/get_class_detail_data",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view_lesson_teach').val(return_data.lesson);
                    $('#view_class_end_remarks').text(return_data.remarks);
                }
            }
        });
    });


    $('#parent-classes-history-filter-btn').on('click',function(e){
        e.preventDefault();
        var student = $('#classes-history-filter-student').val();
        var filters = 'student='+student;
        $('#all-classes-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/parents/all_classes?'+filters).load();
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        $('a[data-toggle="tab"]').removeClass('btn-primary');
        $('a[data-toggle="tab"]').addClass('btn-default');
        $(this).removeClass('btn-default');
        $(this).addClass('btn-primary');
    })

    $('.next').click(function(){
        var nextId = $(this).parents('.tab-pane').next().attr("id");
        $('[href=#'+nextId+']').tab('show');
    })

    $('.prev').click(function(){
        var prevId = $(this).parents('.tab-pane').prev().attr("id");
        $('[href=#'+prevId+']').tab('show');
    })

    $('.submitWizard').click(function(){
        var approve = $(".approveCheck").is(':checked');
            
        // Got to step 1
        $('[href=#step1]').tab('show');

        // Serialize data to post method
        var datastring = $("#simpleForm").serialize();
            
        // Show notification
        swal({
            title: "Thank you!",
            text: "You approved our example form!",
            type: "success"
            });
        });

        $('.clockpicker').clockpicker({autoclose: true});

    });

    
    $('.j_all-parent').click(function(){
        $('.j_all-parent').removeClass('active');
        $(this).addClass('active');
        $(this).closest('body').find('.common-class').removeClass('active');
        var OpenTabDiv = $(this).attr('data-tab');
        $(this).closest('body').find('.'+OpenTabDiv).addClass('active'); 
    });

    $('#pay_checkout_invoice').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'invoice_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/parents/get_invoice_data",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#pay_invoice_id').val(return_data.id);
                    $('#pay_invoice_parent_id').val(return_data.parent_id);
                    $('#pay_invoice_amount').val(return_data.amount);                    
                }
            }
        });
    });

    $('#add-complaint-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/parents/add_complaint",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-complaint-form").trigger('reset');
                        toastr.success(data.success,function(){
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

        $('#select-student-timetable').on('change',function(e){
            e.preventDefault();
            var id = $(this).val();
            $('#show-schedule-table tbody tr:eq(0) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(0) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(0) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(0) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(1) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(1) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(1) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(1) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(2) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(2) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(2) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(2) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(3) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(3) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(3) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(3) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(4) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(4) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(4) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(4) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(5) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(5) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(5) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(5) td:eq(4)').empty();
            $('#show-schedule-table tbody tr:eq(6) td:eq(1)').empty();
            $('#show-schedule-table tbody tr:eq(6) td:eq(2)').empty();
            $('#show-schedule-table tbody tr:eq(6) td:eq(3)').empty();
            $('#show-schedule-table tbody tr:eq(6) td:eq(4)').empty();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/parents/get_student_timetable_data",
                type: "POST",
                dataType: "json",
                data: 'student_id='+id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $.each(data, function( index, value ){
                            if(index == 'monday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(0) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(0) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(0) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(0) td:eq(4)').text(value.cname);
                                }    
                            }else if(index == 'tuesday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(1) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(1) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(1) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(1) td:eq(4)').text(value.cname);
                                }
                            }else if(index == 'wednesday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(2) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(2) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(2) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(2) td:eq(4)').text(value.cname);
                                }
                            }else if(index == 'thursday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(3) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(3) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(3) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(3) td:eq(4)').text(value.cname);
                                }

                            }else if(index == 'friday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(4) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(4) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(4) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(4) td:eq(4)').text(value.cname);
                                }      
                            }else if(index == 'saturday'){
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(5) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(5) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(5) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(5) td:eq(4)').text(value.cname);
                                }              
                            
                            }else{
                                if(value){
                                    $('#show-schedule-table tbody tr:eq(6) td:eq(1)').text(value.tname);
                                    $('#show-schedule-table tbody tr:eq(6) td:eq(2)').text(value.time);
                                    $('#show-schedule-table tbody tr:eq(6) td:eq(3)').text(value.etime);
                                    $('#show-schedule-table tbody tr:eq(6) td:eq(4)').text(value.cname);
                                }     
                            }                        
                        
                    });
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        });


        $("#parent-logout").on('click',function(e) {
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/parents/logout",
            type: "POST",
            dataType: "json",
            success: function(data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = "https://learnquraan.co.uk/ci/index.php/parents";
                    }, 2100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }
        });
    
    $("#clear-teacher-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });
    

    $("#clear-parent-form").on('click',function(e) {
        e.preventDefault();
        $("#add-parent-form").trigger('reset'); //jquery
    });

    $("#clear-country-form").on('click',function(e) {
        e.preventDefault();
        $("#add-country-form").trigger('reset'); //jquery
    });

    $("#clear-shift-form").on('click',function(e) {
        e.preventDefault();
        $("#add-shift-form").trigger('reset'); //jquery
    });


    $("#clear-manager-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });

    $('#change_teacher_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_teacher_id').val(id);              
    });

    $('#change_parent_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_parent_id').val(id);              
    });

    $('#change_manager_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_manager_id').val(id);             
    });

    $('#class_remarks').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#class_id').val(id);
    });

    $('#add_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#record-parent-id').val(id);
    });

});


