/**
 * Created by umair on 10-May-16.
 */
$(function () {
    // Toastr options
    toastr.options = {
        "debug": false,
        "newestOnTop": false,
        "positionClass": "toast-top-center",
        "closeButton": true,
        "toastClass": "animated fadeInDown",
    };

    $('body').on('click','#add-new-stud-fields',function(){
        var courses = '<option></option>';
        var managers = '<option></option>';
        var teachers = '<option></option>';
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_all_cmts",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                   $.each( data.courses, function( index, value ){
                        courses += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.managers, function( index, value ){
                        managers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.teachers, function( index, value ){
                        teachers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });    
                } 

                $('#extra-students').append('<div class="row"><div class="form-group col-lg-6"><label>Student Name</label><input type="text" class="form-control" name="student-name[]" required /></div><div class="form-group col-lg-6"><label>Skype ID</label><input type="text" class="form-control" name="student-skype[]" required /></div><div class="form-group col-lg-6"><label>Age</label><input type="text" class="form-control" name="student-age[]" required /></div><div class="form-group col-lg-6"><label>Gender</label><select class="form-control" name="student-gender[]" required="required"><option></option><option value="male">Male</option><option value="female">Female</option></select></div><div class="form-group col-lg-6"><label>Course</label><select class="form-control" name="course[]">'+courses+'</select></div><div class="form-group col-lg-6"><label>Number of Days </label><select class="form-control" name="days[]" required="required"><option></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div><div class="form-group col-lg-6"><label>Manager</label><select class="form-control" name="student-manager[]" required="">'+managers+'</select></div><div class="form-group col-lg-6"><label>Teacher</label><select class="form-control" name="student-teacher[]" required="">'+teachers+'</select></div><div class="form-group col-lg-6"><label>Status</label><select class="form-control" name="status[]" required ="required"><option></option><option value="active">Active</option><option value="deactive">Deactive</option><option value="trial">Trial</option><option value="holiday">On Holiday</option><option value="leaved">Leaved</option></select></div><div class="form-group col-lg-6"><label>Trial Class Remarks</label><textarea class="form-control" name="trial-class-remarks[]"></textarea></div></div>');                 
    
            }    
        });
    });
});

$(function () {

        /**
         * Flot charts data and options
         */
        var data1 = [ [0, 55], [1, 48], [2, 40], [3, 36], [4, 40], [5, 60], [6, 50], [7, 51] ];
        var data2 = [ [0, 56], [1, 49], [2, 41], [3, 38], [4, 46], [5, 67], [6, 57], [7, 59] ];

        var chartUsersOptions = {
            series: {
                splines: {
                    show: true,
                    tension: 0.4,
                    lineWidth: 1,
                    fill: 0.4
                },
            },
            grid: {
                tickColor: "#f0f0f0",
                borderWidth: 1,
                borderColor: 'f0f0f0',
                color: '#6a6c6f'
            },
            colors: [ "#62cb31", "#efefef"],
        };

        $.plot($("#flot-line-chart"), [data1, data2], chartUsersOptions);

        /**
         * Flot charts 2 data and options
         */
        var chartIncomeData = [
            {
                label: "line",
                data: [ [1, 10], [2, 26], [3, 16], [4, 36], [5, 32], [6, 51] ]
            }
        ];

        var chartIncomeOptions = {
            series: {
                lines: {
                    show: true,
                    lineWidth: 0,
                    fill: true,
                    fillColor: "#64cc34"

                }
            },
            colors: ["#62cb31"],
            grid: {
                show: false
            },
            legend: {
                show: false
            }
        };

        $.plot($("#flot-income-chart"), chartIncomeData, chartIncomeOptions);

        var student_idd = '23';
        $('#manager-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#teacher-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/manager/all_teachers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Teacher Name" },
                { "data": "Email" },
                { "data": "No of Student" },
                { "data": "Shift" },
                { "data": "Gender" },
                { "data": "Skype ID" },
                { "data": "Password" }
            ],
        });

        $('#parent-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/manager/all_parents",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "# of Kids" },
                { "data": "Contact #" },
                { "data": "Manager" },
                { "data": "Email" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Fee" },
                { "data": "Fee Date" },
                { "data": "Actions" }
            ],
        });

        $('#student-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/manager/all_students",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Fathername" },
                { "data": "Country" },
                { "data": "Gender" },
                { "data": "Course" },
                { "data": "Class Records" },
                { "data": "Teacher" },
                { "data": "Manager" },
                { "data": "Actions" }
            ],
        });
        $('#course-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });
        $('#year-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_years",
                "type": "POST"
            },
            "columns": [
                { "data": "No" },
                { "data": "School Year" },
                { "data": "Actions" }
            ],
        });
        $('#shift-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_shifts",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Shift" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Actions" }
            ],
        });
        $('#country-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_countires",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Country" },
                { "data": "Code" },
                { "data": "Currency" },
                { "data": "Actions" }
            ],
        });

        $('#classes-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/manager/today_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
                { "data": "Actions"},
            ],
        });

        $('#all-classes-table').dataTable();


        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('a[data-toggle="tab"]').removeClass('btn-primary');
            $('a[data-toggle="tab"]').addClass('btn-default');
            $(this).removeClass('btn-default');
            $(this).addClass('btn-primary');
        })

        $('.next').click(function(){
            var nextId = $(this).parents('.tab-pane').next().attr("id");
            $('[href=#'+nextId+']').tab('show');
        })

        $('.prev').click(function(){
            var prevId = $(this).parents('.tab-pane').prev().attr("id");
            $('[href=#'+prevId+']').tab('show');
        })

        $('.submitWizard').click(function(){

            var approve = $(".approveCheck").is(':checked');
            
                // Got to step 1
                $('[href=#step1]').tab('show');

                // Serialize data to post method
                var datastring = $("#simpleForm").serialize();
                console.log(datastring);
                // Show notification
                swal({
                    title: "Thank you!",
                    text: "You approved our example form!",
                    type: "success"
                });
        });

        // ClockPicker
        $('.clockpicker').clockpicker({autoclose: true});
        $('.date').datepicker({});
        
    });


$(document).ready(function(){
	$('.j_all-parent').click(function(){
        $('.j_all-parent').removeClass('active');
        $(this).addClass('active');
        $(this).closest('body').find('.common-class').removeClass('active');
        var OpenTabDiv = $(this).attr('data-tab');
        $(this).closest('body').find('.'+OpenTabDiv).addClass('active'); 
    });

    $("#log-btn").on('click',function(e) {
        e.preventDefault();
        var name = $('#username').val();
        var pass = $('#password').val();
        $("#log-btn").val("Processing..........");
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/login",
            type: "POST",
            dataType: "json",
            data: "username="+name+"&pwd="+pass,
            success: function(data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = "https://learnquraan.co.uk/ci/index.php/admin/panel";
                    }, 2100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
                $("#log-btn").val("Login");
            }
        });
    });

    $("#logout").on('click',function(e) {
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/logout",
            type: "POST",
            dataType: "json",
            success: function(data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = "https://learnquraan.co.uk/ci/index.php/manager";
                    }, 2100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }
        });
    });

  
    $('#add-year').on('click',function(e){
        e.preventDefault();
        var name = $('input[name="year"]').val();
        var formdata = 'name='+name;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('input[name="year"]').val('');
                    toastr.success(data.success);
                    $('#year-table').DataTable().ajax.reload();
                    setTimeout(function () {
                        $('a[data-tab="year-list"]').click();
                        }, 1100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('click','.delete-year',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_year",
                    type: "POST",
                    dataType: "json",
                    data: 'year-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#year-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','#class-start',function(){
        var id = $(this).attr('data-id');
        var start_time = new Date(),
        start_time = start_time.getHours()+':'+start_time.getMinutes()+':'+start_time.getSeconds();
        $(this).closest('tr').children('td:eq(5)').text(start_time);
        $(this).closest('tr').children('td:eq(8)').text('Started');
        $(this).attr('id','class-end');
        $(this).text('End');
        $('#teacher-leave').remove();
        $('#student-leave').remove();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/start_class",
            type: "POST",
            dataType: "json",
            data: 'class-id='+id+'&start_time='+start_time,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                }
            }    
        });
        
    });

    $('body').on('click','#teacher-leave,#student-leave',function(){
        var id = $(this).attr('data-id');
        var check = $(this).attr('id');
        var status = '';
        if(check == 'teacher-leave'){
            var status = 'Teacher Leave';
        }else{
            var status = 'Student Leave';
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_leave",
            type: "POST",
            dataType: "json",
            data: 'leave='+status+'&class-id='+id,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('#classes-table').DataTable().ajax.reload();
                    $('#teacher-leave').remove();
                    $('#student-leave').remove();
                    $('#class-start').remove();
                }
            }    
        });
        
    });


    $('body').on('click','#class-end',function(){
        $(this).attr('data-toggle','modal');
        $(this).attr('data-target','#class_remarks');
        var select = $(this);
        var id = $(this).attr('data-id');
        var end_time = new Date(),
        end_time = end_time.getHours()+':'+end_time.getMinutes()+':'+end_time.getSeconds();
        $(this).closest('tr').children('td:eq(6)').text(end_time);
        $(this).closest('tr').children('td:eq(8)').text('Taken');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/end_class",
            type: "POST",
            dataType: "json",
            data: 'class-id='+id+'&end_time='+end_time,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    select.closest('tr').children('td:eq(7)').text(data.duration);
                    //select.remove();
                }
            }    
        });
        
    });

    
    $('#add-new-course').on('click',function(e){
        e.preventDefault();
        var name = $('input[name="course-name"]').val();
        var incharge = $('input[name="course-incharge"]').val();
        var title = $('input[name="course-title"]').val();
        var formdata = "name="+name+"&incharge="+incharge+"&title="+title;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_course",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('input[name="course-name"]').val('');
                    $('input[name="course-incharge"]').val('');
                    $('input[name="course-title"]').val('');
                    toastr.success(data.success);
                    setTimeout(function () {
                        //$('.j_all-parent').removeClass('active');
                        //$('a[data-tab="year-list"]').addClass('active');
                        $('a[data-tab="all-course-tab"]').click();
                    //window.location.href = "http://comparebox.pk/index.php/admin/attribute_set";
                        }, 1100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('.delete-course').click(function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_course",
                    type: "POST",
                    dataType: "json",
                    data: 'course-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-teacher-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });

    $('#add-teacher-form').on('submit',function(e){
        e.preventDefault();
        console.log($( this ).serializeArray());
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_teacher",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-teacher-form").trigger('reset');
                    $('#teacher-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("#clear-parent-form").on('click',function(e) {
        e.preventDefault();
        $("#add-parent-form").trigger('reset'); //jquery
    });

    $('#add-parent-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_parent",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-parent-form").trigger('reset');
                    $('#parent-table').DataTable().ajax.reload();
                    $('#student-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#instant-invoice').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/instant_invoiced",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#instant-invoice").trigger('reset');
                    //$('#parent-table').DataTable().ajax.reload();
                    //$('#student-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("#clear-country-form").on('click',function(e) {
        e.preventDefault();
        $("#add-country-form").trigger('reset'); //jquery
    });

    $('#add-country-form').on('submit',function(e){
        e.preventDefault();
        console.log($( this ).serializeArray());
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_country",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-country-form").trigger('reset');
                    toastr.success(data.success);
                    $('#country-table').DataTable().ajax.reload();

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('click','.delete-country',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_country",
                    type: "POST",
                    dataType: "json",
                    data: 'country-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#country-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-shift-form").on('click',function(e) {
        e.preventDefault();
        $("#add-shift-form").trigger('reset'); //jquery
    });

    $('#add-shift-form').on('submit',function(e){
        e.preventDefault();
        console.log($( this ).serializeArray());
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_shift",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-shift-form").trigger('reset');
                    toastr.success(data.success);
                    $('#shift-table').DataTable().ajax.reload();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('click','.delete-shift',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_shift",
                    type: "POST",
                    dataType: "json",
                    data: 'shift-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#shift-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.delete-student',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_student",
                    type: "POST",
                    dataType: "json",
                    data: 'student-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#student-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.delete-invoice',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_invoice",
                    type: "POST",
                    dataType: "json",
                    data: 'invoice-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#invoices-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {      
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('#edit_invoice').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'invoice_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_invoice_data",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_invoice_id').val(return_data.id);
                    $('#edit_invoice-parent-id').val(return_data.parent_id);
                    $('#edit_invoice-month').val(return_data.month);
                    $('#edit_invoice-year').val(return_data.year);
                    $('#edit_invoice-amount').val(return_data.amount);
                    $('#edit_invoice-due-date').val(return_data.due_date);
                    $('#edit_invoice-status').val(return_data.status);
                }
            }
        });
    });

    $('#update-edit-invoice').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_invoice_id').val();
        var parent_id = $('#edit_invoice-parent-id').val();
        var month = $('#edit_invoice-month').val();
        var year = $('#edit_invoice-year').val();  
        var due_date = $('#edit_invoice-due-date').val();
        var amount = $('#edit_invoice-amount').val();
        var status = $('#edit_invoice-status').val();
        var formdata = 'id='+id+'&parent_id='+parent_id+'&month='+month+'&year='+year+'&due_date='+due_date+'&amount='+amount+'&status='+status;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_invoice",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_invoice').modal('hide');
                        $('#invoices-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_shift').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'shift_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_shift",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_shift_id').val(return_data.id);
                    $('#edit_shift_name').val(return_data.shift);
                    $('#edit_shift_start_time').val(return_data.s_time);
                    $('#edit_shift_end_time').val(return_data.e_time);
                }
            }
        });
    });

    $('#update-edit-shift').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_shift_id').val();
        var name = $('#edit_shift_name').val();
        var s_time = $('#edit_shift_start_time').val();
        var e_time = $('#edit_shift_end_time').val();
        var formdata = 'id='+id+'&name='+name+'&s_time='+s_time+'&e_time='+e_time;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_shift",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_shift').modal('hide');
                        $('#shift-table').DataTable().ajax.reload();
                    });


                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_country').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'country_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_country",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_country_id').val(return_data.id);
                    $('#edit_country_name').val(return_data.name);
                    $('#edit_country_code').val(return_data.code);
                    $('#edit_country_currency').val(return_data.currency);
                }
            }
        });

    });

    $('#update-edit-country').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_country_id').val();
        var name = $('#edit_country_name').val();
        var code = $('#edit_country_code').val();
        var currency = $('#edit_country_currency').val();
        var formdata = 'id='+id+'&name='+name+'&code='+code+'&currency='+currency;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_country",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_country').modal('hide');
                        $('#country-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_year').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'year_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_year_id').val(return_data.id);
                    $('#edit_year_name').val(return_data.year);
                }
            }
        });

    });

    $('#update-edit-year').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_year_id').val();
        var year = $('#edit_year_name').val();
        var formdata = 'id='+id+'&year='+year;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_year').modal('hide');
                        $('#year-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'student_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_student",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_student_id').val(return_data.id);
                    $('#edit_student_name').val(return_data.name);
                    $('#edit_student_age').val(return_data.age);
                    $('#edit_student_skype_id').val(return_data.skype);
                    $('#edit_student_trial_remarks').val(return_data.trial_remarks);
                    $('#edit_student_days').val(return_data.days);
                    $('#edit_student_gender').val(return_data.gender);
                    $('#edit_student_course').val(return_data.course_id);
                    $('#edit_student_teacher').val(return_data.teacher_id);
                    $('#edit_student_manager').val(return_data.manage_id);
                    $('#edit_student_status').val(return_data.status);
                }
            }
        });

    });

    $('#update-edit-student').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_student_id').val();
        var name = $('#edit_student_name').val();
        var skype_id = $('#edit_student_skype_id').val();
        var age = $('#edit_student_age').val();
        var days = $('#edit_student_days').val();
        var gender = $('#edit_student_gender').val();
        var course = $('#edit_student_course').val();
        var teacher = $('#edit_student_teacher').val();
        var manager = $('#edit_student_manager').val();
        var status = $('#edit_student_status').val();
   
        var trial_remarks = $('#edit_student_trial_remarks').val();
        var formdata = 'id='+id+'&name='+name+'&status='+status+'&age='+age+'&skype_id='+skype_id+'&days='+days+'&gender='+gender+'&course_id='+course+'&trial_remarks='+trial_remarks+'&teacher='+teacher+'&manager='+manager;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/update_student",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_student').modal('hide');
                        $('#student-table').DataTable().ajax.reload();

                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });


    $('#add-pstudent').on('submit',function(e){
        e.preventDefault();
        console.log($( this ).serializeArray());
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/add_student",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-shift-form").trigger('reset');
                    toastr.success(data.success,function(){
                        $('#add_student').modal('hide');
                        $('student-table').DataTable().ajax.reload();
                        $('parent-table').DataTable().ajax.reload();
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#edit_teacher').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'teacher_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_teacher",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-teacher-id').val(return_data.id);
                    $('#edit-teacher-name').val(return_data.name);
                    $('#edit-teacher-fname').val(return_data.father_name);
                    $('#edit-teacher-cnic').val(return_data.cnic);
                    $('#edit-teacher-address').val(return_data.address);
                    $('#edit-teacher-landline').val(return_data.landline);
                    $('#edit-teacher-mobile').val(return_data.mobile);
                    $('#edit-teacher-email').val(return_data.email);
                    $('#edit-teacher-shift').val(return_data.shift);
                    $('#edit-teacher-gender').val(return_data.gender);
                    $('#edit-teacher-mat-status').val(return_data.martial_status);
                    $('#edit-teacher-qualification').val(return_data.qualification);
                    $('#edit-teacher-experience').val(return_data.experience);
                    $('#edit-teacher-designation').val(return_data.designation);
                    $('#edit-teacher-skype').val(return_data.skype_id);
                    $('#edit-teacher-salary').val(return_data.salary);
                    $('#edit-teacher-username').val(return_data.user_name);
                    $('#edit-teacher-pass').val(return_data.passwrd);
                    $('#edit-teacher-interremarks').val(return_data.inter_remarks);
                }
            }
        });

    });

    $('#update-edit-teacher').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-teacher-id').val();
        var name = $('#edit-teacher-name').val();
        var fname = $('#edit-teacher-fname').val();
        var cnic = $('#edit-teacher-cnic').val();
        var address = $('#edit-teacher-address').val();
        var landline = $('#edit-teacher-landline').val();
        var mobile = $('#edit-teacher-mobile').val();
        var email = $('#edit-teacher-email').val();
        var shift = $('#edit-teacher-shift').val();
        var gender = $('#edit-teacher-gender').val();
        var matstatus = $('#edit-teacher-mat-status').val();
        var qual = $('#edit-teacher-qualification').val();
        var expert = $('#edit-teacher-experience').val();
        var designation = $('#edit-teacher-designation').val();
        var skype = $('#edit-teacher-skype').val();
        var salary = $('#edit-teacher-salary').val();
        var username = $('#edit-teacher-username').val();
        var pass = $('#edit-teacher-pass').val();
        var interremarks = $('#edit-teacher-interremarks').val();
        
        var formdata = 'id='+id+'&name='+name+'&fname='+fname+'&cnic='+cnic+'&address='+address+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&shift='+shift+'&gender='+gender+'&matstatus='+matstatus+'&qual='+qual+'&expert='+expert+'&designation='+designation+'&skype='+skype+'&salary='+salary+'&username='+username+'&pass='+pass+'&interremarks='+interremarks;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_teacher",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_teacher').modal('hide');
                    });
                    $('#teacher-table').DataTable().ajax.reload();

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    
    $('body').on('click','.delete-teacher',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_teacher",
                    type: "POST",
                    dataType: "json",
                    data: 'teacher-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#teacher-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });


    $('#edit_parent').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'parent_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/get_parent",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-parent-id').val(return_data.id);
                    $('#edit-parent-name').val(return_data.name);
                    $('#edit-parent-telephone').val(return_data.telephone_num);
                    $('#edit-parent-mobile').val(return_data.mobile_num);
                    $('#edit-parent-email').val(return_data.email);
                    $('#edit-parent-skype').val(return_data.sky_id);
                    $('#edit-parent-username').val(return_data.username);
                    $('#edit-parent-fee').val(return_data.fee);
                    $('#edit-parent-fee_currency').val(return_data.fee_currency);
                    $('#edit-parent-fee_date').val(return_data.fee_date);
                    $('#edit-parent-fee_type').val(return_data.fee_type);
                    $('#edit-parent-country').val(return_data.country_id);
                    $('#edit-parent-manager').val(return_data.manage_id);
                    $('#edit-parent-note').val(return_data.notes);
                    $('#edit-parent-timezone').val(return_data.timezone);
                    $('#edit-parent-invoiced').val(return_data.invoiced);
                }
            }
        });

    });

    $('#update-edit-parent').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-parent-id').val();
        var name = $('#edit-parent-name').val();
        var landline = $('#edit-parent-telephone').val();
        var mobile = $('#edit-parent-mobile').val();
        var email = $('#edit-parent-email').val();
        var skype = $('#edit-parent-skype').val();
        var username = $('#edit-parent-username').val();
        var pass = $('#edit-parent-password').val();
        var fee = $('#edit-parent-fee').val();
        var fee_currency = $('#edit-parent-fee_currency').val();
        var fee_date = $('#edit-parent-fee_date').val();
        var fee_type = $('#edit-parent-fee_type').val();
        var country_id = $('#edit-parent-country').val();
        var manager_id = $('#edit-parent-manager').val();
        var note = $('#edit-parent-note').val();
        var timezone = $('#edit-parent-timezone').val();
        var invoiced = $('#edit-parent-invoiced').val();

        var formdata = 'id='+id+'&name='+name+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&note='+note+'&manager_id='+manager_id+'&country_id='+country_id+'&fee='+fee+'&fee_type='+fee_type+'&fee_date='+fee_date+'&skype='+skype+'&fee_currency='+fee_currency+'&username='+username+'&pass='+pass+'&timezone='+timezone+'&invoiced='+invoiced;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/update_parent",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_parent').modal('hide');
                        $('#parent-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('body').on('click','.delete-parent',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_parent",
                    type: "POST",
                    dataType: "json",
                    data: 'parent-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#parent-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('#add-schedule').on('click',function(e){
        e.preventDefault();
        var teacher_id = $('select[name="schedule_teacher_id"]').val();
        var student_id = $('select[name="schedule_student_id"]').val();
        var day = $('select[name="schedule_day"]').val();
        var time = $('select[name="schedule_time"]').val();
        var formdata = 'teacher_id='+teacher_id+'&student_id='+student_id+'&day='+day+'&time='+time;
        console.log(formdata);
        if(teacher_id != '' && student_id != '' && day != '' && time != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/manager/add_schedule",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#add-schedule-form').trigger('reset');
                        $('#add_schedule_modal').modal('hide');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            toastr.error('Please Fill up all the fields');
        }    
    });

    $('#add-class-remarks').on('click',function(e){
        e.preventDefault();
        var class_id = $('input[name="class_id"]').val();
        var lesson_teach = $('input[name="lesson_teach"]').val();
        var Remarks = $('textarea[name="class_remarks"]').val();
        
        var formdata = 'class_id='+class_id+'&lesson='+lesson_teach+'&Remarks='+Remarks;
        if(lesson_teach != '' && Remarks != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/add_class_remarks",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#class_remarks').modal('hide');
                        $('input[name="class_id"]').val('');
                        $('input[name="lesson_teach"]').val('');
                        $('textarea[name="class_remarks"]').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            toastr.error('Please Fill up all the fields');
        }    
    });

    $('#update-teacher-password').on('click',function(e){
        e.preventDefault();
        var new_pass = $('#teacher_new_pass').val();
        var confirm_new_pass = $('#teacher_confirm_new_pass').val();
        var role = 'teacher';
        var id = $('#update_pass_teacher_id').val();
        
        var formdata = 'id='+id+'&role='+role+'&new_pass='+new_pass+'&confirm_new_pass='+confirm_new_pass;
        if(new_pass != confirm_new_pass){
            toastr.error("Password doesn't match");
        }else{
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/manager/update_password",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#change_teacher_password').modal('hide');
                        $('#teacher_new_pass').val('');
                        $('#teacher_confirm_new_pass').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }    
    });


    $('#update-parent-password').on('click',function(e){
        e.preventDefault();
        var new_pass = $('#parent_new_pass').val();
        var confirm_new_pass = $('#parent_confirm_new_pass').val();
        var role = 'parent';
        var id = $('#update_pass_parent_id').val();
        
        var formdata = 'id='+id+'&role='+role+'&new_pass='+new_pass+'&confirm_new_pass='+confirm_new_pass;
        if(new_pass != confirm_new_pass){
            toastr.error("Password doesn't match");
        }else{
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/manager/update_password",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#change_parent_password').modal('hide');
                        $('#parent_new_pass').val('');
                        $('#parent_confirm_new_pass').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }    
    });

    $('#update-parent-status').on('click',function(e){
        e.preventDefault();
        var new_status = $('#parent_new_status').val();
        var id = $('#update_status_parent_id').attr('data-id');
        if(new_status == 'holiday'){
        	var start_date = $('#holiday_start_date').val();
        	var end_date = $('#holiday_end_date').val();
        	var holiday = 'yes';
        	var formdata = 'id='+id+'&status='+new_status+'&holiday='+holiday+'&start_date='+start_date+'&end_date='+end_date;
        }else{
        	var formdata = 'id='+id+'&status='+new_status;
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/update_parent_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if(typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    $('#change_parent_status').modal('hide');
                    $('#parent_new_status').val('');
                }else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        }); 
    });

    $('#update-student-status').on('click',function(e){
        e.preventDefault();
        var new_status = $('#student_new_status').val();
        var id = $('#update_status_student_id').attr('data-id');
        if(new_status == 'holiday'){
        	var start_date = $('#student_holiday_start_date').val();
        	var end_date = $('#student_holiday_end_date').val();
        	var holiday = 'yes';
        	var formdata = 'id='+id+'&status='+new_status+'&holiday='+holiday+'&start_date='+start_date+'&end_date='+end_date;
        }else{
        	var formdata = 'id='+id+'&status='+new_status;
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/update_student_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if(typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    $('#change_student_status').modal('hide');
                    $('#student_new_status').val('');
                }else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        }); 
    });

    $('#parent_new_status').on('change',function(e){
        e.preventDefault();
        var status = $('#parent_new_status').val();
       	if(status == 'holiday'){
       		$('#parent_holiday_start_date').css('display','block');
       		$('#parent_holiday_end_date').css('display','block');
       	}else{
       		$('#parent_holiday_start_date').css('display','none');
       		$('#parent_holiday_end_date').css('display','none');
       	}
    });

    $('#student_new_status').on('change',function(e){
        e.preventDefault();
        var status = $('#student_new_status').val();
       	if(status == 'holiday'){
       		$('#student_holiday_start_date').css('display','block');
       		$('#student_holiday_end_date').css('display','block');
       	}else{
       		$('#student_holiday_start_date').css('display','none');
       		$('#student_holiday_end_date').css('display','none');
       	}
    });


    $('#select-teacher-schedule').on('change',function(e){
        e.preventDefault();
        var teacher_id = $('#select-teacher-schedule').val();
        var formdata = 'teacher_id='+teacher_id;
        $('.filledup').removeClass('table-box');
        $('.filledup').empty();
        $('.filledup').removeClass('filledup');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/get_teacher_schedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $.each(data, function( index, value ){
                      var  timee = value.time.replace(":", "_");
                        timee = timee.replace(' ','_');
                      var select_box = '.'+value.day+'_'+timee; 
                        
                        $(select_box).addClass('table-box');
                        $(select_box).addClass('filledup'); 
                        $('td'+select_box).append('<span id="'+value.id+'" class="close-btn">X</span><p>'+value.name+'</p>');
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });


    $('#select-student-history').on('change',function(e){
        e.preventDefault();
        var student_id = $('#select-student-history').val();
        var formdata = 'student_id='+student_id;
        $('#all-classes-table tbody').empty();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/manager/all_classes",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $.each(data.data, function( index, value ){
                    	console.log(value.Date);  
                        //$(select_box).addClass('table-box');
                        //$(select_box).addClass('filledup'); 
                        $('#all-classes-table tbody').append('<tr><td>'+value.Date+'</td><td>'+value.Class_Time+'</td><td>'+value.Student+'</td><td>'+value.Teacher+'</td><td>'+value.Course+'</td><td>'+value.Start_Time+'</td><td>'+value.End_Time+'</td><td>'+value.Duration+'</td><td>'+value.Status+'</td></tr>');
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".close-btn",function(e) {
        e.preventDefault();
        var id = $(this).attr('id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Schedule!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/manager/delete_schedule",
                    type: "POST",
                    dataType: "json",
                    data: 'schedule-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Schedule has been deleted.", "success");
                            var teacher_id = $('#select-teacher-schedule').val();
                            var formdata = 'teacher_id='+teacher_id;
                            $('.filledup').removeClass('table-box');
                            $('.filledup').empty();
                            $('.filledup').removeClass('filledup');
                            $.ajax({
                                url: "https://learnquraan.co.uk/ci/index.php/manager/get_teacher_schedule",
                                type: "POST",
                                dataType: "json",
                                data: formdata,
                                success: function (data) {
                                    if (typeof(data.error) == "undefined") {
                                        $.each(data, function( index, value ) {
                                          //var select_box = value.day+'_'+;
                                          var  timee = value.time.replace(":", "_");
                                            timee = timee.replace(' ','_');
                                          var select_box = '.'+value.day+'_'+timee; 
                                            
                                            $(select_box).addClass('table-box');
                                            $(select_box).addClass('filledup'); 
                                            $('td'+select_box).append('<span id="'+value.id+'" class="close-btn">X</span><p>'+value.name+'</p>');
                                        });
                                    } else if (data.error) {
                                        toastr.error(data.error);
                                    }
                                }    
                            });
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-manager-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });

    $('#add-manager-form').on('submit',function(e){
        e.preventDefault();
        console.log($( this ).serializeArray());
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_manager",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-manager-form").trigger('reset');
                    toastr.success(data.success);
                    $('#manager-table').DataTable().ajax.reload();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#edit_manager').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var formdata = 'manager_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_manager",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-manager-id').val(return_data.id);
                    $('#edit-manager-name').val(return_data.name);
                    $('#edit-manager-cnic').val(return_data.cnic);
                    $('#edit-manager-address').val(return_data.address);
                    $('#edit-manager-landline').val(return_data.telephone);
                    $('#edit-manager-mobile').val(return_data.mobile);
                    $('#edit-manager-email').val(return_data.email);
                    $('#edit-manager-skype').val(return_data.skype_id);
                    $('#edit-manager-salary').val(return_data.salary_pack);
                    $('#edit-manager-username').val(return_data.username);
                    $('#edit-manager-pass').val(return_data.passwrd);
                }
            }
        });

    });

    $('#change_teacher_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_teacher_id').val(id);              
    });

    $('#change_parent_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_parent_id').val(id);              
    });

    $('#change_parent_status').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_status_parent_id').attr('data-id',id);              
    });

    $('#change_student_status').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_status_student_id').attr('data-id',id);              
    });

    $('#change_manager_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_manager_id').val(id);             
    });


    $('#class_remarks').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#class_id').val(id);
    });


    $('#add_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#add_parent_id').val(id);
    });

    $('body').on('click','.class-reschedule',function(event){
        //var button = $(event.relatedTarget);
        var id = $(this).attr('data-id'); 
        var formdata = 'class_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/class_reschedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(data) {
                if (typeof(data.error) == "undefined"){
                    toastr.success(data.success);
                    $('#classes-table').DataTable().ajax.reload();
                }
            }
        });
    });

    $('#update-edit-manager').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-manager-id').val();
        var name = $('#edit-manager-name').val();
        var cnic = $('#edit-manager-cnic').val();
        var address = $('#edit-manager-address').val();
        var landline = $('#edit-manager-landline').val();
        var mobile = $('#edit-manager-mobile').val();
        var email = $('#edit-manager-email').val();
        var skype = $('#edit-manager-skype').val();
        var salary = $('#edit-manager-salary').val();
        var username = $('#edit-manager-username').val();
        var pass = $('#edit-manager-pass').val();
        
        var formdata = 'id='+id+'&name='+name+'&cnic='+cnic+'&address='+address+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&skype='+skype+'&salary='+salary+'&username='+username+'&pass='+pass;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_manager",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_manager').modal('hide');
                        $('#manager-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#add-student-record').on('click',function(e){
        e.preventDefault();
        var parent_id = $('#record-parent-id').val();
        var name = $('input[name="record-student-name"]').val();
        var skype = $('input[name="record-student-skype"]').val();
        var age = $('input[name="record-student-teacher"]').val();
        var teacher_id = $('select[name="record-student-teacher"]').val();
        var manager_id = $('select[name="record-student-manager"]').val();
        var gender = $('select[name="record-student-gender"]').val();
        var course_id = $('select[name="record-student-course"]').val();
        var days = $('select[name="record-student-days"]').val();
        var fee = $('input[name="record-student-fee"]').val();
        var status = $('select[name="record-student-status"]').val();
        var trial_remarks = $('textarea[name="record-student-trial-class-remarks"]').val();
        
        var formdata = 'parent_id='+parent_id+'&name='+name+'&age='+age+'&teacher_id='+teacher_id+'&manager_id='+manager_id+'&course_id='+course_id+'&days='+days+'&skype='+skype+'&fee='+fee+'&status='+status+'&trial_remarks='+trial_remarks+'&gender='+gender;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_student_record",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#add_student').modal('hide');
                        $('#student-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('body').on('click','.delete-manager',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_manager",
                    type: "POST",
                    dataType: "json",
                    data: 'manager-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#manager-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });


});


