/**
 * Created by umair on 10-May-16.
 */
$(function () {
    // Toastr options
    toastr.options = {
        "debug": false,
        "newestOnTop": false,
        "positionClass": "toast-top-center",
        "closeButton": true,
        "toastClass": "animated fadeInDown",
    };

    //function to initialize select2
    function initializeSelect2(selectElementObj) {
        selectElementObj.select2({
            width: "80%",
            tags: true
        });
    }

    $('body').on('click','#add-new-stud-fields',function(){
        var courses = '<option></option>';
        var managers = '<option></option>';
        var teachers = '<option></option>';
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_all_cmts",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                   $.each( data.courses, function( index, value ){
                        courses += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.managers, function( index, value ){
                        managers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });

                    $.each( data.teachers, function( index, value ){
                        teachers += '<option value="'+value.id+'">'+value.name+'</option>';
                    });    
                } 
                $('#extra-students').append('<div class="row"><div class="form-group col-lg-6"><label>Student Name</label><input type="text" class="form-control" name="student-name[]" required /></div><div class="form-group col-lg-6"><label>Skype ID</label><input type="text" class="form-control" name="student-skype[]" required /></div><div class="form-group col-lg-6"><label>Age</label><input type="text" class="form-control" name="student-age[]" required /></div><div class="form-group col-lg-6"><label>Gender</label><select class="form-control" name="student-gender[]" required="required"><option></option><option value="male">Male</option><option value="female">Female</option></select></div><div class="form-group col-lg-6"><label>Course</label><select class="form-control" name="course[]">'+courses+'</select></div><div class="form-group col-lg-6"><p><strong>Days</strong></p><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="mon-day[]" value="mon"><label for="inlineCheckbox1">Mon</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="tues-day[]" value="tues"><label for="inlineCheckbox1">Tues</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="wed-day[]" value="wed"><label for="inlineCheckbox1">Wed</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="thur-day[]" value="thur"><label for="inlineCheckbox1">Thur</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="fri-day[]" value="fri"><label for="inlineCheckbox1">Fri</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="sat-day[]" value="sat"><label for="inlineCheckbox1">Sat</label></div><div class="checkbox checkbox-inline"><input type="checkbox" id="inlineCheckbox1" name="sun-day[]" value="sat"><label for="inlineCheckbox1">Sun</label></div></div><div class="form-group col-lg-6"><label>Manager</label><select class="form-control" name="student-manager[]" required="">'+managers+'</select></div><div class="form-group col-lg-6"><label>Teacher</label><select class="form-control" name="student-teacher[]" required="">'+teachers+'</select></div><div class="form-group col-lg-6"><label>Status</label><select class="form-control" name="status[]" required ="required"><option></option><option value="active">Active</option><option value="deactive">Deactive</option><option value="trial">Trial</option><option value="holiday">On Holiday</option><option value="leaved">Leaved</option></select></div><div class="form-group col-lg-6"><label>Trial Class Remarks</label><textarea class="form-control" name="trial-class-remarks[]"></textarea></div></div>');
                
            } 
        });
    });
    $('.date').datepicker({});

    $(".js-source-day").select2();
}); 

$(document).ready(function(){
    $("#log-btn").on('click',function(e) {
        e.preventDefault();
        var name = $('#username').val();
        var pass = $('#password').val();
        $("#log-btn").val("Processing..........");
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/login",
            type: "POST",
            dataType: "json",
            data: "username="+name+"&pwd="+pass,
            success: function(data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = "https://learnquraan.co.uk/ci/index.php/admin/panel";
                    }, 2100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
                $("#log-btn").val("Login");
            }
        });
    });

    $("#logout").on('click',function(e) {
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/logout",
            type: "POST",
            dataType: "json",
            success: function(data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = "https://learnquraan.co.uk/ci/index.php/admin";
                    }, 2100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }
        });
    });

    $("#add-new-book-chapter").on('click',function(e) {
        e.preventDefault();
        $('#course-book-form .form-group:eq(-2)').after('<div class="hr-line-dashed"></div> \
                                <div class="form-group"> \
                                    <label class="col-sm-2 control-label">Chapter Name</label> \
                                    <div class="col-sm-5"> \
                                        <input name="book-chapter-name[]" type="text" class="form-control"> \
                                    </div> \
                                </div>');
    });



    $("body").on('click',".btn-delete-query",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/delete_query",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    selector.closest('.hpanel').remove();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click','#update-class-schedule',function(e) {
        e.preventDefault();
        var selector = $(this);
        var ids = $(this).attr('data-student-ids');
        var formdata = 'student_ids='+ids;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_class_from_schedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                $('#classes-table').DataTable().ajax.reload();
            }    
        });
    });

    $("body").on('click',".btn-close-query",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/close_query",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    if(state == 0){
                        selector.removeClass('btn-default');
                        selector.addClass('btn-success');
                    }else{
                        selector.removeClass('btn-success');
                        selector.addClass('btn-default');
                    }
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-done-query",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/done_query",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    selector.removeClass('btn-default');
                    selector.addClass('btn-success');
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-close",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_close_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'  
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });        

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-open",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_open_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });           

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-today",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_today_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });         

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-pending",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_pending_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });         

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-trial",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_trial_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });         

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-done",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_done_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });         

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-show-spam",function(e) {
        e.preventDefault();
        var selector = $('.query-board');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/show_spam_query",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    selector.empty();
                    $.each(data, function( index, value ){
                        var comments_area = '#comments-area-'+value.id;
                        var call_status;
                        var set_email_status;
                        var trial_status;
                        var btnclose;
                        if(value.comments){
                           var comments = jQuery.parseJSON(value.comments); 
                        }
                        if(value.call_status == 1){
                            callstatus = 'btn-success btn-for-call'
                        }else{
                            callstatus = 'btn-default btn-for-call'
                        }
                        if(value.email_status == 1){
                            emailstatus = 'btn-success btn-for-email'
                        }else{
                            emailstatus = 'btn-default btn-for-email'
                        }
                        if(value.trial_status == 1){
                            trialstatus = 'btn-success btn-for-trial'
                        }else{
                            trialstatus = 'btn-default btn-for-trial'
                        }
                        if(value.status == 'close'){
                            btnclose = 'btn-success btn-close-query'
                        }else{
                            btnclose = 'btn-default btn-close-query'
                        }
                        if(value.status == 'done'){
                            btndone = 'btn-success btn-done-query'
                        }else{
                            btndone = 'btn-default btn-done-query'
                        }

                            selector.append('<div class="col-lg-6"><div class="hpanel hgreen"><div class="panel-body"> \
                                        <span class="label label-success pull-right">NEW</span> \
                                        <div class="row"> \
                                            <div class="col-sm-8"> \
                                                <h4><a href="javascript:;">'+value.name+'</a></h4> \
                                                <p class="detail-info"> \
                                                    '+value.message+'</p> \
                                                <div class="row"> \
                                                    <div class="col-sm-4"> \
                                                        <div class="project-label">Email</div> \
                                                        <small>'+value.email+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Phone</div> \
                                                        <small>'+value.phone+'</small> \
                                                    </div> \
                                                    <div class="col-sm-3"> \
                                                        <div class="project-label">Country</div> \
                                                        <small>'+value.country+'</small> \
                                                    </div> \
                                                </div> \
                                            </div> \
                                            <div class="col-sm-4 project-info"> \
                                                <div class="project-action m-t-md"><div class="btn-group pull-right"><button class="btn btn-xs '+btndone+'" data-id="'+value.id+'">Done</button><button class="btn btn-xs '+btnclose+'" data-id="'+value.id+'">Close</button><button class="btn btn-xs btn-default btn-delete-query" data-id="'+value.id+'">Spam</button></div></div><div class="project-action m-t-md m-t-md-top"><div class="btn-group pull-right"><button class="btn btn-xs '+callstatus+'" data-id="'+value.id+'">Call</button><button class="btn btn-xs '+emailstatus+'" data-id="'+ value.id +'">Email</button><button class="btn btn-xs '+trialstatus+'" data-id="'+ value.id +'">Trial</button></div></div></div></div></div><div class="panel-footer"><div id="comments-area-'+value.id+'" class="social-talk-holder"></div><div class="social-form social-form-querry-'+value.id+'"><input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="'+value.id+'"></div></div></div></div>');
                
                            if(comments){
                                $.each(comments, function( index, test ){
                                    
                                    $(comments_area).append('<div class="social-talk"> \
                                            <div class="media social-profile clearfix"> \
                                                <div class="media-body"> \
                                                    <span class="font-bold">'+test.name+'</span> \
                                                    <small class="text-muted">'+test.date+'</small> \
                                                    <div class="social-content">'+test.comments+'</div> \
                                                </div></div></div>');
                                });
                            }
                    });         

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-for-call",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_call_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    if(state == 0){
                        selector.removeClass('btn-default');
                        selector.addClass('btn-success');
                    }else{
                        selector.removeClass('btn-success');
                        selector.addClass('btn-default');
                    }
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-for-email",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_email_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success); 
                    if(state == 0){
                        selector.removeClass('btn-default');
                        selector.addClass('btn-success');
                    }else{
                        selector.removeClass('btn-success');
                        selector.addClass('btn-default');
                    }
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".btn-for-trial",function(e) {
        e.preventDefault();
        var selector = $(this);
        var id = $(this).attr('data-id');
        var state;
        if ( $( this ).hasClass( "btn-success" ) ) {
            state = 1; 
        }else{
            state = 0;
        }
        var formdata = 'id='+id+'&state='+state;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_trial_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    if(state == 0){
                        selector.removeClass('btn-default');
                        selector.addClass('btn-success');
                    }else{
                        selector.removeClass('btn-success');
                        selector.addClass('btn-default');
                    }
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("#add-new-chap-page").on('click',function(e) {
        e.preventDefault();
        var page = parseInt($('#chap-pages-form .form-group:eq(-2) input').val()) + 1;
        id="delete-page-icon"
        $('#chap-pages-form .form-group:eq(-2) #delete-page-icon').css('display','none');
        $('#chap-pages-form .form-group:eq(-2)').after('<div class="hr-line-dashed"></div><div class="form-group"><label class="col-sm-2 control-label">Page #</label><div class="col-sm-1"><input name="chap-page-num[]" type="text" class="form-control" value="'+page+'"></div><label class="col-sm-1 control-label">Page Image</label><div class="col-sm-3"> <input name="chap-page-img[]" type="file" class="form-control"></div><div class="col-sm-1" id="delete-page-icon" ><img src="https://learnquraan.co.uk/ci/public/images/close_button.png" style="width: 30px;"></div>');
    });

  
    $('#add-year').on('click',function(e){
        e.preventDefault();
        var name = $('input[name="year"]').val();
        var formdata = 'name='+name;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('input[name="year"]').val('');
                    toastr.success(data.success);
                    $('#year-table').DataTable().ajax.reload();
                    setTimeout(function () {
                        $('a[data-tab="year-list"]').click();
                        }, 1100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('keyup','#complaint-comment',function(e)
    {
        if(e.keyCode == 13)
        {
        var comment = $(this).val();
        var comp_id = $(this).attr('data-complaint-id');
        var comp_name = $('#login-name').val();
        var selector = $('.social-form-'+comp_id);
        var date = new Date().toDateString();;
        var formdata = 'id='+comp_id+'&comment='+comment+'&complaint_name='+comp_name;
            if(comment == "")
            {
                alert("Please write something in comment.");
            }
            else
            {
                selector.before('<div class="social-talk"> \
                                <div class="media social-profile clearfix"> \
                                    <a class="pull-left"> \
                                        <!--<img src="images/a1.jpg" alt="profile-picture"> -->  \
                                    </a> \
                                    <div class="media-body"> \
                                        <span class="font-bold">'+ comp_name +'</span> \
                                        <small class="text-muted">'+ date +'</small> \
                                        <div class="social-content"> \
                                            '+ comment +' \
                                        </div> \
                                    </div></div></div>');
                $(this).val("");

                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/add_complaint_responce",
                    type: "POST",
                    dataType: "json",
                    data: formdata,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            
                        } else if (data.error) {
                        }
                    }    
                });
            }
        }
    });    

    $('body').on('keyup','#query-comment',function(e)
    {
        if(e.keyCode == 13)
        {
        var comment = $(this).val();
        var query_id = $(this).attr('data-query-id');
        var query_name = $('#login-name').val();
        var selector = $(this).closest('.panel-footer').find('.social-talk-holder');
        var date = new Date().toDateString();;
        var formdata = 'id='+query_id+'&comment='+comment+'&query_name='+query_name;
            if(comment == "")
            {
                alert("Please write something in comment.");
            }
            else
            {
                selector.append('<div class="social-talk"> \
                                <div class="media social-profile clearfix"> \
                                    <a class="pull-left"> \
                                        <!--<img src="images/a1.jpg" alt="profile-picture"> -->  \
                                    </a> \
                                    <div class="media-body"> \
                                        <span class="font-bold">'+ query_name +'</span> \
                                        <small class="text-muted">'+ date +'</small> \
                                        <div class="social-content"> \
                                            '+ comment +' \
                                        </div> \
                                    </div></div></div>');
                $(this).val("");

                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/add_query_responce",
                    type: "POST",
                    dataType: "json",
                    data: formdata,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            
                        } else if (data.error) {
                        }
                    }    
                });
            }
        }
    }); 

    $('body').on('click','.delete-year',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_year",
                    type: "POST",
                    dataType: "json",
                    data: 'year-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#year-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','#class-start',function(){
        var id = $(this).attr('data-id');
        var start_time = new Date(),
        start_time = start_time.getHours()+':'+start_time.getMinutes()+':'+start_time.getSeconds();
        $(this).closest('tr').children('td:eq(5)').text(start_time);
        $(this).closest('tr').children('td:eq(8)').text('Started');
        $(this).attr('id','class-end');
        $(this).text('End');
        $('#teacher-leave').remove();
        $('#student-leave').remove();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/start_class",
            type: "POST",
            dataType: "json",
            data: 'class-id='+id+'&start_time='+start_time,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                }
            }    
        });
        
    });

    $('body').on('click','#teacher-leave,#student-leave',function(){
        var id = $(this).attr('data-id');
        var check = $(this).attr('id');
        var status = '';
        if(check == 'teacher-leave'){
            var status = 'Teacher Leave';
        }else{
            var status = 'Student Leave';
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_leave",
            type: "POST",
            dataType: "json",
            data: 'leave='+status+'&class-id='+id,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('#classes-table').DataTable().ajax.reload();
                    $('#teacher-leave').remove();
                    $('#student-leave').remove();
                    $('#class-start').remove();
                }
            }    
        });
        
    });


    $('body').on('click','#class-end',function(){
        $(this).attr('data-toggle','modal');
        $(this).attr('data-target','#class_remarks');
        var select = $(this);
        var id = $(this).attr('data-id');
        var end_time = new Date(),
        end_time = end_time.getHours()+':'+end_time.getMinutes()+':'+end_time.getSeconds();
        $(this).closest('tr').children('td:eq(6)').text(end_time);
        $(this).closest('tr').children('td:eq(8)').text('Taken');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/end_class",
            type: "POST",
            dataType: "json",
            data: 'class-id='+id+'&end_time='+end_time,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    select.closest('tr').children('td:eq(7)').text(data.duration);
                    //select.remove();
                }
            }    
        });
        
    });

    
    $('#add-new-course').on('click',function(e){
        e.preventDefault();
        var name = $('input[name="course-name"]').val();
        var incharge = $('input[name="course-incharge"]').val();
        var title = $('input[name="course-title"]').val();
        var formdata = "name="+name+"&incharge="+incharge+"&title="+title;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_course",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $('input[name="course-name"]').val('');
                    $('input[name="course-incharge"]').val('');
                    $('input[name="course-title"]').val('');
                    toastr.success(data.success);
                    setTimeout(function () {
                        //$('.j_all-parent').removeClass('active');
                        //$('a[data-tab="year-list"]').addClass('active');
                        $('a[data-tab="all-course-tab"]').click();
                    //window.location.href = "http://comparebox.pk/index.php/admin/attribute_set";
                        }, 1100)
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('.delete-course').click(function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_course",
                    type: "POST",
                    dataType: "json",
                    data: 'course-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-teacher-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });

    $("#clear-teacher-leave-form").on('click',function(e) {
        e.preventDefault();
        $("#teacher-leave-form").trigger('reset'); //jquery
    });


    $('#add-teacher-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_teacher",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-teacher-form").trigger('reset');
                    $('#teacher-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#course-book-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_course_book",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#course-book-form").trigger('reset');
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });


    $('#teacher-leave-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/teacher_leaves",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#teacher-leave-form").trigger('reset');
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("#clear-parent-form").on('click',function(e) {
        e.preventDefault();
        $("#add-parent-form").trigger('reset'); //jquery
    });

    $('#add-parent-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_parent",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-parent-form").trigger('reset');
                    $('#parent-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_parents').load();
                    $('#student-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#parent-filter-btn').on('click',function(e){
        e.preventDefault();
        var country = $('#parent-filter-country').val();
        var manager = $('#parent-filter-manager').val();
        var fdate = $('#parent-filter-fdate').val();
        var ftype = $('#parent-filter-ftype').val();
        var invoice = $('#parent-filter-invoice').val();
        var status = $('#parent-filter-status').val();
        var filters = 'country='+country+'&manager='+manager+'&fdate='+fdate+'&ftype='+ftype+'&invoice='+invoice+'&status='+status;
        $('#parent-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_parents?'+filters).load();
    });

    $('#student-filter-btn').on('click',function(e){
        e.preventDefault();
        var country = $('#student-filter-country').val();
        var manager = $('#student-filter-manager').val();
        var status = $('#student-filter-status').val();
        var teacher = $('#student-filter-teacher').val();
        var parent = '';
        var filters = 'country='+country+'&manager='+manager+'&status='+status+'&teacher='+teacher+'&parent='+parent;
        $('#student-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_students?'+filters).load();
    });

    $('#classes-filter-btn').on('click',function(e){
        e.preventDefault();
        //var manager = $('#classes-filter-manager').val();
        var status = $('#classes-filter-status').val();
        var teacher = $('#classes-filter-teacher').val();
        var filters = 'status='+status+'&teacher='+teacher;
        $('#classes-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/today_classes?'+filters).load();
    });

    $('#classes-history-filter-btn').on('click',function(e){
        e.preventDefault();
        //var manager = $('#classes-filter-manager').val();
        var status = $('#classes-history-filter-status').val();
        var teacher = $('#classes-history-filter-teacher').val();
        var date = $('#historydate').val();
        var filters = 'status='+status+'&teacher='+teacher+'&date='+date;
        $('#all-classes-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_classes?'+filters).load();
    });

    $('#invoices-filter-btn').on('click',function(e){
        e.preventDefault();
        var month = $('#invoices-filter-month').val();
        var manager = $('#invoices-filter-manager').val();
        var year = $('#invoices-filter-year').val();
        var ftype = $('#invoices-filter-ftype').val();
        var status = $('#invoices-filter-status').val();
        var filters = 'month='+month+'&manager='+manager+'&year='+year+'&ftype='+ftype+'&status='+status;
        $('#invoices-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_invoices?'+filters).load();
    });

    $('body').on('click','a#teacher-students',function(e){
        e.preventDefault();
        var country = '';
        var manager = '';
        var status = '';
        var teacher = $(this).attr('data-id');  
        var parent = '';
        var filters = 'country='+country+'&manager='+manager+'&status='+status+'&teacher='+teacher+'&parent='+parent;
        $('#student-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_students?'+filters).load();
        $('a[data-tab="all-student-tab"]').click();
    });

    $('body').on('click','a#parent-students',function(e){
        e.preventDefault();
        var country = '';
        var manager = '';
        var status = '';
        var teacher = '';
        var parent = $(this).attr('data-id');
        var filters = 'country='+country+'&manager='+manager+'&status='+status+'&teacher='+teacher+'&parent='+parent;
        $('#student-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_students?'+filters).load();
        $('a[data-tab="all-student-tab"]').click();
    });

    $('body').on('click','span#v_p_fee',function(e){
        e.preventDefault();
        var month = '';
        var manager = '';
        var year = '';
        var ftype = '';
        var status = '';
        var parent = $(this).attr('data-id');
        var filters = 'month='+month+'&manager='+manager+'&year='+year+'&ftype='+ftype+'&status='+status+'&parent='+parent;
        $('#invoices-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_invoices?'+filters).load();
        $('a[data-tab="all-invoices-tab"]').click();
    });

    $('body').on('click','a#students-classes',function(e){
        e.preventDefault();
        var student = $(this).attr('data-id');
        var filters = 'student='+student;
        $('#all-classes-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/Admin/all_classes?'+filters).load();
        $('a[data-tab="all-classes"]').click();
    });


    $('#instant-invoice').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/instant_invoiced",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#instant-invoice").trigger('reset');
                    //$('#parent-table').DataTable().ajax.reload();
                    //$('#student-table').DataTable().ajax.reload();
                    toastr.success(data.success);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("#clear-country-form").on('click',function(e) {
        e.preventDefault();
        $("#add-country-form").trigger('reset'); //jquery
    });

    $('#add-country-form').on('submit',function(e){
        e.preventDefault();
        
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_country",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-country-form").trigger('reset');
                    toastr.success(data.success);
                    $('#country-table').DataTable().ajax.reload();

                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('click','.delete-country',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_country",
                    type: "POST",
                    dataType: "json",
                    data: 'country-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#country-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-shift-form").on('click',function(e) {
        e.preventDefault();
        $("#add-shift-form").trigger('reset'); //jquery
    });

    $('#add-shift-form').on('submit',function(e){
        e.preventDefault();
        
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_shift",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-shift-form").trigger('reset');
                    toastr.success(data.success);
                    $('#shift-table').DataTable().ajax.reload();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('body').on('click','.delete-shift',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_shift",
                    type: "POST",
                    dataType: "json",
                    data: 'shift-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#shift-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.delete-student',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_student",
                    type: "POST",
                    dataType: "json",
                    data: 'student-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#student-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.delete-book',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_book",
                    type: "POST",
                    dataType: "json",
                    data: 'book-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#all-course-book-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.delete-invoice',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_invoice",
                    type: "POST",
                    dataType: "json",
                    data: 'invoice-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#invoices-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {      
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('body').on('click','.remind-invoice',function (event) {
        event.preventDefault();
        var id = $(this).attr('data-id');
        var formdata = 'invoice_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/invoice_reminder",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_invoice').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'invoice_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_invoice_data",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_invoice_id').val(return_data.id);
                    $('#edit_invoice-parent-id').val(return_data.parent_id);
                    $('#edit_invoice-month').val(return_data.month);
                    $('#edit_invoice-year').val(return_data.year);
                    $('#edit_invoice-amount').val(return_data.amount);
                    $('#edit_invoice-adjustment').val(return_data.adjustment);
                    $('#edit_invoice-due-date').val(return_data.due_date);
                    $('#edit_invoice-status').val(return_data.status);
                    console.log(return_data.adjustment);
                }
            }  
        });
    });

    $('#view_class_remarks').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'class_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_class_detail_data",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view_lesson_teach').val(return_data.lesson);
                    $('#view_class_end_remarks').text(return_data.remarks);
                }
            }
        });
    });

    $('#update-edit-invoice').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_invoice_id').val();
        var due_date = $('#edit_invoice-due-date').val();
        var adjustment = $('#edit_invoice-adjustment').val();
        var status = $('#edit_invoice-status').val();
        var formdata = 'id='+id+'&due_date='+due_date+'&adjustment='+adjustment+'&status='+status;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_invoice",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_invoice').modal('hide');
                        $('#invoices-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_shift').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'shift_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_shift",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_shift_id').val(return_data.id);
                    $('#edit_shift_name').val(return_data.shift);
                    $('#edit_shift_start_time').val(return_data.s_time);
                    $('#edit_shift_end_time').val(return_data.e_time);
                }
            }
        });
    });

    $('#update-edit-shift').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_shift_id').val();
        var name = $('#edit_shift_name').val();
        var s_time = $('#edit_shift_start_time').val();
        var e_time = $('#edit_shift_end_time').val();
        var formdata = 'id='+id+'&name='+name+'&s_time='+s_time+'&e_time='+e_time;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_shift",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_shift').modal('hide');
                        $('#shift-table').DataTable().ajax.reload();
                    });


                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_country').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'country_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_country",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_country_id').val(return_data.id);
                    $('#edit_country_name').val(return_data.name);
                    $('#edit_country_code').val(return_data.code);
                    $('#edit_country_currency').val(return_data.currency);
                }
            }
        });

    });

    $('#update-edit-country').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_country_id').val();
        var name = $('#edit_country_name').val();
        var code = $('#edit_country_code').val();
        var currency = $('#edit_country_currency').val();
        var formdata = 'id='+id+'&name='+name+'&code='+code+'&currency='+currency;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_country",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_country').modal('hide');
                        $('#country-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_year').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'year_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_year_id').val(return_data.id);
                    $('#edit_year_name').val(return_data.year);
                }
            }
        });

    });

    $('#update-edit-year').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_year_id').val();
        var year = $('#edit_year_name').val();
        var formdata = 'id='+id+'&year='+year;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_year",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_year').modal('hide');
                        $('#year-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#edit_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'student_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_student",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit_student_id').val(return_data.id);
                    $('#edit_student_name').val(return_data.name);
                    $('#edit_student_age').val(return_data.age);
                    $('#edit_student_fee').val(return_data.fees);
                    $('#edit_student_skype_id').val(return_data.skype);
                    $('#edit_student_trial_remarks').val(return_data.trial_remarks);
                    $('#edit_student_days').val(return_data.days);
                    $('#edit_student_gender').val(return_data.gender);
                    $('#edit_student_manager').val(return_data.manage_id);
                    $('#edit_student_teacher').val(return_data.teacher_id);
                    $('#edit_student_course').val(return_data.coursee_id);
                    $('#edit_student_status').val(return_data.status);
                    var days = return_data.days.split(',');
                    $.each( days , function( index , value ){
                        console.log(value);
                        $('input#editstudentdays[value="'+value+'"]').prop('checked', true);
                        //$('#editstudent').val("'"+value+"'").prop('checked', true)
                    })
                }
            }
        });
    });

    $('#view_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'student_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_student",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view-student-name').text(return_data.name);
                    $('#view-student-age').text(return_data.age);
                    $('#view-student-fee').text(return_data.fees);
                    $('#view-student-skype').text(return_data.skype);
                    $('#view-student-trial-class').text(return_data.trial_remarks);
                    $('#view-student-days').text(return_data.days);
                    $('#view-student-gender').text(return_data.gender);
                    $('#view-student-course').text(return_data.course_id);
                    $('#view-student-status').text(return_data.status);
                }
            }
        });
    });

    $('#update-edit-student').on('click',function(e){
        e.preventDefault();
        var id = $('#edit_student_id').val();
        var name = $('#edit_student_name').val();
        var skype_id = $('#edit_student_skype_id').val();
        var age = $('#edit_student_age').val();
        var days = $('#edit_student_days').val();
        var days = ['mon','tues','wed','thur','fri','sat','sun'];
        var final_days = [];
        $.each( days , function( index , value ){
            day_check = $('input#editstudentdays[value="'+value+'"]').prop('checked');
            if(day_check){
                final_days.push(value);
            }
        })
        var gender = $('#edit_student_gender').val();
        var course = $('#edit_student_course').val();
        var title = $('#edit_student_title').val();
        var manager = $('#edit_student_manager').val();
        var teacher = $('#edit_student_teacher').val();
        var status = $('#edit_student_status').val();
        var trial_remarks = $('#edit_student_trial_remarks').val();
        var formdata = 'id='+id+'&name='+name+'&age='+age+'&skype_id='+skype_id+'&days='+final_days.toString()+'&gender='+gender+'&course_id='+course+'&trial_remarks='+trial_remarks+'&manager='+manager+'&teacher='+teacher+'&status='+status;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_student",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_student').modal('hide');
                        $('#student-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });


    $('#add-pstudent').on('submit',function(e){
        e.preventDefault();
        
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_student",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-shift-form").trigger('reset');
                    toastr.success(data.success,function(){
                        $('#add_student').modal('hide');
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#edit_teacher').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'teacher_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_teacher",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-teacher-id').val(return_data.id);
                    $('#edit-teacher-name').val(return_data.name);
                    $('#edit-teacher-fname').val(return_data.father_name);
                    $('#edit-teacher-cnic').val(return_data.cnic);
                    $('#edit-teacher-address').val(return_data.address);
                    $('#edit-teacher-landline').val(return_data.landline);
                    $('#edit-teacher-mobile').val(return_data.mobile);
                    $('#edit-teacher-email').val(return_data.email);
                    $('#edit-teacher-shift').val(return_data.shift_id);
                    $('#edit-teacher-gender').val(return_data.gender);
                    $('#edit-teacher-mat-status').val(return_data.martial_status);
                    $('#edit-teacher-qualification').val(return_data.qualification);
                    $('#edit-teacher-experience').val(return_data.experience);
                    $('#edit-teacher-designation').val(return_data.designation);
                    $('#edit-teacher-skype').val(return_data.skype_id);
                    $('#edit-teacher-skype-passwrd').val(return_data.skype_passwrd)
                    $('#edit-teacher-salary').val(return_data.salary);
                    $('#edit-teacher-username').val(return_data.user_name);
                    $('#edit-teacher-pass').val(return_data.passwrd);
                    $('#edit-teacher-interremarks').val(return_data.inter_remarks);
                }
            }
        });
    });


    $('#view_teacher').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'teacher_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_teacher",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view-teacher-name').text(return_data.name);
                    $('#view-teacher-fname').text(return_data.father_name);
                    $('#view-teacher-cnic').text(return_data.cnic);
                    $('#view-teacher-address').text(return_data.address);
                    $('#view-teacher-telephone').text(return_data.landline);
                    $('#view-teacher-mobile').text(return_data.mobile);
                    $('#view-teacher-email').text(return_data.email);
                    $('#view-teacher-shift').text(return_data.shift_id);
                    $('#view-teacher-gender').text(return_data.gender);
                    $('#view-teacher-mstatus').text(return_data.martial_status);
                    $('#view-teacher-qual').text(return_data.qualification);
                    $('#view-teacher-exper').text(return_data.experience);
                    $('#view-teacher-design').text(return_data.designation);
                    $('#view-teacher-skype').text(return_data.skype_id);
                    $('#view-teacher-skypass').text(return_data.skype_passwrd)
                    $('#view-teacher-salpack').text(return_data.salary);
                    $('#view-teacher-username').text(return_data.user_name);
                    $('#view-teacher-intermarks').text(return_data.inter_remarks);
                }
            }
        });
    });

    $('#change_student_status').on('show.bs.modal',function(event){
        //event.preventDefault();
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'student_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_student_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#student_new_status').val(return_data.status);
                }
            }
        });
    });

    $('#update-edit-teacher').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-teacher-id').val();
        var name = $('#edit-teacher-name').val();
        var fname = $('#edit-teacher-fname').val();
        var cnic = $('#edit-teacher-cnic').val();
        var address = $('#edit-teacher-address').val();
        var landline = $('#edit-teacher-landline').val();
        var mobile = $('#edit-teacher-mobile').val();
        var email = $('#edit-teacher-email').val();
        var shift = $('#edit-teacher-shift').val();
        var gender = $('#edit-teacher-gender').val();
        var matstatus = $('#edit-teacher-mat-status').val();
        var qual = $('#edit-teacher-qualification').val();
        var expert = $('#edit-teacher-experience').val();
        var designation = $('#edit-teacher-designation').val();
        var skype = $('#edit-teacher-skype').val();
        var skype_pass = $('#edit-teacher-skype-passwrd').val();
        var salary = $('#edit-teacher-salary').val();
        var username = $('#edit-teacher-username').val();
        var pass = $('#edit-teacher-pass').val();
        var interremarks = $('#edit-teacher-interremarks').val();
        
        var formdata = 'id='+id+'&name='+name+'&fname='+fname+'&cnic='+cnic+'&address='+address+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&shift='+shift+'&gender='+gender+'&matstatus='+matstatus+'&qual='+qual+'&expert='+expert+'&designation='+designation+'&skype='+skype+'&skype_pass='+skype_pass+'&salary='+salary+'&username='+username+'&pass='+pass+'&interremarks='+interremarks;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_teacher",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_teacher').modal('hide');
                    });
                    $('#teacher-table').DataTable().ajax.reload();

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    
    $('body').on('click','.delete-teacher',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_teacher",
                    type: "POST",
                    dataType: "json",
                    data: 'teacher-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#teacher-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });


    $('#edit_parent').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var edit = 1;
        var formdata = 'parent_id='+id+'&edit_parent='+edit;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_parent",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-parent-id').val(return_data.id);
                    $('#edit-parent-name').val(return_data.name);
                    $('#edit-parent-telephone').val(return_data.telephone_num);
                    $('#edit-parent-mobile').val(return_data.mobile_num);
                    $('#edit-parent-email').val(return_data.email);
                    $('#edit-parent-skype').val(return_data.sky_id);
                    $('#edit-parent-username').val(return_data.username);
                    $('#edit-parent-password').val(return_data.passwrd);
                    $('#edit-parent-fee').val(return_data.fee);
                    $('#edit-parent-fee_currency').val(return_data.fee_currency);
                    $('#edit-parent-fee_date').val(return_data.fee_date);
                    $('#edit-parent-fee_type').val(return_data.fee_type);
                    $('#edit-parent-country').val(return_data.country_id);
                    $('#edit-parent-manager').val(return_data.manage_id);
                    $('#edit-parent-note').val(return_data.notes);
                    $('#edit-parent-timezone').val(return_data.timezone);
                    $('#edit-parent-invoiced').val(return_data.invoiced);
                }
            }
        });

    });

    $('#edit_book').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'book_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_book",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-book-id').val(return_data.id);
                    $('#edit-book-name').val(return_data.book_name);
                    $('#edit-book-course').val(return_data.course_id);
                }
            }
        });

    });

    $('#update-edit-book').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-book-id').val();
        var name = $('#edit-book-name').val();
        var course = $('#edit-book-course').val();
        var formdata = 'id='+id+'&name='+name+'&course='+course;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_course_book",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_book').modal('hide');
                        $('#all-course-book-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#view_parent').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var formdata = 'parent_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_parent",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view-parent-name').text(return_data.name);
                    $('#view-parent-telephone').text(return_data.telephone_num);
                    $('#view-parent-mobile').text(return_data.mobile_num);
                    $('#view-parent-email').text(return_data.email);
                    $('#view-parent-skype').text(return_data.sky_id);
                    $('#view-parent-username').text(return_data.username);
                    $('#view-parent-password').text(return_data.passwrd);
                    $('#view-parent-fee').text(return_data.fee);
                    $('#view-parent-fee_currency').text(return_data.fee_currency);
                    $('#view-parent-fee_date').text(return_data.fee_date);
                    $('#view-parent-fee_type').text(return_data.fee_type);
                    $('#view-parent-country').text(return_data.country_id);
                    $('#view-parent-manager').text(return_data.manage_id);
                    $('#view-parent-note').text(return_data.notes);
                    $('#view-parent-timezone').text(return_data.timezone);
                    $('#view-parent-invoiced').text(return_data.invoiced);
                }
            }
        });

    });

    $('#update-edit-parent').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-parent-id').val();
        var name = $('#edit-parent-name').val();
        var landline = $('#edit-parent-telephone').val();
        var mobile = $('#edit-parent-mobile').val();
        var email = $('#edit-parent-email').val();
        var skype = $('#edit-parent-skype').val();
        var username = $('#edit-parent-username').val();
        var fee = $('#edit-parent-fee').val();
        var fee_currency = $('#edit-parent-fee_currency').val();
        var fee_date = $('#edit-parent-fee_date').val();
        var fee_type = $('#edit-parent-fee_type').val();
        var country_id = $('#edit-parent-country').val();
        var manager_id = $('#edit-parent-manager').val();
        var note = $('#edit-parent-note').val();
        var timezone = $('#edit-parent-timezone').val();
        var invoiced = $('#edit-parent-invoiced').val();

        var formdata = 'id='+id+'&name='+name+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&note='+note+'&manager_id='+manager_id+'&country_id='+country_id+'&fee='+fee+'&fee_type='+fee_type+'&fee_date='+fee_date+'&skype='+skype+'&fee_currency='+fee_currency+'&username='+username+'&timezone='+timezone+'&invoiced='+invoiced;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_parent",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_parent').modal('hide');
                        $('#parent-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('body').on('click','.delete-parent',function () {
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_parent",
                    type: "POST",
                    dataType: "json",
                    data: 'parent-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#parent-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $('#add-schedule').on('click',function(e){
        e.preventDefault();
        var teacher_id = $('select[name="teacher_id"]').val();
        var student_id = $('select[name="student_id"]').val();
        var day = $('select[name="day"]').val();
        var time = $('select[name="time"]').val();
        //var student_zone = $('select[name="student_zone"]').val();
        //var course = $('select[name="course"]').val();
        //var formdata = 'teacher_id='+teacher_id+'&student_id='+student_id+'&day='+day+'&time='+time+'&student_zone='+student_zone+'&course_id='+course;
        var formdata = 'teacher_id='+teacher_id+'&student_id='+student_id+'&day='+day+'&time='+time;
        if(teacher_id != '' && student_id != '' && day != '' && time != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/add_schedule",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#add-schedule-form').trigger('reset');
                        $('#add_schedule_modal').modal('hide');
                        $('.js-source-day').val(' ').trigger('change');
                        $('#schedule-student-id').prop('disabled', true);
                        $('#schedule-day').prop('disabled', true);
                        $('#schedule-time').prop('disabled', true);
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            toastr.error('Please Fill up all the fields');
        }    
    });

    $('#add-class-remarks').on('click',function(e){
        e.preventDefault();
        var class_id = $('input[name="class_id"]').val();
        var lesson_teach = $('input[name="lesson_teach"]').val();
        var Remarks = $('textarea[name="class_remarks"]').val();
        
        var formdata = 'class_id='+class_id+'&lesson='+lesson_teach+'&Remarks='+Remarks;
        if(lesson_teach != '' && Remarks != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/add_class_remarks",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#class_remarks').modal('hide');
                        $('input[name="class_id"]').val('');
                        $('input[name="lesson_teach"]').val('');
                        $('textarea[name="class_remarks"]').val('');
                        $('#class-end').remove();
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            toastr.error('Please Fill up all the fields');
        }    
    });

    $('#update-teacher-password').on('click',function(e){
        e.preventDefault();
        var new_pass = $('#teacher_new_pass').val();
        var confirm_new_pass = $('#teacher_confirm_new_pass').val();
        var role = 'teacher';
        var id = $('#update_pass_teacher_id').val();
        
        var formdata = 'id='+id+'&role='+role+'&new_pass='+new_pass+'&confirm_new_pass='+confirm_new_pass;
        if(new_pass != confirm_new_pass){
            toastr.error("Password doesn't match");
        }else{
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/update_password",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#change_teacher_password').modal('hide');
                        $('#teacher_new_pass').val('');
                        $('#teacher_confirm_new_pass').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }    
    });


    $('#update-parent-password').on('click',function(e){
        e.preventDefault();
        var new_pass = $('#parent_new_pass').val();
        var confirm_new_pass = $('#parent_confirm_new_pass').val();
        var role = 'parent';
        var id = $('#update_pass_parent_id').val();
        
        var formdata = 'id='+id+'&role='+role+'&new_pass='+new_pass+'&confirm_new_pass='+confirm_new_pass;
        if(new_pass != confirm_new_pass){
            toastr.error("Password doesn't match");
        }else{
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/update_password",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#change_parent_password').modal('hide');
                        $('#parent_new_pass').val('');
                        $('#parent_confirm_new_pass').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }    
    });



    $('#update-manager-password').on('click',function(e){
        e.preventDefault();
        var new_pass = $('#manager_new_pass').val();
        var confirm_new_pass = $('#manager_confirm_new_pass').val();
        var role = 'manager';
        var id = $('#update_pass_manager_id').val();
        
        var formdata = 'id='+id+'&role='+role+'&new_pass='+new_pass+'&confirm_new_pass='+confirm_new_pass;
        if(new_pass != confirm_new_pass){
            toastr.error("Password doesn't match");
        }else{
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/update_password",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#change_manager_password').modal('hide');
                        $('#manager_new_pass').val('');
                        $('#manager_confirm_new_pass').val('');
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }    
    });

    $('#change_parent_status').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_status_parent_id').attr('data-id',id);              
    });

    $('#change_student_status').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var parentid = button.data('parent-id');
        $('#update_status_student_id').attr('value',id); 
        $('#update_status_parent_id').attr('value',parentid);             
    });

    $('#update-parent-status').on('click',function(e){
        e.preventDefault();
        var new_status = $('#parent_new_status').val();
        var id = $('#update_status_parent_id').attr('data-id');
        if(new_status == 'holiday'){
            var start_date = $('#holiday_start_date').val();
            var end_date = $('#holiday_end_date').val();
            var holiday = 'yes';
            var formdata = 'id='+id+'&status='+new_status+'&holiday='+holiday+'&start_date='+start_date+'&end_date='+end_date;
        }else{
            var formdata = 'id='+id+'&status='+new_status;
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_parent_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if(typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    $('#change_parent_status').modal('hide');
                    $('#parent_new_status').val('');
                }else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        }); 
    });

    $('#update-student-status').on('click',function(e){
        e.preventDefault();
        var new_status = $('#student_new_status').val();
        var id = $('#update_status_student_id').val();
        var parent_id = $('#update_status_parent_id').val();
        if(new_status == 'holiday'){
            var start_date = $('#student_holiday_start_date').val();
            var end_date = $('#student_holiday_end_date').val();
            var holiday = 'yes';
            var formdata = 'id='+id+'&status='+new_status+'&holiday='+holiday+'&start_date='+start_date+'&end_date='+end_date+'&parent_id='+parent_id;
        }else{
            var formdata = 'id='+id+'&status='+new_status+'&parent_id='+parent_id;
        }
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_student_status",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if(typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    $('#change_student_status').modal('hide');
                    $('#student_new_status').val('');
                    $('#student_holiday_start_date').val(' ');
                    $('#student_holiday_end_date').val(' ');
                }else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        }); 
    });

    $('#parent_new_status').on('change',function(e){
        e.preventDefault();
        var status = $('#parent_new_status').val();
        if(status == 'holiday'){
            $('#parent_holiday_start_date').css('display','block');
            $('#parent_holiday_end_date').css('display','block');
        }else{
            $('#parent_holiday_start_date').css('display','none');
            $('#parent_holiday_end_date').css('display','none');
        }
    });

    $('#teacher-schedule-name').on('change',function(e){
        e.preventDefault();
        var teacher_id = $('#teacher-schedule-name').val();
        var formdata = 'teacher_id='+teacher_id;
        if(teacher_id != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/get_student_by_teacher",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('#schedule-student-id').removeAttr('disabled');
                        $('#schedule-student-id').empty();
                        $('#schedule-student-id').append('<option></option>');
                        $.each(data, function( index, value ){
                            $('#schedule-student-id').append('<option value="'+value.id+'" >'+value.name+'</option>');
                        });
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            }); 
        }
    });

    $('#schedule-student-id').on('change',function(e){
        e.preventDefault();
        var student_id = $('#schedule-student-id').val();
        var formdata = 'student_id='+student_id;
        if(student_id != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/get_student_days",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('#schedule-day').removeAttr('disabled');
                        $('#schedule-time').removeAttr('disabled');
                        $('#schedule-day').empty();
                        $('#schedule-day').append('<option></option>');
                        $.each(data, function(key,value){
                            $('#schedule-day').append('<option value="'+key+'" >'+value+'</option>');
                        });  
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            }); 
        }
    });


    $('#student_new_status').on('change',function(e){
        e.preventDefault();
        var status = $('#student_new_status').val();
        if(status == 'holiday'){
            $('#student_holiday_start_date').css('display','block');
            $('#student_holiday_end_date').css('display','block');
        }else{
            $('#student_holiday_start_date').css('display','none');
            $('#student_holiday_end_date').css('display','none');
        }
    });

    $('#send-to').on('change',function(e){
        e.preventDefault();
        var send_to = $('#send-to').val();
        var url = '';
        if(send_to == 'manager'){
            url = 'https://learnquraan.co.uk/ci/index.php/admin/get_all_managers';
        }
        else if(send_to == 'teacher'){
            url = 'https://learnquraan.co.uk/ci/index.php/admin/get_all_teachers';

        }else if(send_to == 'parent'){
            url = 'https://learnquraan.co.uk/ci/index.php/admin/get_all_parents';
        }
        if(url){
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('#edit-message-receiver').empty();
                        $('#edit-message-receiver').append('<option></option>');
                        $.each(data, function( index, value ){
                            $('#edit-message-receiver').append('<option value="'+value.id+'" >'+value.Name+'</option>');
                        });
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }
    });

    $('select[name="chapter-book-course-id"]').on('change',function(e){
        e.preventDefault();
        var course_id = $('select[name="chapter-book-course-id"]').val();
        var formdata = 'course_id='+course_id;
        if(course_id != ''){
            $.ajax({
                url: 'https://learnquraan.co.uk/ci/index.php/admin/get_course_books',
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('select[name="chapter-book-name"]').removeAttr('disabled');
                        $('select[name="chapter-book-name"]').empty();
                        $('select[name="chapter-name"]').attr("disabled",'disabled');
                        $('select[name="chapter-name"]').empty();
                        $('select[name="chapter-book-name"]').append('<option></option>');
                        $.each(data, function( index, value ){
                            $('select[name="chapter-book-name"]').append('<option value="'+value.id+'" >'+value.Name+'</option>');
                        });
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            $('select[name="chapter-book-name"]').attr("disabled",'disabled');
            $('select[name="chapter-book-name"]').empty();
            $('select[name="chapter-book-name"]').append('<option></option>');

            $('select[name="chapter-name"]').attr("disabled",'disabled');
            $('select[name="chapter-name"]').empty();
            $('select[name="chapter-name"]').append('<option></option>');
        }
    });

    $('select[name="chapter-book-name"]').on('change',function(e){
        e.preventDefault();
        var book_id = $('select[name="chapter-book-name"]').val();
        var course_id = $('select[name="chapter-book-course-id"]').val();
        var formdata = 'course_id='+course_id+'&book_id='+book_id;
        if(book_id != '' &&  course_id != ''){
            $.ajax({
                url: 'https://learnquraan.co.uk/ci/index.php/admin/get_all_chapters',
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('select[name="chapter-name"]').removeAttr('disabled');
                        $('select[name="chapter-name"]').empty();
                        $('select[name="chapter-name"]').append('<option></option>');
                        $.each(data, function( index, value ){
                            $('select[name="chapter-name"]').append('<option value="'+value.id+'" >'+value.Name+'</option>');
                        });
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }
    });


    $('select[name="chapter-name"]').on('change',function(e){
        e.preventDefault();
        $('#add-new-chap-page').removeAttr('disabled');
        $('input[name="chap-page-img[]"]').removeAttr('disabled');
        $('input[name="chap-page-num[]"]').removeAttr('disabled');
        $('#add-chap-page-btn').removeAttr('disabled');
        var chap_id = $('select[name="chapter-name"]').val();
        var formdata ='chap_id='+chap_id;
        $.ajax({
                url: 'https://learnquraan.co.uk/ci/index.php/admin/get_chap_page_num',
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        $('input[name="chap-page-num[]"]').val(data.page);
                    }else if (data.error) {          
                }
            }    
        });
    });

    $('#send-message').on('click',function(e){
        e.preventDefault();
        var send_to = $('#send-to').val();
        var receiver_id = $('#edit-message-receiver').val();
        var message = $('#message-to-send').val();
        var formdata = 'send_to='+send_to+'&receiver_id='+receiver_id+'&message='+message;
        if(receiver_id != '' && message != '' ){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/send_message",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if(typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#send_message').modal('hide');
                        $("#send-message-form").trigger('reset')
                    }else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }     
    });


    $('#select-teacher-schedule').on('change',function(e){
        e.preventDefault();
        var teacher_id = $('#select-teacher-schedule').val();
        var formdata = 'teacher_id='+teacher_id;
        $('.filledup').removeClass('table-box');
        $('.filledup').empty();
        $('.filledup').removeClass('filledup');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_teacher_schedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $.each(data, function( index, value ){
                      var  timee = value.time.replace(":", "_");
                        timee = timee.replace(' ','_');
                      var select_box = '.'+value.day+'_'+timee; 
                    
                        $(select_box).addClass('table-box');
                        $(select_box).addClass('filledup'); 
                        $('td'+select_box).append('<span id="'+value.id+'" class="close-btn">X</span><p>'+value.name+'</p>');
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $("body").on('click',".close-btn",function(e) {
        e.preventDefault();
        var id = $(this).attr('id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Schedule!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_schedule",
                    type: "POST",
                    dataType: "json",
                    data: 'schedule-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Schedule has been deleted.", "success");
                            var teacher_id = $('#select-teacher-schedule').val();
                            var formdata = 'teacher_id='+teacher_id;
                            $('.filledup').removeClass('table-box');
                            $('.filledup').empty();
                            $('.filledup').removeClass('filledup');
                            $.ajax({
                                url: "https://learnquraan.co.uk/ci/index.php/admin/get_teacher_schedule",
                                type: "POST",
                                dataType: "json",
                                data: formdata,
                                success: function (data) {
                                    if (typeof(data.error) == "undefined") {
                                        $.each(data, function( index, value ) {
                                          //var select_box = value.day+'_'+;
                                          var  timee = value.time.replace(":", "_");
                                            timee = timee.replace(' ','_');
                                          var select_box = '.'+value.day+'_'+timee; 
                                            
                                            $(select_box).addClass('table-box');
                                            $(select_box).addClass('filledup'); 
                                            $('td'+select_box).append('<span id="'+value.id+'" class="close-btn">X</span><p>'+value.name+'</p>');
                                        });
                                    } else if (data.error) {
                                        toastr.error(data.error);
                                    }
                                }    
                            });
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });

    $("#clear-manager-form").on('click',function(e) {
        e.preventDefault();
        $("#add-teacher-form").trigger('reset'); //jquery
    });

    $('#add-manager-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_manager",
            type: "POST",
            dataType: "json",
            data: $( this ).serializeArray(),
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $("#add-manager-form").trigger('reset');
                    toastr.success(data.success);
                    $('#manager-table').DataTable().ajax.reload();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#chap-pages-form').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/upload_chap_page",
            type: "POST",
            dataType: "json",
            data: new FormData(this),
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false, 
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success);
                    $("#chap-pages-form").trigger('reset');
                    location.reload();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });

    $('#edit_manager').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var formdata = 'manager_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_manager",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#edit-manager-id').val(return_data.id);
                    $('#edit-manager-name').val(return_data.name);
                    $('#edit-manager-cnic').val(return_data.cnic);
                    $('#edit-manager-address').val(return_data.address);
                    $('#edit-manager-landline').val(return_data.telephone);
                    $('#edit-manager-mobile').val(return_data.mobile);
                    $('#edit-manager-email').val(return_data.email);
                    $('#edit-manager-skype').val(return_data.skype_id);
                    $('#edit-manager-salary').val(return_data.salary_pack);
                    $('#edit-manager-shift').val(return_data.shift_id);
                    $('#edit-manager-username').val(return_data.username);
                    $('#edit-manager-pass').val(return_data.passwrd);
                }
            }
        });

    });

    $('#show_schedule').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var formdata = 'student_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_detail_student_schedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#show_student_schedule_table').empty();
                    $.each(return_data, function( index, value ){
                        $('#show_student_schedule_table').append('<tr><td>'+value.day+'</td><td>'+value.time+'</td></tr>');
                    });

                }
            }
        });

    });


    $('#view_manager').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var formdata = 'manager_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/get_manager",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(return_data) {
                if (typeof(return_data.error) == "undefined"){
                    $('#view-manager-name').text(return_data.name);
                    $('#view-manager-cnic').text(return_data.cnic);
                    $('#view-manager-address').text(return_data.address);
                    $('#view-manager-tele').text(return_data.telephone);
                    $('#view-manager-mobile').text(return_data.mobile);
                    $('#view-manager-email').text(return_data.email);
                    $('#view-manager-skype').text(return_data.skype_id);
                    $('#view-manager-spack').text(return_data.salary_pack);
                    $('#view-manager-username').text(return_data.username);
                }
            }
        });

    });
    $('#change_teacher_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_teacher_id').val(id);              
    });

    $('#change_parent_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_parent_id').val(id);              
    });

    $('#change_manager_password').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#update_pass_manager_id').val(id);             
    });


    $('#class_remarks').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#class_id').val(id);
    });

    $('#class_teacher_assign').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#assign_teacher_class_id').attr('value',id);
    });

    $('#assign-teacher').on('click',function(e){
        e.preventDefault();
        var class_id = $('#assign_teacher_class_id').val();
        var teacher_id = $('#class-assign-teacher').val();
        
        var formdata = 'class_id='+class_id+'&teacher_id='+teacher_id;
        if(teacher_id != ''){
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/admin/assign_class_teacher",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        $('#class_teacher_assign').modal('hide');
                        $('#classes-table').DataTable().ajax.reload();
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }    
            });
        }else{
            toastr.error('Please Fill up all the fields');
        }    
    });


    $('#add_student').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#record-parent-id').val(id);
    });

    $('body').on('click','.class-validate',function(event){
        //var button = $(event.relatedTarget);
        var id = $(this).attr('data-id'); 
        var formdata = 'class_id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/class_validate",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(data) {
                if (typeof(data.error) == "undefined"){
                    toastr.success(data.success);
                    $('#classes-table').DataTable().ajax.reload();
                }
            }
        });
    });

    $('body').on('click','.class-student-approve',function(event){
        //var button = $(event.relatedTarget);
        var id = $(this).attr('data-id'); 
        var status = 'Student Leave';
        var formdata = 'leave='+status+'&class-id='+id;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/set_leave",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(data) {
                if (typeof(data.error) == "undefined"){
                    toastr.success(data.success);
                    $('.class-student-approve').remove();
                    $('.class-validate').remove();
                    $('#classes-table').DataTable().ajax.reload();
                }
            }
        });
    });

    $('#class_reschedule').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        $('#class_reschedule_id').attr('value',id);
        console.log(id);
    });

    $('#add-class-reschedule').on('click',function(event){
        event.preventDefault();
        var id = $('#class_reschedule_id').val(); 
        var date = $('#class_reschedule_date').val(); 
        var time = $('.class_reschedule_clockpicker').val(); 
        var formdata = 'class_id='+id+'&date='+date+'&time='+time;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/class_reschedule",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function(data) {
                if (typeof(data.error) == "undefined"){
                    toastr.success(data.success);
                    $('#class_reschedule').modal('hide');
                    $('#classes-table').DataTable().ajax.reload();
                }
            }
        });
    });

    $('#update-edit-manager').on('click',function(e){
        e.preventDefault();
        var id = $('#edit-manager-id').val();
        var name = $('#edit-manager-name').val();
        var cnic = $('#edit-manager-cnic').val();
        var address = $('#edit-manager-address').val();
        var landline = $('#edit-manager-landline').val();
        var mobile = $('#edit-manager-mobile').val();
        var email = $('#edit-manager-email').val();
        var skype = $('#edit-manager-skype').val();
        var salary = $('#edit-manager-salary').val();
        var shift = $('#edit-manager-shift').val();
        var username = $('#edit-manager-username').val();
        var pass = $('#edit-manager-pass').val();
        var formdata = 'id='+id+'&name='+name+'&cnic='+cnic+'&address='+address+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&skype='+skype+'&salary='+salary+'&username='+username+'&pass='+pass+'&shift='+shift;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/update_manager",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#edit_manager').modal('hide');
                        $('#manager-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('#add-student-record').on('click',function(e){
        e.preventDefault();
        var parent_id = $('#record-parent-id').val();
        var name = $('input[name="record-student-name"]').val();
        var skype = $('input[name="record-student-skype"]').val();
        var age = $('input[name="record-student-teacher"]').val();
        var teacher_id = $('select[name="record-student-teacher"]').val();
        var manager_id = $('select[name="record-student-manager"]').val();
        var gender = $('select[name="record-student-gender"]').val();
        var course_id = $('select[name="record-student-course"]').val();
        var days = $('select[name="record-student-days"]').val();
        var fee = $('input[name="record-student-fee"]').val();
        var status = $('select[name="record-student-status"]').val();
        var trial_remarks = $('textarea[name="record-student-trial-class-remarks"]').val();
        
        var formdata = 'parent_id='+parent_id+'&name='+name+'&age='+age+'&teacher_id='+teacher_id+'&manager_id='+manager_id+'&course_id='+course_id+'&days='+days+'&skype='+skype+'&fee='+fee+'&status='+status+'&trial_remarks='+trial_remarks+'&gender='+gender;
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/admin/add_student_record",
            type: "POST",
            dataType: "json",
            data: formdata,
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    toastr.success(data.success,function(){
                        $('#add_student').modal('hide');
                        $('#student-table').DataTable().ajax.reload();
                    });

                } else if(data.error) {
                    toastr.error(data.error);   
                }
            }
        });
    });

    $('body').on('click','.delete-manager',function(){
        var id = $(this).attr('data-id');
        swal({
            title: "Are you sure?",
            text: "Your will not be able to recover this Record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel plx!",
            closeOnConfirm: false,
            closeOnCancel: false },
            function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/delete_manager",
                    type: "POST",
                    dataType: "json",
                    data: 'manager-id='+id,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            swal("Deleted!", "Your Record has been deleted.", "success");
                            $('#manager-table').DataTable().ajax.reload();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            } else {
                            
                swal("Cancelled", "Your Record is safe :)", "error");
            }
        });
    });


});


