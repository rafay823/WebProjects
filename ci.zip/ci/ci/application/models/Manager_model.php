<?php
class Manager_model extends CI_Model
{
	public function __construct()
	{
	$this->load->database();
	}
	 
	
	// Save a new year. 
	function save_year($year_data) {
		$this->db->insert('year' , $year_data); 
		return $this->db->insert_id();
	}

	function get_all_years() {
		$this->db->from('year');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function check_login($username,$password) {
		$this->db->from('managers');
		$this->db->where('username',$username);
		$this->db->where('passwrd',$password);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
		
	}

	function delete_year($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('year'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_course($data) {
		$this->db->insert('courses' , $data); 
		return $this->db->insert_id();
	}

	function get_all_courses() {
		$this->db->from('courses');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_course($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('courses'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_teacher($data) {
		$this->db->insert('teachers' , $data); 
		return $this->db->insert_id();
	}

	function get_all_teachers() {
		$this->db->from('teachers');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_today_schedule($day) {
		$this->db->from('schedule');
		$this->db->where('day',$day);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_messages($manager_id) {
		$this->db->from('messages');
		$this->db->where('receiver_title','manager');
		$this->db->where('receiver_id',$manager_id);
		$this->db->order_by("id","asc");
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_today_classes($day,$date) {
		$this->db->from('classes');
		$this->db->where('day',$day);
		$this->db->where('t_date',$date);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_all_classes($student_id) {
		$this->db->from('classes');
		$this->db->where('student_id',$student_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_teacher($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('teachers'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}


	function save_country($data) {
		$this->db->insert('countries' , $data); 
		return $this->db->insert_id();
	}

	function get_all_countries() {
		$this->db->from('countries');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_country($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('countries'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function schedule_check($student_id,$teacher_id,$time,$day)
	{
		$this->db->from('schedule');
		$this->db->where('teacher_id',$teacher_id);
		$this->db->where('student_id',$student_id);
		$this->db->where('time',$time);
		$this->db->where('day',$day);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	function save_shift($data) {
		$this->db->insert('shifts' , $data); 
		return $this->db->insert_id();
	}

	function get_all_shifts() {
		$this->db->from('shifts');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_shift($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('shifts'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_parent($data) {
		$this->db->insert('parent' , $data); 
		return $this->db->insert_id();
	}

	function get_all_parents() {
		$this->db->from('parent');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_parent($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('parent'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function get_parent($id)
	{
		$this->db->from('parent');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function save_student($data) {
		$this->db->insert('students' , $data); 
		return $this->db->insert_id();
	}

	function save_class($data) {
		$this->db->insert('classes' , $data); 
		return $this->db->insert_id();
	}

	function get_all_students() {
		$this->db->from('students');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_teacher_schedule($teacher_id) {
		$this->db->select('students.name,schedule.*');
		$this->db->from('schedule');
		$this->db->join('students', 'schedule.student_id = students.id');
		$this->db->where('schedule.teacher_id',$teacher_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_course($couser_id) {
		$this->db->select('name');
		$this->db->from('courses');
		$this->db->where('id',$couser_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_course_id($student_id) {
		$this->db->select('course_id');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_name($student_id) {
		$this->db->select('name');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}
	function get_student_manager($manager_id) {
		$this->db->select('name');
		$this->db->from('managers');
		$this->db->where('id',$manager_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_kids_count($parent_id) {
		$this->db->from('students');
		$this->db->where('parent_id',$parent_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_student_teacher($teacher_id) {
		$this->db->select('name');
		$this->db->from('teachers');
		$this->db->where('id',$teacher_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_country($parent_id) {
		$this->db->select('countries.code');
		$this->db->from('countries');
		$this->db->join('parent', 'parent.country_id = countries.id');
		$this->db->where('parent.id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_fname($parent_id) {
		$this->db->select('parent.name');
		$this->db->from('parent');
		$this->db->join('students', 'students.parent_id = parent.id');
		$this->db->where('students.parent_id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_classrecords($student_id) {
		$this->db->from('classes');
		$this->db->where('student_id',$student_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function delete_student($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('students'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}
	
	function get_shift($id)
	{
		$this->db->from('shifts');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_shift($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('shifts', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_class($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('classes', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_class_times($id)
	{
		$this->db->select('start_time,end_time');
		$this->db->from('classes');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_country($id)
	{
		$this->db->from('countries');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_country($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('countries', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_year($id)
	{
		$this->db->from('year');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_year($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('year', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_student($id)
	{
		$this->db->from('students');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_student($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('students', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_teacher($id)
	{
		$this->db->from('teachers');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_manager($id)
	{
		$this->db->from('managers');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_teacher($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('teachers', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_parent($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('parent', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

    
    function all_industry()
	{
		$this->db->from('Industries');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_filters()
	{
		$this->db->from('cat_filters');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_sub_cat()
	{
		$this->db->from('sub_industry');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_sub_industry()
	{
		$this->db->from('sub_industry');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_sub_cats($parent_id)
	{
		$this->db->from('sub_industry');
		$this->db->where('parent_cat_id',$parent_id);	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_attr_filter($indus_id)
	{
		$this->db->select('attribute.*');
		$this->db->from('attribute');	
		$this->db->where('attribute_set_name.cat_id', $indus_id);
		$this->db->join('attribute_set_name', 'attribute_set_name.id = attribute.set_id');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_retailers()
	{
		$this->db->from('featured_retailer');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function add_attribute_Set($data)
	{
		$this->db->insert('attribute_set_name',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function all_attribute_set()
	{
		$this->db->from('attribute_set_name');
		$query = $this->db->get();
		return ($query->result_array());
	}
    
    function check_industry($name)
	{
		$this->db->select('name');
        $this->db->from('Industries');	
        $this->db->where('name',$name);
		$query = $this->db->get();
		if($query->num_rows() > 0){
		  return true;
          }else{
            return false;
          }
	}

	function check_attribute_set_name($name)
	{
		$this->db->select('set_name');
		$this->db->from('attribute_set_name');
		$this->db->where('set_name',$name);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

    function delete_industry($id)
	{
        $this->db->where('id', $id);
       $query =  $this->db->delete('Industries'); 
		if($query){
		  return true;
		}else{
		  return false;
		}
	}

	function delete_sub_cat($id)
	{
        $this->db->where('id', $id);
       $query =  $this->db->delete('sub_industry'); 
		if($query){
		  return true;
		}else{
		  return false;
		}
	}

	function check_cat_name($name)
	{	
		$this->db->from('Industries');
        $this->db->where('name', $name);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}

	function check_sub_cat_name($name)
	{
		$this->db->from('sub_industry');
        $this->db->where('name', $name);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  	return true;
		}else{
		  	return false;
		}
	}

	function delete_attribute_set($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('attribute_set_name');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function get_attribute_set($id)
	{
		$this->db->from('attribute_set_name');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}



	function add_attribute($data)
	{
		$this->db->insert('attribute',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function all_attribute()
	{
		$this->db->from('attribute');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_attribute($id)
	{
		$this->db->from('attribute');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

    function get_attributes($id)
    {
        $this->db->select('name');
        $this->db->from('attribute');
        $this->db->where('set_id',$id);
        $query = $this->db->get();
        return ($query->result_array());
    }

	function check_attribute($name)
	{
		$this->db->select('name');
		$this->db->from('attribute');
		$this->db->where('name',$name);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	function attribute_set_name($id)
	{
		$this->db->select('set_name');
		$this->db->from('attribute_set_name');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return ($query->row());
		}else{
			return false;
		}
	}

	function update_attribute_set($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('attribute_set_name', $data);
		//$this->db->last_query();
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}


	function delete_attribute($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('attribute');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function update_attribute($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('attribute', $data);
		//$this->db->last_query();
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_product($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('products', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function set_featured_product($id,$featured)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('products', $featured);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function set_featured_retailer($id,$featured)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('featured_retailer', $featured);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function set_edit_retailer($id,$featured)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('featured_retailer', $featured);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function set_approved_product($id,$approved)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('products_reviews', $approved);
		//$this->db->last_query();
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}


	function add_product($data)
	{
		$this->db->insert('products',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}
    
     function all_products()
	{
		$this->db->from('products');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_products_reviews()
	{
		$this->db->select('products_reviews.*,products.name');
		$this->db->from('products_reviews');
		$this->db->join('products', 'products.id = products_reviews.product_id');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_product($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('products');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function delete_product_review($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('products_reviews');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function add_brand($data)
	{
		$this->db->insert('brands',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}
    
	function add_poll($data)
	{
		$this->db->insert('polls',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function add_user($data)
	{
		$this->db->insert('users',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function add_user_role($data)
	{
		$this->db->insert('user_roles',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}


	function add_filter($data)
	{
		$this->db->insert('cat_filters',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function all_polls()
	{
		$this->db->from('polls');	
		$query = $this->db->get();
		return ($query->result_array());
	}

    function all_brands()
	{
		$this->db->from('brands');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function all_users()
	{
		$this->db->from('users');	
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_brands($id)
	{
		$this->db->select('id,name');
		$this->db->from('brands');
		$this->db->where('indus_id',$id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function update_brand_no_image($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('brands', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_brand_logo($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('brands', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_user($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('users', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_brand($id)
	{
		$this->db->from('brands');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_product($id)
	{
		$this->db->from('products');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}


	function delete_advert($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('brands');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function delete_user($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('users');
		if($query){
			return true;
		}else{
			return false;
		}
	}
 


	function delete_poll($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('polls');
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function brand_name($id)
	{
		$this->db->select('name');
		$this->db->from('brands');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return ($query->row());
		}else{
			return false;
		}
	}

	function check_brand($name)
	{
		$this->db->select('name');
		$this->db->from('brands');
		$this->db->where('name',$name);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
    
    function add_slider($data)
	{
		$this->db->insert('banner_slider',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}
    
    function all_slider()
	{
		$this->db->from('banner_slider');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_slider($id)
	{
		$this->db->where('id', $id);
		$query =  $this->db->delete('banner_slider');
		if($query){
			return true;
		}else{
			return false;
		}
	}


	function add_sub_cat($data)
	{
		$this->db->insert('sub_industry',$data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function update_sub_cat($id,$data)
	{
		$this->db->where('id', $id);
		$this->db->update('sub_industry', $data);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		return false;
	}

	function parent_cat_name($id)
	{
		$this->db->select('name');
		$this->db->from('Industries');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return ($query->row());
		}else{
			return false;
		}
	}


	function sub_cat_name($id)
	{
		$this->db->select('name');
		$this->db->from('sub_industry');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return ($query->row());
		}else{
			return false;
		}
	}

	function get_sub_cat($id)
	{
		$this->db->from('sub_industry');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function save_schedule($data) {
		$this->db->insert('schedule' , $data); 
		return $this->db->insert_id();
	}

	function save_holiday($data) {
		$this->db->insert('holidays' , $data); 
		return $this->db->insert_id();
	}


	function delete_schedule($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('schedule'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_manager($data) {
		$this->db->insert('managers' , $data); 
		return $this->db->insert_id();
	}

	function get_all_managers() {
		$this->db->from('managers');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_manager($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('managers'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

}
?>
