<?php
class Admin_model extends CI_Model
{
	public function __construct()
	{
	$this->load->database();
	}
	 
	
	// Save a new year. 
	function save_year($year_data) {
		$this->db->insert('year' , $year_data); 
		return $this->db->insert_id();
	}

	function save_chap_page($data) {
		$this->db->insert('book_chapter_page' , $data); 
		return $this->db->insert_id();
	}

	function save_instant_invoice($data) {
		$this->db->insert('invoices' , $data); 
		return $this->db->insert_id();
	}

	function get_all_years() {
		$this->db->from('year');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_no_invoiced_parents() {
		$this->db->select('id,name');
		$this->db->from('parent');
		$this->db->where('invoiced',0);
		$query = $this->db->get();
		return ($query->result_array());
	}


	function check_instant_invoice($parent_id,$month_id,$year) {
		$this->db->from('invoices'); 
		$this->db->where('parent_id',$parent_id);
		$this->db->where('month',$month_id);
		$this->db->where('year',$year);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	function get_parent_fee($parent_id) {
		$this->db->select('fee');
		$this->db->from('parent');
		$this->db->where('id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function process_form_seven() {
		$submitted_times = array();
		$config['hostname'] = "localhost";
        $config['username'] = "learnqur_wordad7";
        $config['password'] = "QXBqUkOIBiIt";
        $config['database'] = "learnqur_wordpressad7";
        $config['dbdriver'] = "mysql";
        $config['dbprefix'] = "";
        $config['pconnect'] = FALSE;
        $config['db_debug'] = TRUE;
        $config['cache_on'] = FALSE;
        $config['cachedir'] = "";
        $config['char_set'] = "utf8";
        $config['dbcollat'] = "utf8_general_ci";

        $customer_db = $this->load->database($config, TRUE);
        $customer_db->distinct();
        $customer_db->from('wp_brlk_cf7dbplugin_submits');
		$customer_db->where('status',0);
		$query = $customer_db->get();
		$results = $query->result_array();
		foreach ($results as $result) {
			$submitted_times[] = $result['submit_time'];
		}

		foreach($submitted_times as $time){
			$customer_db->distinct();
        	$customer_db->from('wp_brlk_cf7dbplugin_submits');
			$customer_db->where('submit_time',$time);
			$query = $customer_db->get();
			$results = $query->result_array();
			foreach ($results as $result) {
				if($result['field_order'] == '0'){
					$data['name'] = $result['field_value'];
				}
				elseif($result['field_order'] == '1'){
					$data['email'] = $result['field_value'];
				}
				elseif($result['field_order'] == '2'){
					$data['phone'] = $result['field_value'];
				}
				elseif($result['field_order'] == '3'){
					$data['country'] = $result['field_value'];
				}
				elseif($result['field_order'] == '4'){
					$data['message'] = $result['field_value'];
				}
				$data['status'] = 'open';
				$data['date'] = date('Y-m-d');
				$this->db->insert('qurries' , $data);
				echo $this->db->last_query();
			}
		}
	}


	function get_all_qurries() {
		$today = date('Y-m-d');
		$ignore = array('close', 'done','spam');
		$this->db->from('qurries');
		//$this->db->where_not_in('status',$ignore);
		$this->db->where('date',$today);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_close_querys() {
		$this->db->from('qurries');
		$this->db->where('status','close');
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_open_querys() {
		$this->db->from('qurries');
		$this->db->where('status','open');
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_today_querys() {
		$today = date('Y-m-d');
		$this->db->from('qurries');
		$this->db->where('date',$today);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_pending_querys() {
		$ignore = array('close', 'done','spam');
		$this->db->from('qurries');
		$this->db->where_not_in('status',$ignore);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_trial_querys() {
		$ignore = array('close', 'done','spam');
		$this->db->from('qurries');
		$this->db->where('trial_status',1);
		$this->db->where_not_in('status',$ignore);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_done_querys() {
		$this->db->from('qurries');
		$this->db->where('status','done');
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function show_spam_querys() {
		$this->db->from('qurries');
		$this->db->where('status','spam');
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function set_query_call_status($id,$state) {
		$this->db->where('id',$id);
		if( $state == 1){
			$data['call_status'] = 0;
		}else{
			$data['call_status'] = 1;
		}
		$query = $this->db->update('qurries', $data);
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_query($data) {
		$this->db->insert('qurries' , $data); 
		return $this->db->insert_id();
	}

	function query_delete($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('qurries'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function query_close($id,$state)
	{	
		$this->db->where('id', $id);
		if( $state == 1){
			$data['status'] = 'Pending';
		}else{
			$data['status'] = 'close';
		}
		$query = $this->db->update('qurries', $data); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function query_spam($id,$state)
	{	
		$this->db->where('id', $id);
		if( $state == 1){
			$data['status'] = 'Pending';
		}else{
			$data['status'] = 'spam';
		}
		$query = $this->db->update('qurries', $data); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function query_done($id,$state)
	{	
		$this->db->where('id', $id);
		if( $state == 1){
			$data['status'] = 'Pending';
		}else{
			$data['status'] = 'done';
		}
		$query = $this->db->update('qurries', $data); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function set_query_email_status($id,$state) {
		$this->db->where('id',$id);
		if( $state == 1){
			$data['email_status'] = 0;
		}else{
			$data['email_status'] = 1;
		}
		$query = $this->db->update('qurries', $data);
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function set_query_trial_status($id,$state) {
		$this->db->where('id',$id);
		if( $state == 1){
			$data['trial_status'] = 0;
		}else{
			$data['trial_status'] = 1;
		}
		$query = $this->db->update('qurries', $data);
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function get_year_year($year_id) {
		$this->db->select('year');
		$this->db->from('year');
		$this->db->where('id',$year_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function delete_year($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('year'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_course($data) {
		$this->db->insert('courses' , $data); 
		return $this->db->insert_id();
	}

	function save_message($data) {
		$this->db->insert('messages' , $data); 
		return $this->db->insert_id();
	}

	function get_all_complaints() {
		$this->db->select('complaints.*,parent.name as pname , students.name as sname , teachers.name as tname');
		$this->db->from('complaints');
		$this->db->join('parent','parent.id = complaints.parent_id');
		$this->db->join('students','students.id = complaints.student_id');
		$this->db->join('teachers','teachers.id = complaints.teacher_id');
		$query = $this->db->get();
		return ($query->result_array());
	}


	function get_all_courses() {
		$this->db->from('courses');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_course($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('courses'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_teacher($data) {
		$this->db->insert('teachers' , $data); 
		return $this->db->insert_id();
	}

	function save_teacher_leave($data) {
		$this->db->insert('teacher_leaves' , $data); 
		return $this->db->insert_id();
	}

	function get_all_teachers() {
		$this->db->select('teachers.*,shifts.shift');
		$this->db->from('teachers');
		$this->db->join('shifts','shifts.id = teachers.shift_id');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_today_schedule($day) {
		$this->db->from('schedule');
		$this->db->where('day',$day);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function updated_studnet_schedule($day,$student_ids) {
		$this->db->from('schedule');
		$this->db->where('day',$day);
		$this->db->where_not_in('student_id',$student_ids);
		$query = $this->db->get();
		//echo $this->db->last_query();
		return ($query->result_array());
	}

	function get_teacher_leave($teacher_id,$date)
	{	
		$this->db->from('teacher_leaves');
		$this->db->where('teacher_id',$teacher_id);
		$this->db->where('date',$date);
		$query = $this->db->get();
		if($query->num_rows() >= 1){
			return true;
		}else{
			return false;
		}
	}

	function get_today_classes($day,$date) {
		$this->db->from('classes');
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Pending');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_current_std_ids() {
		$ids = array();
		$this->db->distinct();
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->select('student_id');
		$this->db->from('classes');
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$query = $this->db->get();
		foreach ($query->result_array() as $value) {
			$ids[] = $value['student_id']; 
		}
		if(count($ids) > 0){
			return implode(',', $ids);
		}else{
			return true;
		}
			
	}

	function check_manager_username($name)
	{	
		$this->db->from('managers');
        $this->db->where('username', $name);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}


	function check_manager_email($email)
	{	
		$this->db->from('managers');
        $this->db->where('email', $email);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}

	function check_manager_cnic($cnic)
	{	
		$this->db->from('managers');
        $this->db->where('cnic', $cnic);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}

	function check_teacher_username($name)
	{	
		$this->db->from('teachers');
        $this->db->where('user_name', $name);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}


	function check_teacher_email($email)
	{	
		$this->db->from('teachers');
        $this->db->where('email', $email);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}

	function check_teacher_cnic($cnic)
	{	
		$this->db->from('teachers');
        $this->db->where('cnic', $cnic);
       	$query =  $this->db->get(); 
		if($query->num_rows() >= 1){
		  return true;
		}else{
		  return false;
		}
	}

	function get_all_classes() {
		$this->db->from('classes');
		$this->db->order_by('id', 'DESC');
		echo $this->db->last_query();
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_teacher($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('teachers'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}


	function save_country($data) {
		$this->db->insert('countries' , $data); 
		return $this->db->insert_id();
	}

	function get_all_countries() {
		$this->db->from('countries');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_country($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('countries'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_shift($data) {
		$this->db->insert('shifts' , $data); 
		return $this->db->insert_id();
	}

	function get_all_shifts() {
		$this->db->from('shifts');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_shift($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('shifts'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_parent($data) {
		$this->db->insert('parent' , $data); 
		return $this->db->insert_id();
	}

	function save_book($data) {
		$this->db->insert('course_books' , $data); 
		return $this->db->insert_id();
	}

	function get_all_parents() {
		$this->db->from('parent');
		$this->db->where('status','active');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_all_chapters($book_id,$course_id) {
		$this->db->from('course_book_chapters');
		$this->db->join('course_books','course_books.id = course_book_chapters.book_id');
		$this->db->where('course_books.course_id',$course_id);
		$this->db->where('course_book_chapters.book_id',$book_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_chap_page_num($chap_id) {
		$this->db->select('page_no');
		$this->db->from('book_chapter_page');
		$this->db->where('chapter_id',$chap_id);
		$this->db->order_by('id', 'DESC');
		$this->db->limit('1');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_all_parents_filters($country,$manager,$fdate,$ftype,$invoice,$status) {
		$this->db->from('parent');
		if($status != Null){
			$this->db->where('status',$status);
		}
		if($manager != Null){
			$this->db->where('manage_id',$manager);
		}
		if($country != Null){
			$this->db->where('country_id',$country);
		}
		if($ftype != Null){
			$this->db->where('fee_type',$ftype);
		}
		if($fdate != Null){
			$this->db->where('fee_date',$fdate);
		}
		if($invoice != Null){
			$this->db->where('invoiced',$invoice);
		}
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_status($student_id) {
		$this->db->select('status');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_all_students_filters($country,$manager,$status,$teacher,$parent) {
		$this->db->from('students');
		if($status != Null){
			$this->db->where('students.status',$status);
		}
		if($manager != Null){
			$this->db->where('students.manage_id',$manager);
		}
		if($teacher != Null){
			$this->db->where('students.teacher_id',$teacher);
		}
		if($parent != Null){
			$this->db->where('students.parent_id',$parent);
		}
		if($country != Null){
			$this->db->join('parent', 'students.parent_id = parent.id');
			$this->db->where('parent.country_id',$country);
		}
		
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_today_classes_filters($day,$date,$status,$teacher) {
		$this->db->from('classes');
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		if($status != Null){
			$this->db->where('status',$status);
		}
		//if($manager != Null){
			//$this->db->where('manage_id',$manager);
		//}
		if($teacher != Null){
			$this->db->where('Teacher_id',$teacher);
		}
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_all_classes_filters($date,$status,$teacher) {
		$this->db->from('classes');
		$this->db->order_by('id', 'DESC');
		if($status != Null){
			$this->db->where('status',$status);
		}
		if($date != Null){
			$this->db->where('date',$date);
		}
		if($teacher != Null){
			$this->db->where('Teacher_id',$teacher);
		}
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_by_teacher($teacher_id) {
		$this->db->select('id,name');
		$this->db->from('students');
		$this->db->where('teacher_id',$teacher_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_days($student_id) {
		$this->db->select('days');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_students_nums($teacher_id) {
		$this->db->from('students');
		$this->db->where('teacher_id',$teacher_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_comments($comp_id) {
		$this->db->select('remarks');
		$this->db->from('complaints');
		$this->db->where('id',$comp_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_query($comp_id) {
		$this->db->select('comments');
		$this->db->from('qurries');
		$this->db->where('id',$comp_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_holiday_by_end_date($date) {
		$this->db->from('holidays');
		$this->db->where('end_date',$date);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_all_invoices_filters($month,$manager,$year,$ftype,$status,$parent) {
		$this->db->select('invoices.*,parent.name,parent.fee_type');
		$this->db->from('invoices');
		$this->db->join('parent','parent.id = invoices.parent_id');
		if($status != Null){
			$this->db->where('invoices.status',$status);
		}
		if($manager != Null){
			$this->db->where('parent.manage_id',$manager);
		}
		if($month != Null){
			$this->db->where('invoices.month',$month);
		}
		if($year != Null){
			$this->db->where('invoices.year',$year);
		}
		if($ftype != Null){
			$this->db->where('parent.fee_type',$ftype);
		}
		if($parent != Null){
			$this->db->where('invoices.parent_id',$parent);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		return ($query->result_array());
	}

	function get_all_invoices() {
		$this->db->select('invoices.*,parent.name,parent.fee_type');
		$this->db->from('invoices');
		$this->db->join('parent','parent.id = invoices.parent_id');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_parent($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('parent'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function get_parent($id)
	{
		$this->db->from('parent');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_book($id)
	{
		$this->db->from('course_books');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function save_student($data) {
		$this->db->insert('students' , $data); 
		return $this->db->insert_id();
	}

	function save_book_chapter($data) {
		$this->db->insert('course_book_chapters' , $data); 
		return $this->db->insert_id();
	}

	function save_class($data) {
		$this->db->insert('classes' , $data); 
		return $this->db->insert_id();
	}

	function get_all_students() {
		$this->db->from('students');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_teacher_schedule($teacher_id) {
		$this->db->select('students.name,schedule.*');
		$this->db->from('schedule');
		$this->db->join('students', 'schedule.student_id = students.id');
		$this->db->where('schedule.teacher_id',$teacher_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_course($couser_id) {
		$this->db->select('name');
		$this->db->from('courses');
		$this->db->where('id',$couser_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_parent_manager($manager_id) {
		$this->db->select('name');
		$this->db->from('managers');
		$this->db->where('id',$manager_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_parent_country($country_id) {
		$this->db->select('name');
		$this->db->from('countries');
		$this->db->where('id',$country_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_parent_name($parent_id) {
		$this->db->select('name');
		$this->db->from('parent');
		$this->db->where('id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_course_id($student_id) {
		$this->db->select('course_id');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}


	function get_student_num($parent_id) {
		$this->db->from('students');
		$this->db->where('parent_id',$parent_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_chap_num($book_id) {
		$this->db->from('course_book_chapters');
		$this->db->where('book_id',$book_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_total_pages($book_id) {
		$this->db->from('book_chapter_page');
		$this->db->join('course_book_chapters', 'course_book_chapters.id = book_chapter_page.chapter_id');
		$this->db->where('course_book_chapters.book_id',$book_id);
		//$this->db->where('chapter_id',$book_id);
		$query = $this->db->get();
		//echo $this->db->last_query();
		return ($query->num_rows());
	}    


	function get_student_timezone($student_id) {
		$this->db->select('parent.timezone');
		$this->db->from('parent');
		$this->db->join('students', 'parent.id = students.parent_id');
		$this->db->where('students.id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_name($student_id) {
		$this->db->select('name');
		$this->db->from('students');
		$this->db->where('id',$student_id);
		$query = $this->db->get();
		return ($query->row());
	}
	function get_student_manager($manager_id) {
		$this->db->select('name');
		$this->db->from('managers');
		$this->db->where('id',$manager_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_teacher($teacher_id) {
		$this->db->select('name');
		$this->db->from('teachers');
		$this->db->where('id',$teacher_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_country($parent_id) {
		$this->db->select('countries.code');
		$this->db->from('countries');
		$this->db->join('parent', 'parent.country_id = countries.id');
		$this->db->where('parent.id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_country_name($country_id) {
		$this->db->select('countries.code');
		$this->db->from('countries');
		$this->db->where('id',$country_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_fname($parent_id) {
		$this->db->select('parent.name');
		$this->db->from('parent');
		$this->db->join('students', 'students.parent_id = parent.id');
		$this->db->where('students.parent_id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_pmail($parent_id) {
		$this->db->select('email');
		$this->db->from('parent');
		$this->db->where('id',$parent_id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_student_schedule($student_id) {
		$this->db->from('schedule');
		$this->db->where('student_id',$student_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_detail_student_schedule($student_id) {
		$this->db->select('day,time');
		$this->db->from('schedule');
		$this->db->where('student_id',$student_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_student_classrecords($student_id) {
		$this->db->from('classes');
		$this->db->where('student_id',$student_id);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function delete_student($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('students'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function delete_book($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('course_books'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function delete_invoice($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('invoices'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}
	
	function get_shift($id)
	{
		$this->db->from('shifts');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_invoice_data($id)
	{
		$this->db->from('invoices');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_class_detail_data($id)
	{
		$this->db->from('classes');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_shift($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('shifts', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_invoice($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('invoices', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_comments($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('complaints', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_qurries($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('qurries', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_course_book($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('course_books', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_class($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('classes', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_class_times($id)
	{
		$this->db->select('start_time,end_time');
		$this->db->from('classes');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function get_total_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_taken_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Taken');
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_running_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Started');
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_sl_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Student Leave');
		$query = $this->db->get();
		return ($query->num_rows());
	}


	function get_tl_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Teacher Leave');
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_remianing_classes()
	{
		$day = date('l');
        $date = date("Y-m-d");
		$this->db->from('classes');	
		$this->db->where('day',$day);
		$this->db->where('date',$date);
		$this->db->where('status','Pending');
		$query = $this->db->get();
		return ($query->num_rows());
	}

	function get_country($id)
	{
		$this->db->from('countries');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_country($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('countries', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_year($id)
	{
		$this->db->from('year');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_year($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('year', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_student($id)
	{
		$this->db->from('students');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_student($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('students', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_teacher($id)
	{
		$this->db->from('teachers');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_teacher($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('teachers', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function update_parent($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('parent', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function get_manager($id)
	{
		$this->db->from('managers');	
		$this->db->where('id',$id);
		$query = $this->db->get();
		return ($query->row());
	}

	function update_manager($id, $data){
		$this->db->where('id', $id);
		$query = $this->db->update('managers', $data);
		if($query)
		{
			return true;
		}else {
			return false;
		}
	}

	function save_holiday($data) {
		$this->db->insert('holidays' , $data); 
		return $this->db->insert_id();
	}
    

	function schedule_check($student_id,$teacher_id,$time,$day)
	{
		$this->db->from('schedule');
		$this->db->where('teacher_id',$teacher_id);
		$this->db->where('student_id',$student_id);
		$this->db->where('time',$time);
		$this->db->where('day',$day);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}


	function save_schedule($data) {
		$this->db->insert('schedule' , $data); 
		return $this->db->insert_id();
	}


	function delete_schedule($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('schedule'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_manager($data) {
		$this->db->insert('managers' , $data); 
		return $this->db->insert_id();
	}

	function get_all_managers() {
		$this->db->from('managers');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_course_books() {
		$this->db->from('course_books');
		$query = $this->db->get();
		return ($query->result_array());
	}

	function get_selected_books($course_id) {
		$this->db->from('course_books');
		$this->db->where('course_id', $course_id);
		$query = $this->db->get();
		return ($query->result_array());
	}

	function delete_manager($id)
	{	
		$this->db->where('id', $id);
		$query = $this->db->delete('managers'); 
		if($query){
			return true;
		}else{
			return false;
		}
	}

	function save_teacher_notification($teacher_id,$data) {
		$this->db->insert('Notifications' , $data); 
		$insert_id = $this->db->insert_id();
		if($insert_id){
			$noti_data = array(
				'teacher_id' => $teacher_id,
				'notification_id' => $insert_id
				);
			$this->db->insert('teacher_notifications' , $noti_data); 
			return $this->db->insert_id();
		}
		else{
			return false;
		}
	}

	function save_parent_notification($parent_id,$data) {
		$this->db->insert('Notifications' , $data); 
		$insert_id = $this->db->insert_id();
		if($insert_id){
			$noti_data = array(
				'parent_id' => $parent_id,
				'notification_id' => $insert_id
				);  
			$this->db->insert('parent_notifications' , $noti_data); 
			return $this->db->insert_id();
		}
		else{
			return false;
		}
	}



}
?>
