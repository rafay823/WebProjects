
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>HOMER | WebApp admin theme</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/metisMenu.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.print.css" media='print'/>
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/sweet-alert.css" />


    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/helper.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/style.css">
    <style>
        .parent-content {
        padding: 20px;
        width: 100%;
        }
    .parent-table {
        padding: 20px;
        width: 100%;
        }
    .common-class {
        display: none;
        }
    .common-class.active {
        display: block;
        width: 100%;
        }
    </style>

</head>
<body class="fixed-navbar fixed-sidebar relative">

    <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
        <div class="row">
            <div class="col-sm-12">
                <table id="example2" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>School </th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>School</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
        
<!-- Vendor scripts -->
<script src="<?php echo base_url()?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>public/js/curvedLines.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/metisMenu.min.js"></script>
<script src="<?php echo base_url()?>public/js/icheck.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.peity.min.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/moment.min.js"></script>
<script src="<?php echo base_url()?>public/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url()?>public/js/toastr.min.js"></script>
<script src="<?php echo base_url()?>public/js/sweet-alert.min.js"></script>


<!-- App scripts -->
<script src="<?php echo base_url()?>public/js/homer.js"></script>
<script src="<?php echo base_url()?>public/js/charts.js"></script>
<script src="<?php echo base_url()?>public/js/app.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url()?>public/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>

<script>

    $(function () { 
        // Initialize Example 2
        //$('#example2').dataTable();
         $('#example2').DataTable( {
        "ajax": 'https://learnquraan.co.uk/ci/index.php/Admin/all_courses',
        "columnDefs": [ {
            "targets": -1,
            "data": null,
            "defaultContent": '<button  data-toggle="modal" data-target="#edit_year" class="btn btn-info btn-sm">Edit</button><button class="btn btn-danger btn-sm delete-year" data-id="">Delete</button>'
        } ]
    } );
    });

</script>
</body>
</html>