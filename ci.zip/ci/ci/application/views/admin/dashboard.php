<?php
if (!isset($this->session->userdata['logged_in'])) {
    header("location:https://learnquraan.co.uk/ci/index.php/Admin");
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>LEARN QURAN | Admin Panel</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/metisMenu.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.print.css" media='print'/>
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/sweet-alert.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap-clockpicker.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker3.min.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/helper.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
    <style>
        .parent-content {
        padding: 20px;
        width: 100%;
        }
        .parent-table {
            padding: 20px;
            width: 100%;
            }
        .common-class {
            display: none;
            }
        .common-class.active {
            display: block;
            width: 100%;
            }

        .no-gap {
            margin: 0 !important;
        }

        .double-pad-top {
            padding-top: 20px;
        }
        .no-border {
            border: 0 none !important;
        }

        .hpanel table th {
          background: #3f5872 none repeat scroll 0 0;
          color: #fff;
        }

        .hpanel table tr td:first-child {
          width: 100px;
        }

        .hpanel table tr td {
          width: 200px;
        } 

        #add_schedule_modal .select2-container {
            width: 100% !important;
        }

        #add_schedule_modal .select2-selection--multiple {
            width: 100%;
        }

        .table-box {
            background: #0486ca none repeat scroll 0 0;
            color: #fff;
            font-size: 12px;
            line-height: 15px;
            position: relative;
            text-align: center;
        }

        .table-box p {
            margin-top: 10px;
        }

        .close-btn {
          color: #fff !important;
          cursor: pointer;
          float: right;
          font-size: 12px;
          padding: 2px 5px;
          position: absolute;
          right: 0;
          text-align: right;
          top: 0;
        }

        .social-board{
            padding-top: 21px;
        }

        table#classes-table tr td:first-child {
            width: 150px;
        }

        table#classes-table tr td:last-child {
            width: 400px;
        }

        table#invoices-table tr td:last-child {
            width: 390px !important;
        }

        table#parent-table tr td:last-child {
            width: 1100px;
        }

        table#all-classes-table{
            width: 100% !important;
        }


        table#classes-table{
            width: 100% !important;
        }

        table#parent-table{
            width: 100% !important;
        }

        #student-table{
            width: 100% !important;
        }

        #student-table th.action,#student-table td.action{
            width: 15%;
        }

        table#invoices-table{
            width: 100% !important;
        }

        table#classes-history-table{
            width: 100% !important;
        }

        .badge{
            cursor: pointer;
        }

        #parent-filter-btn{
            margin-top: 23px;
        }

        #student-filter-btn{
            margin-top: 23px;
        }

        #classes-filter-btn{
            margin-top: 23px;
        }

        #classes-history-filter-btn{
            margin-top: 23px;
        }

        #update-class-schedule{
            margin-top: 23px;
        }

        #invoices-filter-btn{
            margin-top: 23px;
        }

        table#all-course-book-table tr td:last-child {
            width: 355px;
        }

        #delete-page-icon{
            cursor: pointer;
        }

        .select2-selection--multiple {
            width: 577px;
            margin-top: 26px;
        }

        th.hide_me, td.hide_me {
            display: none;
        }

        .green {
            color: #69AA46!important;
        }

        .action-buttons a {
            margin: 0 3px;
            display: inline-block;
            opacity: .85;
            -webkit-transition: all .1s;
            -o-transition: all .1s;
            transition: all .1s;
        }
        .bigger-140 {
            font-size: 140%!important;
        }
        .ace-icon {
            text-align: center;
        }

        .custom_wd_show{
            width: 250px;
        }

        .m-t-md-top {
            padding-top: 12%;
        }

        .social-talk-holder {
            min-height: 132px;
            max-height: 132px;
            overflow-y: auto;
        }

        .detail-info {
            min-height: 55px;
        }

        #v_p_fee{
            cursor: pointer;
        }

        #d_h_v{
            cursor:pointer;
        }

        .mt-top-cus{
            margin-top: 12px;
        }

        .class-filter-box{
            background: #fff;
            border: 1px solid #e4e5e7;
            left:14px;
        }

    </style>

</head>
<body class="fixed-navbar fixed-sidebar relative">
<input type="hidden" id="login-name" value="<?php echo $this->session->userdata['logged_in']['username'] ?>"></input>
<!-- Simple splash screen-->
<div class="splash"><div class="splash-title"><h1>Learn Quran Academy</h1><div class="spinner"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div> </div> </div>
<!--[if lt IE 7]>
<p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<!-- Header -->
<div id="header">
    <div id="logo" class="light-version">
        <span>
            Learn Quran
        </span>
    </div>
    <nav role="navigation">
        <div class="header-link hide-menu"><i class="fa fa-bars"></i></div>
        <div class="small-logo">
            <span class="text-primary">HOMER APP</span>
        </div>
        <!--<form role="search" class="navbar-form-custom" method="post" action="#">
            <div class="form-group">
                <input type="text" placeholder="Search something special" class="form-control" name="search">
            </div>
        </form> -->
        <div class="mobile-menu">
            <button type="button" class="navbar-toggle mobile-menu-toggle" data-toggle="collapse" data-target="#mobile-collapse">
                <i class="fa fa-chevron-down"></i>
            </button>
            <div class="collapse mobile-navbar" id="mobile-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="" href="login.html">Login</a>
                    </li>
                    <li>
                        <a class="" href="login.html">Logout</a>
                    </li>
                    <li>
                        <a class="" href="profile.html">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar-right">
            <ul class="nav navbar-nav no-borders">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-speaker"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown notification animated flipInX">
                        <li>
                            <a>
                                <span class="label label-success">NEW</span> It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-warning">WAR</span> There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-danger">ERR</span> Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See all notifications</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-mail"></i>
                        <span class="label label-success">4</span>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <div class="title">
                            You have 4 new messages
                        </div>
                        <li>
                            <a>
                                It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                Lorem Ipsum is simply dummy.
                            </a>
                        </li>
                        <li>
                            <a>
                                Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See All Messages</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-upload pe-rotate-90"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <li>
                            <a data-toggle="modal" data-target="#send_message">
                                Send Message
                            </a>
                        </li>
                        <li>
                            <a>
                                Edit Profile
                            </a>
                        </li>
                        <li>
                            <a id="logout" href="javascript:;">
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Navigation -->
<aside id="menu">
    <div id="navigation">
        <div class="profile-picture">
            <a href="javascript:;">
                <img src="<?php echo base_url()?>public/images/profile.jpg" class="img-circle m-b" alt="logo">
            </a>
        </div>

        <ul class="nav" id="side-menu">
            <li class="active">
                <a data-tab="dashboard-tab" href="javascript:;" class="j_all-parent"><span class="nav-label">Dashboard</span></a>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Classes</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="today-classes">Today Classes</a></li> -->
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="classes-history">Classes History</a></li> -->
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-classes">Classes History</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Managers</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-manager-tab">View All Managers</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-manager-tab">Add New Managers</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Teachers</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-tech-tab">View All Teachers</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-tech-tab">Add New Teacher</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Parents</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-parent-tab">View All Parents</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-parent-tab">Add New Parent</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Students</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-student-tab">View All Students</a></li>
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="add-parent-tab">Add New Student</a></li> -->
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Invoices</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="instant-invoice">Instant Invoice</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-invoices-tab">View All Invoices</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Schedule</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="scheduling">Scheduling</a></li>
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="day-two-tab">Day 2</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-three-tab">Day 3</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-four-tab">Day 4</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-five-tab">Day 5</a></li> -->
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Leave</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="teacher-leave-tab">Teacher Leave</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Courses</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-course-tab">View All Courses</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-course">Add New Course</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Books</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-books-tab">View All Books</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-book">Add New Book</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-pages">Add New Pages</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Year</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="year-list">Year List</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-year">Add New Year</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="all-complains-tab">Complains</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="all-qurries-tab">Qurries</a>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Shifts</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-shift-tab">View All Shifts</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-shift-tab">Add New Shift</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Countries</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-country-tab">View All Countries List</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-country-tab">Add New Country</a></li>
                </ul>
            </li>
        </ul>
    </div>
</aside>

<!-- Main Wrapper -->
<div id="wrapper">
    <div class="common-outter">
        <div class="common-class dashboard-tab active">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12 text-center m-t-md">
                        <h2>
                            Welcome to Learn Quran Admin Panel
                        </h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: blanchedalmond;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Today Classes
                                </h3>
                                <h1><?php echo $this->Admin_model->get_total_classes(); ?></h1>   
                            </div> 
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: greenyellow;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Taken Classes
                                </h3>
                                <h1><?php echo $this->Admin_model->get_taken_classes(); ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: azure;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Running Classes
                                </h3>
                                <h1><?php echo $this->Admin_model->get_running_classes(); ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: aquamarine;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Student Leaves
                                </h3>
                                <h1><?php echo $this->Admin_model->get_sl_classes(); ?></h1>
                            </div>
                        </div>
                    </div> 
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: gainsboro;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Teacher Leaves
                                </h3>
                                <h1><?php echo $this->Admin_model->get_tl_classes(); ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100" style="background-color: gold;">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Remaining
                                </h3>
                                <h1><?php echo $this->Admin_model->get_remianing_classes(); ?></h1>
                            </div>
                        </div>
                    </div>   
                </div>
                <div class="row col-lg-12 class-filter-box">
                    <div class="form-group col-lg-2">
                        <label>Status</label>
                        <select id="classes-filter-status" class="form-control" name="status[]" />
                            <option value="all">All</option>
                            <option value="Pending">Pending</option>
                            <option value="Started">Running</option>
                            <option value="Taken">Taken</option>
                            <option value="Student Leave">Student Leave</option>
                            <option value="Teacher Leave">Teacher Leave</option>
                        </select>
                    </div>
                    <!--<div class="form-group col-lg-2">
                        <label>Manager</label>
                        <select id="student-filter-manager" class="form-control" name="manager" />
                            <option value="all">All</option>
                            <?php
                            //$this->load->model('Admin_model'); 
                            //$all_managers = $this->Admin_model->get_all_managers();
                            //foreach($all_managers as $manager){?>
                            <option value="<?php //echo $manager['id']?>"><?php //echo $manager['name']?></option>
                            <?php //} ?> 
                        </select>
                    </div> -->
                    <div class="form-group col-lg-2">
                        <label>Teacher</label>
                        <select id="classes-filter-teacher" class="form-control" name="manager" />
                            <option value="all">All</option>
                            <?php
                            $this->load->model('Admin_model'); 
                            $all_teachers = $this->Admin_model->get_all_teachers();
                            foreach($all_teachers as $teacher){?>
                            <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                            <?php } ?> 
                        </select>
                    </div>
                    <?php $active_student_ids = $this->Admin_model->get_current_std_ids();?>
                    <button id="classes-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                    <button id="update-class-schedule" data-student-ids="<?php echo $active_student_ids?>" class="btn btn-success pull-right" >Update</button>              
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>History</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>History</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--<div class="common-class all-complains-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            
                            <h2 class="font-light m-b-xs">Complaints</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="complaint-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Student Name</th>
                                                        <th>Parent Name</th>
                                                        <th>Teacher Name</th>
                                                        <th>Complaint</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Student Name</th>
                                                        <th>Parent Name</th>
                                                        <th>Teacher Name</th>
                                                        <th>Complaint</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="common-class all-complains-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            
                            <h2 class="font-light m-b-xs">Complaints</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row social-board">
                    <?php 
                    $all_complaints = $this->Admin_model->get_all_complaints();
                    foreach ($all_complaints as $complaint) {?>
                    <div class="col-lg-4 hpanel hgreen">
                        <div class="panel-body">
                            <div class="media social-profile clearfix">
                                <span class="label label-success pull-right">NEW</span>
                                <a class="pull-left">
                                    <!-- <img src="images/a7.jpg" alt="profile-picture"> -->
                                </a>
                                  
                                <div class="media-body">
                                    <h5><?php echo $complaint['pname']?></h5>
                                    <small class="text-muted">13.05.2015</small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['tname']?></h5>
                                    <small class="text-muted">Teacher</small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['sname']?></h5>
                                    <small class="text-muted">Student</small>
                                </div>
                            </div>

                            <div class="social-content m-t-md">
                                <?php echo $complaint['complaint']?>
                                <!--<img class="img-responsive m-t-md" src="images/p2.jpg" alt=""> -->

                            </div>
                        </div>
                        <div class="panel-footer">
                        <?php 
                            $remarks = json_decode($complaint['remarks'] , true);
                            if(count($remarks) != 0){
                            foreach ($remarks as $remark) {?>
                            <div class="social-talk">
                                <div class="media social-profile clearfix">
                                    <a class="pull-left">
                                        <!--<img src="images/a1.jpg" alt="profile-picture"> -->
                                    </a>
                                    <div class="media-body">
                                        <span class="font-bold"><?php echo $remark['name']?></span>
                                        <small class="text-muted"><?php echo $remark['date']?></small>
                                        <div class="social-content">
                                            <?php echo $remark['remarks']?>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                            <?php } }?>
                            <div class="social-form social-form-<?php echo $complaint['id']?>">
                                <input class="form-control" placeholder="Your comment" id="complaint-comment" data-complaint-id="<?php echo $complaint['id']?>">
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="common-class all-qurries-tab">
            <?php $this->Admin_model->process_form_seven();?>
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <a class="small-header-action" href="">
                                <div class="clip-header">
                                    <i class="fa fa-arrow-up"></i>
                                </div>
                            </a>
                            <div id="hbreadcrumb" class="pull-right m-t-lg">
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-pending">Pending</a>
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-today">Today</a>
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-trial">Trial</a>
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-done">Done</a>
                                <!--<a href="javascript:;" class="btn btn-xs btn-default btn-show-open">Open</a>-->
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-close">Close</a>
                                <a href="javascript:;" class="btn btn-xs btn-default btn-show-spam">Spam</a>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Qurries
                            </h2>
                            <small>Qurries board</small>
                        </div>
                    </div>
                </div>
                <div class="row social-board query-board">
                    <?php 
                    $all_qurries = $this->Admin_model->show_pending_querys();

                    foreach ($all_qurries as $query) {?>
                    <div class="col-lg-6">
                        <div class="hpanel hgreen">
                            <div class="panel-body">
                                <span class="label label-success pull-right">NEW</span>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <h4><a href="javascript:;"><?php echo $query['name']?></a></h4>
                                        <p class="detail-info">
                                            <?php echo $query['message']?>
                                        </p>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="project-label">Email</div>
                                                <small><?php echo $query['email']?></small>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="project-label">Phone</div>
                                                <small><?php echo $query['phone']?></small>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="project-label">Country</div>
                                                <small><?php echo $query['country']?></small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4 project-info">
                                        <div class="project-action m-t-md">
                                            <div class="btn-group pull-right">
                                                <button class="btn btn-xs <?php if($query['status'] == 'done'){ echo 'btn-success' ;}else{ echo 'btn-default btn-done-query' ;}?>" data-id="<?php echo $query['id']?>">Done</button>
                                                <button class="btn btn-xs <?php if($query['status'] == 'close'){ echo 'btn-success' ;}else{ echo 'btn-default btn-close-query' ;}?>" data-id="<?php echo $query['id']?>">Close</button>
                                                <button class="btn btn-xs btn-default btn-delete-query" data-id="<?php echo $query['id']?>">Spam</button>
                                            </div>
                                        </div>
                                        <div class="project-action m-t-md m-t-md-top">
                                            <div class="btn-group pull-right">
                                                <button class="btn btn-xs <?php if($query['call_status'] == 1){ echo 'btn-success' ;}else{ echo 'btn-default btn-for-call' ;}?>" data-id="<?php echo $query['id']?>"> Call</button>
                                                <button class="btn btn-xs <?php if($query['email_status'] == 1){ echo 'btn-success' ;}else{ echo 'btn-default btn-for-email' ;}?>" data-id="<?php echo $query['id']?>"> Email</button>
                                                <button class="btn btn-xs <?php if($query['trial_status'] == 1){ echo 'btn-success' ;}else{ echo 'btn-default btn-for-trial' ;}?>" data-id="<?php echo $query['id']?>"> Trial</button>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <div class="social-talk-holder">
                                    <?php 
                                    $remarks = json_decode($query['comments'] , true);
                                    if(count($remarks) != 0){
                                    foreach ($remarks as $remark) {?>
                                    <div class="social-talk">
                                        <div class="media social-profile clearfix">
                                            <div class="media-body">
                                                <span class="font-bold"><?php echo $remark['name']?></span>
                                                <small class="text-muted"><?php echo $remark['date']?></small>
                                                <div class="social-content">
                                                    <?php echo $remark['comments']?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } }?>
                                </div>    
                                <div class="social-form social-form-querry-<?php echo $query['id']?>"">
                                    <input class="form-control" placeholder="Your comment" id="query-comment" data-query-id="<?php echo $query['id']?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php }?>
                </div>
            </div>
        </div>
        <!--<div class="common-class today-classes">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="common-class classes-history">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classes-history-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Lesson</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Lesson</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="common-class all-classes">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div class="row col-lg-12">
                                    <div class="form-group col-lg-2">
                                        <label>Status</label>
                                        <select id="classes-history-filter-status" class="form-control" name="status" />
                                            <option value="all">All</option>
                                            <option value="Pending">Pending</option>
                                            <option value="Started">Running</option>
                                            <option value="Taken">Taken</option>
                                            <option value="Student Leave">Student Leave</option>
                                            <option value="Teacher Leave">Teacher Leave</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Teacher</label>
                                        <select id="classes-history-filter-teacher" class="form-control" name="teacher" />
                                            <option value="all">All</option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_teachers = $this->Admin_model->get_all_teachers();
                                            foreach($all_teachers as $teacher){?>
                                            <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label class="col-sm-2 control-label">Date</label>
                                        <div class="col-sm-10">
                                            <input id="historydate" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <button id="classes-history-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                                    </div>
                                </div>    
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="all-classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class all-manager-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="manager-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Skype ID</th>
                                                        <th>Username</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Skype ID</th>
                                                        <th>Username</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-manager-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <form id="add-manager-form" action="javascript:;" method="post">
                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                    <div id="step1" class="p-m tab-pane active">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="form-group col-lg-6">
                                                        <label>Name</label>
                                                        <input type="text" class="form-control" name="manager_name" placeholder="Name" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>CNIC</label>
                                                        <input type="text" class="form-control" name="manager_cnic" placeholder="XXXXX-XXXXXXXXXXX-X" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Address</label>
                                                        <input type="text" class="form-control" name="manager_address" placeholder="Steet,Town,City" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Telephone #</label>
                                                        <input type="text" class="form-control" name="manager_landline" placeholder="" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Mobile #</label>
                                                        <input type="text" class="form-control" name="manager_mobile" placeholder="" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Email Address</label>
                                                        <input type="text" class="form-control" name="manager_email" placeholder="user@email.com" required />
                                                    </div>
                                                </div>
                                                <div class="text-center m-b-md" id="wizardControl">
                                                    <a class="btn btn-primary" data-toggle="tab">Step 2 - Offical Data</a>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-lg-6">
                                                        <label>Username</label>
                                                        <input type="text" class="form-control" name="manager_username" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Password</label>
                                                        <input type="password" class="form-control" name="manager_password" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Skype ID</label>
                                                        <input type="text" class="form-control" name="manager_skype_id" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Salaray Package</label>
                                                        <input type="text" class="form-control" name="manager_sal_pack" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Shift</label>
                                                        <select class="form-control" name="shift_id" required />
                                                            <option></option>
                                                            <?php
                                                                $all_shifts = $this->Admin_model->get_all_shifts();
                                                                foreach($all_shifts as $shift){?>
                                                                <option value="<?php echo $shift['id']?>"><?php echo $shift['shift']?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-right m-t-xs">
                                            <button id="clear-manager-form" class="btn btn-default">Clear</button>
                                            <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                            <button id='add-new-manager' type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </div>    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
        <div class="common-class all-tech-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="teacher-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Teacher Name</th>
                                                        <th>Email</th>
                                                        <th>Username</th>
                                                        <th>No. of Student</th>
                                                        <th>Shift</th>
                                                        <th>Gender</th>
                                                        <th>Skype ID</th>
                                                        <th>Skype Password</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Teacher Name</th>
                                                        <th>Email</th>
                                                        <th>Username</th>
                                                        <th>No. of Student</th>
                                                        <th>Shift</th>
                                                        <th>Gender</th>
                                                        <th>Skype ID</th>
                                                        <th>Skype Password</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class teacher-leave-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <form id="teacher-leave-form" action="javascript:;" method="post">
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Teacher Name</label>
                                                    <select class="form-control m-b" name="leave_teacher_id">
                                                        <option></option>
                                                        <?php
                                                        $this->load->model('Admin_model'); 
                                                        $all_teachers = $this->Admin_model->get_all_teachers();
                                                        foreach($all_teachers as $teacher){
                                                        ?>
                                                        <option value="<?php echo $teacher['id'];?>"><?php echo $teacher['name']; ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div id="teacher-leave-date" class="form-group col-lg-6">
                                                    <label>Date</label>
                                                    <div class="input-group date">
                                                        <input id="teacher-leave-date" type="text" class="form-control" name="teacher-leave-date"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                    </div>  
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Reason</label>
                                                    <textarea class="form-control" name="leave-reason"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-teacher-leave-form" class="btn btn-default">Clear</button>
                                        <button id='add-new-teacher' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <div class="common-class add-tech-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <form id="add-teacher-form" action="javascript:;" method="post">
                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Teacher Name</label>
                                                    <input type="text" class="form-control" name="teacher_name" placeholder="Teacher Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Father Name</label>
                                                    <input type="text" class="form-control" name="father_name" placeholder="Father Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>CNIC</label>
                                                    <input type="text" class="form-control" name="teacher_cnic" placeholder="XXXXX-XXXXXXXXXXX-X" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Address</label>
                                                    <input type="text" class="form-control" name="address" placeholder="Steet,Town,City" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Telephone #</label>
                                                    <input type="text" class="form-control" name="landline" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Mobile #</label>
                                                    <input type="text" class="form-control" name="mobile"  required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Email Address</label>
                                                    <input type="email" class="form-control" name="teacher_email" placeholder="user@email.com" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Gender</label>
                                                    <select class="form-control" name="gender" required />
                                                        <option></option>
                                                        <option>Male</option>
                                                        <option>Female</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Marital Status</label>
                                                    <select class="form-control" name="martial_status" required />
                                                        <option></option>
                                                        <option>Married</option>
                                                        <option>Single</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Qualification</label>
                                                    <input type="text" class="form-control" name="qualification" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Experience</label>
                                                    <input type="text"  class="form-control" name="experience" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Shift</label>
                                                    <select class="form-control" name="shift_id" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_shifts = $this->Admin_model->get_all_shifts();
                                                            foreach($all_shifts as $shift){?>
                                                            <option value="<?php echo $shift['id']?>"><?php echo $shift['shift']?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 2 - Offical Data</a>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Username</label>
                                                    <input type="text"  class="form-control" name="teacher_username" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Password</label>
                                                    <input type="password" class="form-control" name="password" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text" class="form-control" name="skype_id" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype Password</label>
                                                    <input type="text" class="form-control" name="skype_passwrd" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Designation</label>
                                                    <input type="text" class="form-control" name="designation" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Salaray Package</label>
                                                    <input type="text"  class="form-control" name="sal_pack" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Interview Remarks</label>
                                                    <textarea class="form-control" name="inter_remarks" ></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-teacher-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-teacher' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <div class="common-class all-parent-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row col-lg-12">
                                    <div class="form-group col-lg-2">
                                        <label>Country</label>
                                        <select id="parent-filter-country" class="form-control" name="country" />
	                                        <option value="all">All</option>
	                                        <?php
	                                            $this->load->model('Admin_model'); 
	                                            $all_countries = $this->Admin_model->get_all_countries();
	                                            foreach($all_countries as $country){?>
	                                            <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
	                                        <?php }?>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Status</label>
                                        <select id="parent-filter-status" class="form-control" name="status[]" />
                                            <option value="all">All</option>
                                            <option value="active">Active</option>
                                            <option value="deactive">Deactive</option>
                                            <option value="trial">Trial</option>
                                            <option value="holiday">On Holiday</option>
                                            <option value="leaved">Leaved</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Manager</label>
                                        <select id="parent-filter-manager" class="form-control" name="manager" />
                                            <option value="all">All</option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_managers = $this->Admin_model->get_all_managers();
                                            foreach($all_managers as $manager){?>
                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-1">
                                        <label>Fee Date</label>
                                        <select id="parent-filter-fdate" class="form-control" name="fee-date" />
                                            <option value="all">All</option>
                                            <option value="1">1</option>
                                            <option value="15">15</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-1">
                                        <label>Fee Type</label>
                                        <select id="parent-filter-ftype" class="form-control" name="fee-type" />
                                            <option value="all">All</option>
                                            <option value="paypal">Paypal</option>
                                            <option value="2checkout">2Checkout</option>
                                            <option value="wu/bankaccount">WU/Bank Account</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-1">
                                        <label>Invoiced</label>
                                        <select id="parent-filter-invoice" class="form-control" name="country" />
                                            <option value="all">All</option>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                    <button id="parent-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                                </div>
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="parent-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Mobile</th>
                                                        <th>Skype</th>
                                                        <th>Country</th>
                                                        <th>Username</th>
                                                        <th>Manager</th>
                                                        <th>Students</th>
                                                        <th>Fee</th>
                                                        <th>Fee Date</th>
                                                        <th>Password</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Mobile</th>
                                                        <th>Skype</th>
                                                        <th>Country</th>
                                                        <th>Username</th>
                                                        <th>Manager</th>
                                                        <th>Students</th>
                                                        <th>Fee</th>
                                                        <th>Fee Date</th>
                                                        <th>Password</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-parent-tab">
            <div class="content">

            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">

                            <form name="add-parent"  id="add-parent-form" action="javascript:;" method="post">

                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" href="#step4" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                <div id="step4" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Parent Name</label>
                                                    <input type="text" class="form-control" name="parent-name" placeholder="Parent Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Email</label>
                                                    <input type="email" class="form-control" name="parent-email" placeholder="user@email.com" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Username</label>
                                                    <input type="text" class="form-control" name="username"  required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Password</label>
                                                    <input type="password" class="form-control" name="password" placeholder="*********" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Telephone</label>
                                                    <input type="text" class="form-control" name="landline" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Mobile</label>
                                                    <input type="text" class="form-control" name="mobile" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text"  class="form-control" name="parent-skype" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Notes</label>
                                                    <input type="text" class="form-control" name="notes" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Manager</label>
                                                    <select class="form-control" name="parent-manager" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_managers = $this->Admin_model->get_all_managers();
                                                            foreach($all_managers as $manager){?>
                                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Country</label>
                                                    <select class="form-control" name="country" required />
                                                        <option></option>
                                                        <?php
                                                        $this->load->model('Admin_model'); 
                                                        $all_countries = $this->Admin_model->get_all_countries();
                                                        foreach($all_countries as $country){?>
                                                            <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                                                        <?php }?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>TimeZone</label>
                                                    <select class="form-control" name="parent-timezone" required />
                                                        <option></option>
                                                        <?php
                                                            $timezones = array(
                                                                'Pacific/Midway'       => "(GMT-11:00) Midway Island",
                                                                'US/Samoa'             => "(GMT-11:00) Samoa",
                                                                'US/Hawaii'            => "(GMT-10:00) Hawaii",
                                                                'US/Alaska'            => "(GMT-09:00) Alaska",
                                                                'US/Pacific'           => "(GMT-08:00) Pacific Time (US &amp; Canada)",
                                                                'America/Tijuana'      => "(GMT-08:00) Tijuana",
                                                                'US/Arizona'           => "(GMT-07:00) Arizona",
                                                                'US/Mountain'          => "(GMT-07:00) Mountain Time (US &amp; Canada)",
                                                                'America/Chihuahua'    => "(GMT-07:00) Chihuahua",
                                                                'America/Mazatlan'     => "(GMT-07:00) Mazatlan",
                                                                'America/Mexico_City'  => "(GMT-06:00) Mexico City",
                                                                'America/Monterrey'    => "(GMT-06:00) Monterrey",
                                                                'Canada/Saskatchewan'  => "(GMT-06:00) Saskatchewan",
                                                                'US/Central'           => "(GMT-06:00) Central Time (US &amp; Canada)",
                                                                'US/Eastern'           => "(GMT-05:00) Eastern Time (US &amp; Canada)",
                                                                'US/East-Indiana'      => "(GMT-05:00) Indiana (East)",
                                                                'America/Bogota'       => "(GMT-05:00) Bogota",
                                                                'America/Lima'         => "(GMT-05:00) Lima",
                                                                'America/Caracas'      => "(GMT-04:30) Caracas",
                                                                'Canada/Atlantic'      => "(GMT-04:00) Atlantic Time (Canada)",
                                                                'America/La_Paz'       => "(GMT-04:00) La Paz",
                                                                'America/Santiago'     => "(GMT-04:00) Santiago",
                                                                'Canada/Newfoundland'  => "(GMT-03:30) Newfoundland",
                                                                'America/Buenos_Aires' => "(GMT-03:00) Buenos Aires",
                                                                'Greenland'            => "(GMT-03:00) Greenland",
                                                                'Atlantic/Stanley'     => "(GMT-02:00) Stanley",
                                                                'Atlantic/Azores'      => "(GMT-01:00) Azores",
                                                                'Atlantic/Cape_Verde'  => "(GMT-01:00) Cape Verde Is.",
                                                                'Africa/Casablanca'    => "(GMT) Casablanca",
                                                                'Europe/Dublin'        => "(GMT) Dublin",
                                                                'Europe/Lisbon'        => "(GMT) Lisbon",
                                                                'Europe/London'        => "(GMT) London",
                                                                'Africa/Monrovia'      => "(GMT) Monrovia",
                                                                'Europe/Amsterdam'     => "(GMT+01:00) Amsterdam",
                                                                'Europe/Belgrade'      => "(GMT+01:00) Belgrade",
                                                                'Europe/Berlin'        => "(GMT+01:00) Berlin",
                                                                'Europe/Bratislava'    => "(GMT+01:00) Bratislava",
                                                                'Europe/Brussels'      => "(GMT+01:00) Brussels",
                                                                'Europe/Budapest'      => "(GMT+01:00) Budapest",
                                                                'Europe/Copenhagen'    => "(GMT+01:00) Copenhagen",
                                                                'Europe/Ljubljana'     => "(GMT+01:00) Ljubljana",
                                                                'Europe/Madrid'        => "(GMT+01:00) Madrid",
                                                                'Europe/Paris'         => "(GMT+01:00) Paris",
                                                                'Europe/Prague'        => "(GMT+01:00) Prague",
                                                                'Europe/Rome'          => "(GMT+01:00) Rome",
                                                                'Europe/Sarajevo'      => "(GMT+01:00) Sarajevo",
                                                                'Europe/Skopje'        => "(GMT+01:00) Skopje",
                                                                'Europe/Stockholm'     => "(GMT+01:00) Stockholm",
                                                                'Europe/Vienna'        => "(GMT+01:00) Vienna",
                                                                'Europe/Warsaw'        => "(GMT+01:00) Warsaw",
                                                                'Europe/Zagreb'        => "(GMT+01:00) Zagreb",
                                                                'Europe/Athens'        => "(GMT+02:00) Athens",
                                                                'Europe/Bucharest'     => "(GMT+02:00) Bucharest",
                                                                'Africa/Cairo'         => "(GMT+02:00) Cairo",
                                                                'Africa/Harare'        => "(GMT+02:00) Harare",
                                                                'Europe/Helsinki'      => "(GMT+02:00) Helsinki",
                                                                'Europe/Istanbul'      => "(GMT+02:00) Istanbul",
                                                                'Asia/Jerusalem'       => "(GMT+02:00) Jerusalem",
                                                                'Europe/Kiev'          => "(GMT+02:00) Kyiv",
                                                                'Europe/Minsk'         => "(GMT+02:00) Minsk",
                                                                'Europe/Riga'          => "(GMT+02:00) Riga",
                                                                'Europe/Sofia'         => "(GMT+02:00) Sofia",
                                                                'Europe/Tallinn'       => "(GMT+02:00) Tallinn",
                                                                'Europe/Vilnius'       => "(GMT+02:00) Vilnius",
                                                                'Asia/Baghdad'         => "(GMT+03:00) Baghdad",
                                                                'Asia/Kuwait'          => "(GMT+03:00) Kuwait",
                                                                'Africa/Nairobi'       => "(GMT+03:00) Nairobi",
                                                                'Asia/Riyadh'          => "(GMT+03:00) Riyadh",
                                                                'Europe/Moscow'        => "(GMT+03:00) Moscow",
                                                                'Asia/Tehran'          => "(GMT+03:30) Tehran",
                                                                'Asia/Baku'            => "(GMT+04:00) Baku",
                                                                'Europe/Volgograd'     => "(GMT+04:00) Volgograd",
                                                                'Asia/Muscat'          => "(GMT+04:00) Muscat",
                                                                'Asia/Tbilisi'         => "(GMT+04:00) Tbilisi",
                                                                'Asia/Yerevan'         => "(GMT+04:00) Yerevan",
                                                                'Asia/Kabul'           => "(GMT+04:30) Kabul",
                                                                'Asia/Karachi'         => "(GMT+05:00) Karachi",
                                                                'Asia/Tashkent'        => "(GMT+05:00) Tashkent",
                                                                'Asia/Kolkata'         => "(GMT+05:30) Kolkata",
                                                                'Asia/Kathmandu'       => "(GMT+05:45) Kathmandu",
                                                                'Asia/Yekaterinburg'   => "(GMT+06:00) Ekaterinburg",
                                                                'Asia/Almaty'          => "(GMT+06:00) Almaty",
                                                                'Asia/Dhaka'           => "(GMT+06:00) Dhaka",
                                                                'Asia/Novosibirsk'     => "(GMT+07:00) Novosibirsk",
                                                                'Asia/Bangkok'         => "(GMT+07:00) Bangkok",
                                                                'Asia/Jakarta'         => "(GMT+07:00) Jakarta",
                                                                'Asia/Krasnoyarsk'     => "(GMT+08:00) Krasnoyarsk",
                                                                'Asia/Chongqing'       => "(GMT+08:00) Chongqing",
                                                                'Asia/Hong_Kong'       => "(GMT+08:00) Hong Kong",
                                                                'Asia/Kuala_Lumpur'    => "(GMT+08:00) Kuala Lumpur",
                                                                'Australia/Perth'      => "(GMT+08:00) Perth",
                                                                'Asia/Singapore'       => "(GMT+08:00) Singapore",
                                                                'Asia/Taipei'          => "(GMT+08:00) Taipei",
                                                                'Asia/Ulaanbaatar'     => "(GMT+08:00) Ulaan Bataar",
                                                                'Asia/Urumqi'          => "(GMT+08:00) Urumqi",
                                                                'Asia/Irkutsk'         => "(GMT+09:00) Irkutsk",
                                                                'Asia/Seoul'           => "(GMT+09:00) Seoul",
                                                                'Asia/Tokyo'           => "(GMT+09:00) Tokyo",
                                                                'Australia/Adelaide'   => "(GMT+09:30) Adelaide",
                                                                'Australia/Darwin'     => "(GMT+09:30) Darwin",
                                                                'Asia/Yakutsk'         => "(GMT+10:00) Yakutsk",
                                                                'Australia/Brisbane'   => "(GMT+10:00) Brisbane",
                                                                'Australia/Canberra'   => "(GMT+10:00) Canberra",
                                                                'Pacific/Guam'         => "(GMT+10:00) Guam",
                                                                'Australia/Hobart'     => "(GMT+10:00) Hobart",
                                                                'Australia/Melbourne'  => "(GMT+10:00) Melbourne",
                                                                'Pacific/Port_Moresby' => "(GMT+10:00) Port Moresby",
                                                                'Australia/Sydney'     => "(GMT+10:00) Sydney",
                                                                'Asia/Vladivostok'     => "(GMT+11:00) Vladivostok",
                                                                'Asia/Magadan'         => "(GMT+12:00) Magadan",
                                                                'Pacific/Auckland'     => "(GMT+12:00) Auckland",
                                                                'Pacific/Fiji'         => "(GMT+12:00) Fiji",
                                                            );
                                                            foreach ($timezones as $key => $value) {?>
                                                                <option value="<?php echo $key ;?>" ><?php echo $value; ?></option>
                                                        <?php    
                                                            }
                                                        ?>
                                                        
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Invoiced</label>
                                                    <select class="form-control" name="parent-invoiced" required />
                                                        <option></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">No</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 2 - Payment data</a>
                                            </div>    
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <div class="row">
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee</label>
                                                            <input class="form-control"  type="text" name="fee" required />
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Currency</label>
                                                            <select class="form-control" name="fee-currency" required />
                                                                <option></option>
                                                                <option>USD</option>
                                                                <option>AUD</option>
                                                                <option>EURO</option>
                                                                <option>POUND</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Type</label>
                                                            <select class="form-control" name="fee-type" required />
                                                                <option></option>
                                                                <option value="paypal">Paypal</option>
                                                                <option value="2checkout">2Checkout</option>
                                                                <option value="wu/bankaccount">WU/Bank Account</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Date</label>
                                                            <select class="form-control" name="fee-date" required />
                                                                <option></option>
                                                                <option value="1">1</option>
                                                                <option value="15">15</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 3 - Student data</a>
                                            </div>    
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Student Name</label>
                                                    <input type="text" class="form-control" name="student-name[]" placeholder="Student Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text" class="form-control" name="student-skype[]" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Age</label>
                                                    <input type="text" class="form-control" name="student-age[]" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Gender</label>
                                                    <select class="form-control" name="student-gender[]" required />
                                                        <option></option>
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Course</label>
                                                    <select class="form-control" name="course[]">
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_courses = $this->Admin_model->get_all_courses();
                                                            foreach($all_courses as $course){?>
                                                            <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                        <?php } ?>    
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <!--<label>Days</label> -->
                                                    <p><strong>Days</strong></p>
                                                    <!--<select class="form-control" name="days[]" required />
                                                        <option></option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                    </select> -->
                                                    <!--<select class="form-control js-example-basic-multiple" multiple="multiple" name="days[]" required />
                                                        <option></option>
                                                        <option value="mon">Monday</option>
                                                        <option value="tues">Tuesday</option>
                                                        <option value="wed">Wednesday</option>
                                                        <option value="thur">Thursday</option>
                                                        <option value="fir">Friday</option>
                                                        <option value="sat">Saturday</option>
                                                    </select> -->
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="mon-day[]" value="mon">
                                                        <label for="inlineCheckbox1">Mon</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="tues-day[]" value="tues">
                                                        <label for="inlineCheckbox1">Tues</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="wed-day[]" value="wed">
                                                        <label for="inlineCheckbox1">Wed</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="thur-day[]" value="thur">
                                                        <label for="inlineCheckbox1">Thur</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="fri-day[]" value="fri">
                                                        <label for="inlineCheckbox1">Fri</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="sat-day[]" value="sat">
                                                        <label for="inlineCheckbox1">Sat</label>
                                                    </div>
                                                    <div class="checkbox checkbox-inline">
                                                        <input type="checkbox" id="inlineCheckbox1" name="sun-day[]" value="sat">
                                                        <label for="inlineCheckbox1">Sun</label>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Manager</label>
                                                    <select class="form-control" name="student-manager[]" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_managers = $this->Admin_model->get_all_managers();
                                                            foreach($all_managers as $manager){?>
                                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Teacher</label>
                                                    <select class="form-control" name="student-teacher[]" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_teachers = $this->Admin_model->get_all_teachers();
                                                            foreach($all_teachers as $teacher){?>
                                                            <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <!--<div class="form-group col-lg-6">
                                                    <label>Fee </label>
                                                    <input type="text" class="form-control" name="student-fee[]" required />
                                                </div> -->
                                                <div class="form-group col-lg-6">
                                                    <label>Status</label>
                                                    <select class="form-control" name="status[]" required />
                                                        <option></option>
                                                        <option value="active">Active</option>
                                                        <option value="deactive">Deactive</option>
                                                        <option value="trial">Trial</option>
                                                        <option value="holiday">On Holiday</option>
                                                        <option value="leaved">Leaved</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Trial Class Remarks</label>
                                                    <textarea class="form-control" name="trial-class-remarks[]"></textarea>
                                                </div>
                                            </div>
                                            <div id="extra-students"></div>
                                        </div>
                                    </div>

                                    <div class="text-right m-t-xs">
                                        <a class="btn btn-success pull-left" id="add-new-stud-fields">Add new student</a>
                                        <button id="clear-parent-form" class="btn btn-default">Clear</button>
                                        <button id='add-new-parent' type="submit" class="btn btn-success">Submit</button>
                                    </div>

                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <div class="common-class all-student-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row col-lg-12">
                                    <div class="form-group col-lg-2">
                                        <label>Country</label>
                                        <select id="student-filter-country" class="form-control" name="country" />
                                            <option value="all">All</option>
                                            <?php
                                                $this->load->model('Admin_model'); 
                                                $all_countries = $this->Admin_model->get_all_countries();
                                                foreach($all_countries as $country){?>
                                                <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                                                <?php }?>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Status</label>
                                        <select id="student-filter-status" class="form-control" name="status[]" />
                                            <option value="all">All</option>
                                            <option value="active">Active</option>
                                            <option value="deactive">Deactive</option>
                                            <option value="trial">Trial</option>
                                            <option value="holiday">On Holiday</option>
                                            <option value="leaved">Leaved</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Manager</label>
                                        <select id="student-filter-manager" class="form-control" name="manager" />
                                            <option value="all">All</option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_managers = $this->Admin_model->get_all_managers();
                                            foreach($all_managers as $manager){?>
                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Teacher</label>
                                        <select id="student-filter-teacher" class="form-control" name="manager" />
                                            <option value="all">All</option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_teachers = $this->Admin_model->get_all_teachers();
                                            foreach($all_teachers as $teacher){?>
                                            <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <button id="student-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                                </div>
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Schedule</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th class="action">Actions</th>
                                                        <th class="hide_me">Schedule_check</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Schedule</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th class="action">Actions</th>
                                                        <th class="hide_me">Schedule_check</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class instant-invoice">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>Invoices</span>
                                    </li>
                                    <li class="active">
                                        <span>Instant Invoice</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Send Instant Invoice
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form id="instant-invoice" method="get" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Parent Name</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="invoiced-parent-id" required="required">
                                            <option></option>
                                            <?php
                                                $this->load->model('Admin_model'); 
                                                $all_parents = $this->Admin_model->get_no_invoiced_parents();
                                                foreach($all_parents as $parent){?>
                                                    <option value="<?php echo $parent['id']?>"><?php echo $parent['name']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Month</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="invoiced-month" required="required">
                                            <option></option>
                                            <option value="01">January</option>
                                            <option value="02">February</option>
                                            <option value="03">March</option>
                                            <option value="04">April</option>
                                            <option value="05">May</option>
                                            <option value="06">June</option>
                                            <option value="07">July</option>
                                            <option value="08">August</option>
                                            <option value="09">September</option>
                                            <option value="10">October</option>
                                            <option value="11">November</option>
                                            <option value="12">December</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Year</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="invoiced-year" required="required">
                                            <option></option>
                                            <?php
                                                $this->load->model('Admin_model'); 
                                                $all_years = $this->Admin_model->get_all_years();
                                                foreach($all_years as $year){?>
                                                    <option value="<?php echo $year['year']?>"><?php echo $year['year']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Due Date</label>
                                    <div class="col-sm-10">
                                        <input id="datapicker2" type="text" class="form-control" name="invoiced-due-date" required="required">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class all-invoices-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            	<div class="row col-lg-12">
                                    <div class="form-group col-lg-2">
                                        <label>Month</label>
                                        <select id="invoices-filter-month" class="form-control" name="month" />
	                                        <option value="all">All</option>
	                                        <option value="01">January</option>
                                            <option value="02">February</option>
                                            <option value="03">March</option>
                                            <option value="04">April</option>
                                            <option value="05">May</option>
                                            <option value="06">June</option>
                                            <option value="07">July</option>
                                            <option value="08">August</option>
                                            <option value="09">September</option>
                                            <option value="10">October</option>
                                            <option value="11">November</option>
                                            <option value="12">December</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Year</label>
                                        <select id="invoices-filter-year" class="form-control" name="year" />
	                                        <option value="all">All</option>
	                                        <?php
                                                $this->load->model('Admin_model'); 
                                                $all_years = $this->Admin_model->get_all_years();
                                                foreach($all_years as $year){?>
                                                    <option value="<?php echo $year['year']?>"><?php echo $year['year']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Status</label>
                                        <select id="invoices-filter-status" class="form-control" name="status" />
                                            <option value="all">All</option>
                                            <option value="paid">Paid</option>
                                            <option value="pending">Pending</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <label>Manager</label>
                                        <select id="invoices-filter-manager" class="form-control" name="manager" />
                                            <option value="all">All</option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_managers = $this->Admin_model->get_all_managers();
                                            foreach($all_managers as $manager){?>
                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-1">
                                        <label>Fee Type</label>
                                        <select id="invoices-filter-ftype" class="form-control" name="ftype" />
                                            <option value="all">All</option>
                                            <option value="paypal">Paypal</option>
                                            <option value="2checkout">2Checkout</option>
                                            <option value="wu/bankaccount">WU/Bank Account</option>
                                        </select>
                                    </div>
                                    <button id="invoices-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                                </div>
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="invoices-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Invoice Type</th>
                                                        <th>Month/Year</th>
                                                        <th>Fee Amt</th>
                                                        <th>Fee Adj</th>
                                                        <th>Full Amt</th>
                                                        <th>Due Date</th>
                                                        <th>Inv / Sale No.</th>
                                                        <th>Status</th>
                                                        <th>Fee Type</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Invoice Type</th>
                                                        <th>Month/Year</th>
                                                        <th>Fee Amt</th>
                                                        <th>Fee Adj</th>
                                                        <th>Full Amt</th>
                                                        <th>Due Date</th>
                                                        <th>Inv / Sale No.</th>
                                                        <th>Status</th>
                                                        <th>Fee Type</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class all-course-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="all-courses-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Course </th>
                                                        <th>Person In charge</th>
                                                        <th>Title</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Course</th>
                                                        <th>Person In charge</th>
                                                        <th>Title</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                    foreach($all_courses as $course){?>
                                                        <tr>
                                                            <td>1</td>
                                                            <td><?php echo $course['name']?></td>
                                                            <td><?php echo $course['incharge']?></td>
                                                            <td><?php echo $course['title']?></td>
                                                            <td>
                                                                <button  data-toggle="modal" data-target="#add_course_book" class="btn btn-info btn-sm">Add Book</button>
                                                                <button  data-toggle="modal" data-target="#edit_course" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm delete-course" data-id="<?php echo $course['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class all-books-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="all-course-book-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-book">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>Books</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Book</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Book
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form id="course-book-form" name="course-book-form"  method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Book Name</label>
                                    <div class="col-sm-5">
                                        <input name="course-book-name" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Course</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" name="course-id">
                                            <option></option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_courses = $this->Admin_model->get_all_courses();
                                            foreach($all_courses as $course){?>
                                            <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                            <?php } ?>    
                                        </select>
                                    </div>    
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Chapter Name</label>
                                    <div class="col-sm-5">
                                        <input name="book-chapter-name[]" type="text" class="form-control">
                                    </div>
                                    <div class="col-sm-3">
                                        <button id="add-new-book-chapter" class="btn btn-primary" type="submit">Add Chapter</button>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-pages">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>Books</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Pages</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Pages
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form id="chap-pages-form" name="chap-pages-form"  method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Course</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" name="chapter-book-course-id">
                                            <option></option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_courses = $this->Admin_model->get_all_courses();
                                            foreach($all_courses as $course){?>
                                            <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                            <?php } ?>    
                                        </select>
                                    </div>    
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Book</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" name="chapter-book-name" disabled="disabled">
                                            <option></option>
                                            <?php
                                            $this->load->model('Admin_model'); 
                                            $all_courses = $this->Admin_model->get_course_books();
                                            foreach($all_courses as $course){?>
                                            <option value="<?php echo $course['id']?>"><?php echo $course['book_name']?></option>
                                            <?php } ?>    
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Chapter</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" name="chapter-name" disabled="disabled">
                                            <option></option> 
                                        </select>
                                    </div>    
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Page #</label>
                                    <div class="col-sm-1">
                                        <input name="chap-page-num[]" type="text" class="form-control" disabled="disabled">
                                    </div>
                                    <label class="col-sm-1 control-label">Page Image</label>
                                    <div class="col-sm-3">
                                        <input name="chap-page-img[]" type="file" class="form-control" disabled="disabled">
                                    </div>
                                    <div class="col-sm-1" id="delete-page-icon">
                                        <img src="https://learnquraan.co.uk/ci/public/images/close_button.png" style="width: 30px;">
                                    </div>
                                    <div class="col-sm-3">
                                        <button id="add-new-chap-page" class="btn btn-primary" type="submit" disabled="disabled">Add another Page</button>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button id="add-chap-page-btn" class="btn btn-primary" type="submit" disabled="disabled">Add</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-course">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Course</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Course
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Course</label>
                                    <div class="col-sm-10">
                                        <input name="course-name" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Person Incharge</label>
                                    <div class="col-sm-10">
                                        <input name="course-incharge" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Title</label>
                                    <div class="col-sm-10">
                                        <input name="course-title" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button id="add-new-course" class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class year-list">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="year-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid">
                                                <thead>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>School Year</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>School Year</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-year">
            <div class="content ">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Year
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                            
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Year</label>
                                    <div class="col-sm-10">
                                        <input  name="year" type="text" class="form-control" required>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button id="add-year" class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>    
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class scheduling">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">Scheduling</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel no-gap">
                            <div class="panel-heading"></div> 
                            <div class="panel-body no-border">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6 no-gap">
                                                <label>Teacher Name</label>
                                                <select id="select-teacher-schedule" class="form-control m-b" name="schedule_teacher_name">
                                                    <option></option>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_teachers = $this->Admin_model->get_all_teachers();
                                                    foreach($all_teachers as $teacher){
                                                    ?>
                                                    <option value="<?php echo $teacher['id'];?>"><?php echo $teacher['name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>        
                                            <div class="form-group col-lg-6 no-gap text-right double-pad-top">
                                                <button type="submit" class="btn btn-primary" data-target="#add_schedule_modal" data-toggle="modal">Add</button>
                                            </div>  
                                        </div>
                                    </div>        
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-body no-border">
                                <div class="table-responsive">
                                <table id="show-schedule-table" cellpadding="1" cellspacing="1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Friday</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1:00 AM</td>
                                        <td class="Monday_1_00_AM"></td>
                                        <td class="Tuesday_1_00_AM"></td>
                                        <td class="Wednesday_1_00_AM"></td>
                                        <td class="Thursday_1_00_AM"></td>
                                        <td class="Friday_1_00_AM"></td>
                                        <td class="Saturday_1_00_AM"></td>
                                        <td class="Sunday_1_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>1:30 AM</td>
                                        <td class="Monday_1_30_AM"></td>
                                        <td class="Tuesday_1_30_AM"></td>
                                        <td class="Wednesday_1_30_AM"></td>
                                        <td class="Thursday_1_30_AM"></td>
                                        <td class="Friday_1_30_AM"></td>
                                        <td class="Saturday_1_30_AM"></td>
                                        <td class="Sunday_1_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:00 AM</td>
                                        <td class="Monday_2_00_AM"></td>
                                        <td class="Tuesday_2_00_AM"></td>
                                        <td class="Wednesday_2_00_AM"></td>
                                        <td class="Thursday_2_00_AM"></td>
                                        <td class="Friday_2_00_AM"></td>
                                        <td class="Saturday_2_00_AM"></td>
                                        <td class="Sunday_2_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:30 AM</td>
                                        <td class="Monday_2_30_AM"></td>
                                        <td class="Tuesday_2_30_AM"></td>
                                        <td class="Wednesday_2_30_AM"></td>
                                        <td class="Thursday_2_30_AM"></td>
                                        <td class="Friday_2_30_AM"></td>
                                        <td class="Saturday_2_30_AM"></td>
                                        <td class="Sunday_2_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:00 AM</td>
                                        <td class="Monday_3_00_AM"></td>
                                        <td class="Tuesday_3_00_AM"></td>
                                        <td class="Wednesday_3_00_AM"></td>
                                        <td class="Thursday_3_00_AM"></td>
                                        <td class="Friday_3_00_AM"></td>
                                        <td class="Saturday_3_00_AM"></td>
                                        <td class="Sunday_3_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:30 AM</td>
                                        <td class="Monday_3_30_AM"></td>
                                        <td class="Tuesday_3_30_AM"></td>
                                        <td class="Wednesday_3_30_AM"></td>
                                        <td class="Thursday_3_30_AM"></td>
                                        <td class="Friday_3_30_AM"></td>
                                        <td class="Saturday_3_30_AM"></td>
                                        <td class="Sunday_3_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>4:00 AM</td>
                                        <td class="Monday_4_00_AM"></td>
                                        <td class="Tuesday_4_00_AM"></td>
                                        <td class="Wednesday_4_00_AM"></td>
                                        <td class="Thursday_4_00_AM"></td>
                                        <td class="Friday_4_00_AM"></td>
                                        <td class="Saturday_4_00_AM"></td>
                                        <td class="Sunday_4_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>4:30 AM</td>
                                        <td class="Monday_4_30_AM"></td>
                                        <td class="Tuesday_4_30_AM"></td>
                                        <td class="Wednesday_4_30_AM"></td>
                                        <td class="Thursday_4_30_AM"></td>
                                        <td class="Friday_4_30_AM"></td>
                                        <td class="Saturday_4_30_AM"></td>
                                        <td class="Sunday_4_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>5:00 AM</td>
                                        <td class="Monday_5_00_AM"></td>
                                        <td class="Tuesday_5_00_AM"></td>
                                        <td class="Wednesday_5_00_AM"></td>
                                        <td class="Thursday_5_00_AM"></td>
                                        <td class="Friday_5_00_AM"></td>
                                        <td class="Saturday_5_00_AM"></td>
                                        <td class="Sunday_5_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>5:30 AM</td>
                                        <td class="Monday_5_30_AM"></td>
                                        <td class="Tuesday_5_30_AM"></td>
                                        <td class="Wednesday_5_30_AM"></td>
                                        <td class="Thursday_5_30_AM"></td>
                                        <td class="Friday_5_30_AM"></td>
                                        <td class="Saturday_5_30_AM"></td>
                                        <td class="Sunday_5_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:00 AM</td>
                                        <td class="Monday_6_00_AM"></td>
                                        <td class="Tuesday_6_00_AM"></td>
                                        <td class="Wednesday_6_00_AM"></td>
                                        <td class="Thursday_6_00_AM"></td>
                                        <td class="Friday_6_00_AM"></td>
                                        <td class="Saturday_6_00_AM"></td>
                                        <td class="Sunday_6_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:30 AM</td>
                                        <td class="Monday_6_30_AM"></td>
                                        <td class="Tuesday_6_30_AM"></td>
                                        <td class="Wednesday_6_30_AM"></td>
                                        <td class="Thursday_6_30_AM"></td>
                                        <td class="Friday_6_30_AM"></td>
                                        <td class="Saturday_6_30_AM"></td>
                                        <td class="Sunday_6_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:00 AM</td>
                                        <td class="Monday_7_00_AM"></td>
                                        <td class="Tuesday_7_00_AM"></td>
                                        <td class="Wednesday_7_00_AM"></td>
                                        <td class="Thursday_7_00_AM"></td>
                                        <td class="Friday_7_00_AM"></td>
                                        <td class="Saturday_7_00_AM"></td>
                                        <td class="Sunday_7_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:30 AM</td>
                                        <td class="Monday_7_30_AM"></td>
                                        <td class="Tuesday_7_30_AM"></td>
                                        <td class="Wednesday_7_30_AM"></td>
                                        <td class="Thursday_7_30_AM"></td>
                                        <td class="Friday_7_30_AM"></td>
                                        <td class="Saturday_7_30_AM"></td>
                                        <td class="Sunday_7_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:00 AM</td>
                                        <td class="Monday_8_00_AM"></td>
                                        <td class="Tuesday_8_00_AM"></td>
                                        <td class="Wednesday_8_00_AM"></td>
                                        <td class="Thursday_8_00_AM"></td>
                                        <td class="Friday_8_00_AM"></td>
                                        <td class="Saturday_8_00_AM"></td>
                                        <td class="Sunday_8_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:30 AM</td>
                                        <td class="Monday_8_30_AM"></td>
                                        <td class="Tuesday_8_30_AM"></td>
                                        <td class="Wednesday_8_30_AM"></td>
                                        <td class="Thursday_8_30_AM"></td>
                                        <td class="Friday_8_30_AM"></td>
                                        <td class="Saturday_8_30_AM"></td>
                                        <td class="Sunday_8_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:00 AM</td>
                                        <td class="Monday_9_00_AM"></td>
                                        <td class="Tuesday_9_00_AM"></td>
                                        <td class="Wednesday_9_00_AM"></td>
                                        <td class="Thursday_9_00_AM"></td>
                                        <td class="Friday_9_00_AM"></td>
                                        <td class="Saturday_9_00_AM"></td>
                                        <td class="Sunday_9_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:30 AM</td>
                                        <td class="Monday_9_30_AM"></td>
                                        <td class="Tuesday_9_30_AM"></td>
                                        <td class="Wednesday_9_30_AM"></td>
                                        <td class="Thursday_9_30_AM"></td>
                                        <td class="Friday_9_30_AM"></td>
                                        <td class="Saturday_9_30_AM"></td>
                                        <td class="Sunday_9_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:00 AM</td>
                                        <td class="Monday_10_00_AM"></td>
                                        <td class="Tuesday_10_00_AM"></td>
                                        <td class="Wednesday_10_00_AM"></td>
                                        <td class="Thursday_10_00_AM"></td>
                                        <td class="Friday_10_00_AM"></td>
                                        <td class="Saturday_10_00_AM"></td>
                                        <td class="Sunday_10_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:30 AM</td>
                                        <td class="Monday_10_30_AM"></td>
                                        <td class="Tuesday_10_30_AM"></td>
                                        <td class="Wednesday_10_30_AM"></td>
                                        <td class="Thursday_10_30_AM"></td>
                                        <td class="Friday_10_30_AM"></td>
                                        <td class="Saturday_10_30_AM"></td>
                                        <td class="Sunday_10_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:00 AM</td>
                                        <td class="Monday_11_00_AM"></td>
                                        <td class="Tuesday_11_00_AM"></td>
                                        <td class="Wednesday_11_00_AM"></td>
                                        <td class="Thursday_11_00_AM"></td>
                                        <td class="Friday_11_00_AM"></td>
                                        <td class="Saturday_11_00_AM"></td>
                                        <td class="Sunday_11_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:30 AM</td>
                                        <td class="Monday_11_30_AM"></td>
                                        <td class="Tuesday_11_30_AM"></td>
                                        <td class="Wednesday_11_30_AM"></td>
                                        <td class="Thursday_11_30_AM"></td>
                                        <td class="Friday_11_30_AM"></td>
                                        <td class="Saturday_11_30_AM"></td>
                                        <td class="Sunday_11_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:00 AM</td>
                                        <td class="Monday_12_00_AM"></td>
                                        <td class="Tuesday_12_00_AM"></td>
                                        <td class="Wednesday_12_00_AM"></td>
                                        <td class="Thursday_12_00_AM"></td>
                                        <td class="Friday_12_00_AM"></td>
                                        <td class="Saturday_12_00_AM"></td>
                                        <td class="Sunday_12_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:30 AM</td>
                                        <td class="Monday_12_30_AM"></td>
                                        <td class="Tuesday_12_30_AM"></td>
                                        <td class="Wednesday_12_30_AM"></td>
                                        <td class="Thursday_12_30_AM"></td>
                                        <td class="Friday_12_30_AM"></td>
                                        <td class="Saturday_12_30_AM"></td>
                                        <td class="Sunday_12_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>1:00 PM</td>
                                        <td class="Monday_1_00_PM"></td>
                                        <td class="Tuesday_1_00_PM"></td>
                                        <td class="Wednesday_1_00_PM"></td>
                                        <td class="Thursday_1_00_PM"></td>
                                        <td class="Friday_1_00_PM"></td>
                                        <td class="Saturday_1_00_PM"></td>
                                        <td class="Sunday_1_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>1:30 PM</td>
                                        <td class="Monday_1_30_PM"></td>
                                        <td class="Tuesday_1_30_PM"></td>
                                        <td class="Wednesday_1_30_PM"></td>
                                        <td class="Thursday_1_30_PM"></td>
                                        <td class="Friday_1_30_PM"></td>
                                        <td class="Saturday_1_30_PM"></td>
                                        <td class="Sunday_1_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:00 PM</td>
                                        <td class="Monday_2_00_PM"></td>
                                        <td class="Tuesday_2_00_PM"></td>
                                        <td class="Wednesday_2_00_PM"></td>
                                        <td class="Thursday_2_00_PM"></td>
                                        <td class="Friday_2_00_PM"></td>
                                        <td class="Saturday_2_00_PM"></td>
                                        <td class="Sunday_2_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:30 PM</td>
                                        <td class="Monday_2_30_PM"></td>
                                        <td class="Tuesday_2_30_PM"></td>
                                        <td class="Wednesday_2_30_PM"></td>
                                        <td class="Thursday_2_30_PM"></td>
                                        <td class="Friday_2_30_PM"></td>
                                        <td class="Saturday_2_30_PM"></td>
                                        <td class="Sunday_2_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:00 PM</td>
                                        <td class="Monday_3_00_PM"></td>
                                        <td class="Tuesday_3_00_PM"></td>
                                        <td class="Wednesday_3_00_PM"></td>
                                        <td class="Thursday_3_00_PM"></td>
                                        <td class="Friday_3_00_PM"></td>
                                        <td class="Saturday_3_00_PM"></td>
                                        <td class="Sunday_3_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:30 PM</td>
                                        <td class="Monday_3_30_PM"></td>
                                        <td class="Tuesday_3_30_PM"></td>
                                        <td class="Wednesday_3_30_PM"></td>
                                        <td class="Thursday_3_30_PM"></td>
                                        <td class="Friday_3_30_PM"></td>
                                        <td class="Saturday_3_30_PM"></td>
                                        <td class="Sunday_3_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>4:00 PM</td>
                                        <td class="Monday_4_00_PM"></td>
                                        <td class="Tuesday_4_00_PM"></td>
                                        <td class="Wednesday_4_00_PM"></td>
                                        <td class="Thursday_4_00_PM"></td>
                                        <td class="Friday_4_00_PM"></td>
                                        <td class="Saturday_4_00_PM"></td>
                                        <td class="Sunday_4_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>4:30 PM</td>
                                        <td class="Monday_4_30_PM"></td>
                                        <td class="Tuesday_4_30_PM"></td>
                                        <td class="Wednesday_4_30_PM"></td>
                                        <td class="Thursday_4_30_PM"></td>
                                        <td class="Friday_4_30_PM"></td>
                                        <td class="Saturday_4_30_PM"></td>
                                        <td class="Sunday_4_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>5:00 PM</td>
                                        <td class="Monday_5_00_PM"></td>
                                        <td class="Tuesday_5_00_PM"></td>
                                        <td class="Wednesday_5_00_PM"></td>
                                        <td class="Thursday_5_00_PM"></td>
                                        <td class="Friday_5_00_PM"></td>
                                        <td class="Saturday_5_00_PM"></td>
                                        <td class="Sunday_5_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>5:30 PM</td>
                                        <td class="Monday_5_30_PM"></td>
                                        <td class="Tuesday_5_30_PM"></td>
                                        <td class="Wednesday_5_30_PM"></td>
                                        <td class="Thursday_5_30_PM"></td>
                                        <td class="Friday_5_30_PM"></td>
                                        <td class="Saturday_5_30_PM"></td>
                                        <td class="Sunday_5_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:00 PM</td>
                                        <td class="Monday_6_00_PM"></td>
                                        <td class="Tuesday_6_00_PM"></td>
                                        <td class="Wednesday_6_00_PM"></td>
                                        <td class="Thursday_6_00_PM"></td>
                                        <td class="Friday_6_00_PM"></td>
                                        <td class="Saturday_6_00_PM"></td>
                                        <td class="Sunday_6_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:30 PM</td>
                                        <td class="Monday_6_30_PM"></td>
                                        <td class="Tuesday_6_30_PM"></td>
                                        <td class="Wednesday_6_30_PM"></td>
                                        <td class="Thursday_6_30_PM"></td>
                                        <td class="Friday_6_30_PM"></td>
                                        <td class="Saturday_6_30_PM"></td>
                                        <td class="Sunday_6_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:00 PM</td>
                                        <td class="Monday_7_00_PM"></td>
                                        <td class="Tuesday_7_00_PM"></td>
                                        <td class="Wednesday_7_00_PM"></td>
                                        <td class="Thursday_7_00_PM"></td>
                                        <td class="Friday_7_00_PM"></td>
                                        <td class="Saturday_7_00_PM"></td>
                                        <td class="Sunday_7_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:30 PM</td>
                                        <td class="Monday_7_30_PM"></td>
                                        <td class="Tuesday_7_30_PM"></td>
                                        <td class="Wednesday_7_30_PM"></td>
                                        <td class="Thursday_7_30_PM"></td>
                                        <td class="Friday_7_30_PM"></td>
                                        <td class="Saturday_7_30_PM"></td>
                                        <td class="Sunday_7_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:00 PM</td>
                                        <td class="Monday_8_00_PM"></td>
                                        <td class="Tuesday_8_00_PM"></td>
                                        <td class="Wednesday_8_00_PM"></td>
                                        <td class="Thursday_8_00_PM"></td>
                                        <td class="Friday_8_00_PM"></td>
                                        <td class="Saturday_8_00_PM"></td>
                                        <td class="Sunday_8_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:30 PM</td>
                                        <td class="Monday_8_30_PM"></td>
                                        <td class="Tuesday_8_30_PM"></td>
                                        <td class="Wednesday_8_30_PM"></td>
                                        <td class="Thursday_8_30_PM"></td>
                                        <td class="Friday_8_30_PM"></td>
                                        <td class="Saturday_8_30_PM"></td>
                                        <td class="Sunday_8_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:00 PM</td>
                                        <td class="Monday_9_00_PM"></td>
                                        <td class="Tuesday_9_00_PM"></td>
                                        <td class="Wednesday_9_00_PM"></td>
                                        <td class="Thursday_9_00_PM"></td>
                                        <td class="Friday_9_00_PM"></td>
                                        <td class="Saturday_9_00_PM"></td>
                                        <td class="Sunday_9_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:30 PM</td>
                                        <td class="Monday_9_30_PM"></td>
                                        <td class="Tuesday_9_30_PM"></td>
                                        <td class="Wednesday_9_30_PM"></td>
                                        <td class="Thursday_9_30_PM"></td>
                                        <td class="Friday_9_30_PM"></td>
                                        <td class="Saturday_9_30_PM"></td>
                                        <td class="Sunday_9_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:00 PM</td>
                                        <td class="Monday_10_00_PM"></td>
                                        <td class="Tuesday_10_00_PM"></td>
                                        <td class="Wednesday_10_00_PM"></td>
                                        <td class="Thursday_10_00_PM"></td>
                                        <td class="Friday_10_00_PM"></td>
                                        <td class="Saturday_10_00_PM"></td>
                                        <td class="Sunday_10_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:30 PM</td>
                                        <td class="Monday_10_30_PM"></td>
                                        <td class="Tuesday_10_30_PM"></td>
                                        <td class="Wednesday_10_30_PM"></td>
                                        <td class="Thursday_10_30_PM"></td>
                                        <td class="Friday_10_30_PM"></td>
                                        <td class="Saturday_10_30_PM"></td>
                                        <td class="Sunday_10_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:00 PM</td>
                                        <td class="Monday_11_00_PM"></td>
                                        <td class="Tuesday_11_00_PM"></td>
                                        <td class="Wednesday_11_00_PM"></td>
                                        <td class="Thursday_11_00_PM"></td>
                                        <td class="Friday_11_00_PM"></td>
                                        <td class="Saturday_11_00_PM"></td>
                                        <td class="Sunday_11_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:30 PM</td>
                                        <td class="Monday_11_30_PM"></td>
                                        <td class="Tuesday_11_30_PM"></td>
                                        <td class="Wednesday_11_30_PM"></td>
                                        <td class="Thursday_11_30_PM"></td>
                                        <td class="Friday_11_30_PM"></td>
                                        <td class="Saturday_11_30_PM"></td>
                                        <td class="Sunday_11_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:00 PM</td>
                                        <td class="Monday_12_00_PM"></td>
                                        <td class="Tuesday_12_00_PM"></td>
                                        <td class="Wednesday_12_00_PM"></td>
                                        <td class="Thursday_12_00_PM"></td>
                                        <td class="Friday_12_00_PM"></td>
                                        <td class="Saturday_12_00_PM"></td>
                                        <td class="Sunday_12_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:30 PM</td>
                                        <td class="Monday_12_30_PM"></td>
                                        <td class="Tuesday_12_30_PM"></td>
                                        <td class="Wednesday_12_30_PM"></td>
                                        <td class="Thursday_12_30_PM"></td>
                                        <td class="Friday_12_30_PM"></td>
                                        <td class="Saturday_12_30_PM"></td>
                                        <td class="Sunday_12_30_PM"></td>
                                    </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--- shifts -->
        <div class="common-class all-shift-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="shift-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Shift</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Shift</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-shift-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">

                            <form id="add-shift-form" action="javascript:;" method="post">
                                
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <label>Shift</label>
                                                    <input type="" value="" id="" class="form-control" name="shift" required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Start Time</label>
                                                    <div class="input-group clockpicker" data-autoclose="true">
                                                        <input name="shift-start-time" type="text" class="form-control" required />
                                                            <span class="input-group-addon">
                                                                <span class="fa fa-clock-o"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>End Time</label>
                                                    <div class="input-group clockpicker" data-autoclose="true">
                                                        <input name="shift-end-time" type="text" class="form-control" required />
                                                            <span class="input-group-addon">
                                                                <span class="fa fa-clock-o"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-shift-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-shift' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <!-- end shifts -->
        <!--countries -->
        <div class="common-class all-country-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="country-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Country</th>
                                                        <th>Code</th>
                                                        <th>Currency</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Country</th>
                                                        <th>Code</th>
                                                        <th>Currency</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-country-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <form id="add-country-form" action="javascript:;" method="post">
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <label>Country Name</label>
                                                    <input type="text"  class="form-control" name="count-name"  required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Code</label>
                                                    <input type="text"  class="form-control" name="count-code"  required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Currency</label>
                                                    <input type="text"  class="form-control" name="count-currency"  required />
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-country-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-country' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <!--end country -->
    </div>

    <!--- teacher modal -->
    <div class="modal fade" id="myModal5" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Modal title</h4>
                    <small class="font-bold">Lorem Ipsum is simply dummy text.</small>
                </div>
                <div class="modal-body">
                    <p><strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,
                    remaining essentially unchanged.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher modal -->

    <!--- manager edit modal -->
    <div class="modal fade" id="edit_manager" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <input id="edit-manager-id" type="hidden" class="form-control">
                                            <div class="text-center"><strong>Personal Bio Data</strong></div>
                                            <div class="hr-line-dashed"></div>  
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-name" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">CNIC</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-cnic" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Address</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-address" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Telephone</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-landline" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-mobile" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Email</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-email" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                        </form>
                                    </div>
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <div class="text-center"><strong> Office Details</strong></div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">User Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-username" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <!--<div class="form-group">
                                                <label class="col-sm-4 control-label">Password</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-pass" type="password" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>-->
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Skype ID</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-skype" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Salary Package</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-salary" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Shift</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-manager-shift" class="form-control" name="shift_id" required />
                                                        <option></option>
                                                        <?php
                                                            $all_shifts = $this->Admin_model->get_all_shifts();
                                                            foreach($all_shifts as $shift){?>
                                                            <option value="<?php echo $shift['id']?>"><?php echo $shift['shift']?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="pull-right">
                                                <button id="update-edit-manager" type="button" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end manager edit modal -->

    <!--- manager view modal -->
    <div class="modal fade" id="view_manager" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <h2>Manager Profile</h2>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table class="table table-user-information">
                                            <tbody>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td id="view-manager-name"></td>
                                                </tr>
                                                <tr>
                                                    <td>CNIC:</td>
                                                    <td id="view-manager-cnic"></td>
                                                </tr>
                                                <tr>
                                                    <td>Address</td>
                                                    <td id="view-manager-address"></td>
                                                </tr>
                                                <tr>
                                                    <td>Telephone</td>
                                                    <td id="view-manager-tele"></td>
                                                </tr>
                                                <tr>
                                                    <td>Mobile</td>
                                                    <td id="view-manager-mobile"></td>
                                                </tr>
                                                <tr>
                                                    <td>Email</td>
                                                    <td id="view-manager-email"></td>
                                                </tr>
                                                <tr>
                                                    <td>User Name</td>
                                                    <td id="view-manager-username"></td>
                                                </tr>
                                                <tr>
                                                    <td>Skype ID</td>
                                                    <td id="view-manager-skype"></td>
                                                </tr>
                                                <tr>
                                                    <td>Salary Package</td>
                                                    <td id="view-manager-spack"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end manager view modal -->

    <!--- teacher view modal -->
    <div class="modal fade" id="view_teacher" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <h2>Teacher Profile</h2>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table class="table table-user-information">
                                            <tbody>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td id="view-teacher-name"></td>
                                                </tr>
                                                <tr>
                                                    <td>Father Name:</td>
                                                    <td id="view-teacher-fname"></td>
                                                </tr>
                                                <tr>
                                                    <td>CNIC:</td>
                                                    <td id="view-teacher-cnic"></td>
                                                </tr>
                                                <tr>
                                                    <td>Address:</td>
                                                    <td id="view-teacher-address"></td>
                                                </tr>
                                                <tr>
                                                    <td>Email:</td>
                                                    <td id="view-teacher-email"></td>
                                                </tr>
                                                <tr>
                                                    <td>Username:</td>
                                                    <td id="view-teacher-username"></td>
                                                </tr>
                                                <tr>
                                                    <td>Telephone:</td>
                                                    <td id="view-teacher-telephone"></td>
                                                </tr>
                                                <tr>
                                                    <td>Mobile:</td>
                                                    <td id="view-teacher-mobile"></td>
                                                </tr>
                                                <tr>
                                                    <td>Shift:</td>
                                                    <td id="view-teacher-shift"></td>
                                                </tr>
                                                <tr>
                                                    <td>Gender:</td>
                                                    <td id="view-teacher-gender"></td>
                                                </tr>
                                                <tr>
                                                    <td>Martial Status:</td>
                                                    <td id="view-teacher-mstatus"></td>
                                                </tr>
                                                <tr>
                                                    <td>Qualification:</td>
                                                    <td id="view-teacher-qual"></td>
                                                </tr>
                                                <tr>
                                                    <td>Experience:</td>
                                                    <td id="view-teacher-exper"></td>
                                                </tr>
                                                <tr>
                                                    <td>Skype ID:</td>
                                                    <td id="view-teacher-skype"></td>
                                                </tr>
                                                <tr>
                                                    <td>Skype Password</td>
                                                    <td id="view-teacher-skypass"></td>
                                                </tr>
                                                <tr>
                                                    <td>Designation</td>
                                                    <td id="view-teacher-design"></td>
                                                </tr>
                                                <tr>
                                                    <td>Salary Package</td>
                                                    <td id="view-teacher-salpack"></td>
                                                </tr>
                                                <tr>
                                                    <td>Interiew Remarks</td>
                                                    <td id="view-teacher-intermarks"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher view modal -->

    <!--- show schedule modal -->
    <div class="modal fade" id="show_schedule" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog custom_wd_show">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                Student Schedule
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                            <th>Day</th>
                                            <th>Time</th>
                                        </thead>    
                                        <tbody id="show_student_schedule_table">
                                            
                                        </tbody>
                                        
                                    </table>  
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end show schedule modal -->


    <!--- teacher profile modal -->
    <div class="modal fade" id="edit_teacher" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <input id="edit-teacher-id" type="hidden" class="form-control">
                                            <div class="text-center"><strong>Personal Bio Data</strong></div>
                                            <div class="hr-line-dashed"></div>  
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Teacher Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-name" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Father Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-fname" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">CNIC</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-cnic" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Address</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-address" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Telephone</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-landline" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-mobile" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Email</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-email" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Shift</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-shift" class="form-control" name="shift" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_shifts = $this->Admin_model->get_all_shifts();
                                                            foreach($all_shifts as $shift){?>
                                                            <option value="<?php echo $shift['id']?>"><?php echo $shift['shift']?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>    
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Gender</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-gender" class="form-control" name="account">
                                                    <option></option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Marital Status</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-mat-status" class="form-control" name="account">
                                                        <option></option>
                                                        <option value="Single">Single</option>
                                                        <option value="Married">Married</option>
                                                        <option value="Divorced">Divorced</option>
                                                    </select>    
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Qualification</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-qualification" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Experience</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-experience" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                        </form>
                                    </div>
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <div class="text-center"><strong> Office Details</strong></div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Designation</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-designation" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Skype ID</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-skype" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Skype Password</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-skype-passwrd" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Salary Package</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-salary" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">User Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-username" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <!--<div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Password</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-pass" type="password" class="form-control">
                                                </div>
                                            </div> -->
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Interview remarks</label>
                                                <div class="col-sm-8">
                                                    <textarea id="edit-teacher-interremarks" type="text" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="pull-right">
                                                <button id="update-edit-teacher" type="button" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher profile modal -->

    <!--- parent view modal -->
    <div class="modal fade" id="view_parent" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <h2>Parent Profile</h2>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table class="table table-user-information">
                                            <tbody>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td id="view-parent-name"></td>
                                                </tr>
                                                <tr>
                                                    <td>Email:</td>
                                                    <td id="view-parent-email"></td>
                                                </tr>
                                                <tr>
                                                    <td>Username:</td>
                                                    <td id="view-parent-username"></td>
                                                </tr>
                                                <tr>
                                                    <td>Telephone:</td>
                                                    <td id="view-parent-telephone"></td>
                                                </tr>
                                                <tr>
                                                    <td>Mobile:</td>
                                                    <td id="view-parent-mobile"></td>
                                                </tr>
                                                <tr>
                                                    <td>Manager:</td>
                                                    <td id="view-parent-manager"></td>
                                                </tr>
                                                <tr>
                                                    <td>Skype ID:</td>
                                                    <td id="view-parent-skype"></td>
                                                </tr>
                                                <tr>
                                                    <td>Notes</td>
                                                    <td id="view-parent-note"></td>
                                                </tr>
                                                <tr>
                                                    <td>Country</td>
                                                    <td id="view-parent-country"></td>
                                                </tr>
                                                <tr>
                                                    <td>Time Zone</td>
                                                    <td id="view-parent-timezone"></td>
                                                </tr>
                                                <tr>
                                                    <td>Invoiced</td>
                                                    <td id="view-parent-invoiced"></td>
                                                </tr>
                                                <tr>
                                                    <td>Fee</td>
                                                    <td id="view-parent-fee"></td>
                                                </tr>
                                                <tr>
                                                    <td>Fee Currency</td>
                                                    <td id="view-parent-fee_currency"></td>
                                                </tr>
                                                <tr>
                                                    <td>Fee Type</td>
                                                    <td id="view-parent-fee_type"></td>
                                                </tr>
                                                <tr>
                                                    <td>Fee Date</td>
                                                    <td id="view-parent-fee_date"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end parent view modal -->


    <!--- edit parent modal -->
    <div class="modal fade" id="edit_parent" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-heading">
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <input type="hidden" id="edit-parent-id" class="form-control" >
                                                        <div class="form-group col-lg-6">
                                                            <label>Parent Name</label>
                                                            <input type="text" id="edit-parent-name" class="form-control" >
                                                        </div>
                                                    
                                                        <div class="form-group col-lg-6">
                                                            <label>Email</label>
                                                            <input type="email" id="edit-parent-email" class="form-control">
                                                        </div>
                                                    
                                                        <div class="form-group col-lg-6">
                                                            <label>Username</label>
                                                            <input type="text" id="edit-parent-username" class="form-control">
                                                        </div>
                                                        
                                                        <!--<div class="form-group col-lg-6">
                                                            <label>Password</label>
                                                            <input type="password" id="edit-parent-password" class="form-control">
                                                        </div> -->
                                                    
                                                        <div class="form-group col-lg-6">
                                                            <label>Telephone</label>
                                                            <input type="text" id="edit-parent-telephone" class="form-control">
                                                        </div>
                                                        
                                                        <div class="form-group col-lg-6">
                                                            <label>Mobile</label>
                                                            <input type="text" id="edit-parent-mobile" class="form-control">
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Skype ID</label>
                                                            <input type="text" id="edit-parent-skype" class="form-control">
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Notes</label>
                                                            <input type="text" id="edit-parent-note" class="form-control">
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Manager</label>
                                                            <select id="edit-parent-manager" class="form-control">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_managers = $this->Admin_model->get_all_managers();
                                                                    foreach($all_managers as $manager){?>
                                                                        <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Country</label>
                                                            <select id="edit-parent-country" class="form-control">
                                                                <option></option>
                                                                <?php
                                                                $this->load->model('Admin_model'); 
                                                                $all_countries = $this->Admin_model->get_all_countries();
                                                                foreach($all_countries as $country){?>
                                                                    <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Time Zone</label>
                                                            <select id="edit-parent-timezone" class="form-control">
                                                                <option></option>
                                                                <?php
                                                            $timezones = array(
                                                                'Pacific/Midway'       => "(GMT-11:00) Midway Island",
                                                                'US/Samoa'             => "(GMT-11:00) Samoa",
                                                                'US/Hawaii'            => "(GMT-10:00) Hawaii",
                                                                'US/Alaska'            => "(GMT-09:00) Alaska",
                                                                'US/Pacific'           => "(GMT-08:00) Pacific Time (US &amp; Canada)",
                                                                'America/Tijuana'      => "(GMT-08:00) Tijuana",
                                                                'US/Arizona'           => "(GMT-07:00) Arizona",
                                                                'US/Mountain'          => "(GMT-07:00) Mountain Time (US &amp; Canada)",
                                                                'America/Chihuahua'    => "(GMT-07:00) Chihuahua",
                                                                'America/Mazatlan'     => "(GMT-07:00) Mazatlan",
                                                                'America/Mexico_City'  => "(GMT-06:00) Mexico City",
                                                                'America/Monterrey'    => "(GMT-06:00) Monterrey",
                                                                'Canada/Saskatchewan'  => "(GMT-06:00) Saskatchewan",
                                                                'US/Central'           => "(GMT-06:00) Central Time (US &amp; Canada)",
                                                                'US/Eastern'           => "(GMT-05:00) Eastern Time (US &amp; Canada)",
                                                                'US/East-Indiana'      => "(GMT-05:00) Indiana (East)",
                                                                'America/Bogota'       => "(GMT-05:00) Bogota",
                                                                'America/Lima'         => "(GMT-05:00) Lima",
                                                                'America/Caracas'      => "(GMT-04:30) Caracas",
                                                                'Canada/Atlantic'      => "(GMT-04:00) Atlantic Time (Canada)",
                                                                'America/La_Paz'       => "(GMT-04:00) La Paz",
                                                                'America/Santiago'     => "(GMT-04:00) Santiago",
                                                                'Canada/Newfoundland'  => "(GMT-03:30) Newfoundland",
                                                                'America/Buenos_Aires' => "(GMT-03:00) Buenos Aires",
                                                                'Greenland'            => "(GMT-03:00) Greenland",
                                                                'Atlantic/Stanley'     => "(GMT-02:00) Stanley",
                                                                'Atlantic/Azores'      => "(GMT-01:00) Azores",
                                                                'Atlantic/Cape_Verde'  => "(GMT-01:00) Cape Verde Is.",
                                                                'Africa/Casablanca'    => "(GMT) Casablanca",
                                                                'Europe/Dublin'        => "(GMT) Dublin",
                                                                'Europe/Lisbon'        => "(GMT) Lisbon",
                                                                'Europe/London'        => "(GMT) London",
                                                                'Africa/Monrovia'      => "(GMT) Monrovia",
                                                                'Europe/Amsterdam'     => "(GMT+01:00) Amsterdam",
                                                                'Europe/Belgrade'      => "(GMT+01:00) Belgrade",
                                                                'Europe/Berlin'        => "(GMT+01:00) Berlin",
                                                                'Europe/Bratislava'    => "(GMT+01:00) Bratislava",
                                                                'Europe/Brussels'      => "(GMT+01:00) Brussels",
                                                                'Europe/Budapest'      => "(GMT+01:00) Budapest",
                                                                'Europe/Copenhagen'    => "(GMT+01:00) Copenhagen",
                                                                'Europe/Ljubljana'     => "(GMT+01:00) Ljubljana",
                                                                'Europe/Madrid'        => "(GMT+01:00) Madrid",
                                                                'Europe/Paris'         => "(GMT+01:00) Paris",
                                                                'Europe/Prague'        => "(GMT+01:00) Prague",
                                                                'Europe/Rome'          => "(GMT+01:00) Rome",
                                                                'Europe/Sarajevo'      => "(GMT+01:00) Sarajevo",
                                                                'Europe/Skopje'        => "(GMT+01:00) Skopje",
                                                                'Europe/Stockholm'     => "(GMT+01:00) Stockholm",
                                                                'Europe/Vienna'        => "(GMT+01:00) Vienna",
                                                                'Europe/Warsaw'        => "(GMT+01:00) Warsaw",
                                                                'Europe/Zagreb'        => "(GMT+01:00) Zagreb",
                                                                'Europe/Athens'        => "(GMT+02:00) Athens",
                                                                'Europe/Bucharest'     => "(GMT+02:00) Bucharest",
                                                                'Africa/Cairo'         => "(GMT+02:00) Cairo",
                                                                'Africa/Harare'        => "(GMT+02:00) Harare",
                                                                'Europe/Helsinki'      => "(GMT+02:00) Helsinki",
                                                                'Europe/Istanbul'      => "(GMT+02:00) Istanbul",
                                                                'Asia/Jerusalem'       => "(GMT+02:00) Jerusalem",
                                                                'Europe/Kiev'          => "(GMT+02:00) Kyiv",
                                                                'Europe/Minsk'         => "(GMT+02:00) Minsk",
                                                                'Europe/Riga'          => "(GMT+02:00) Riga",
                                                                'Europe/Sofia'         => "(GMT+02:00) Sofia",
                                                                'Europe/Tallinn'       => "(GMT+02:00) Tallinn",
                                                                'Europe/Vilnius'       => "(GMT+02:00) Vilnius",
                                                                'Asia/Baghdad'         => "(GMT+03:00) Baghdad",
                                                                'Asia/Kuwait'          => "(GMT+03:00) Kuwait",
                                                                'Africa/Nairobi'       => "(GMT+03:00) Nairobi",
                                                                'Asia/Riyadh'          => "(GMT+03:00) Riyadh",
                                                                'Europe/Moscow'        => "(GMT+03:00) Moscow",
                                                                'Asia/Tehran'          => "(GMT+03:30) Tehran",
                                                                'Asia/Baku'            => "(GMT+04:00) Baku",
                                                                'Europe/Volgograd'     => "(GMT+04:00) Volgograd",
                                                                'Asia/Muscat'          => "(GMT+04:00) Muscat",
                                                                'Asia/Tbilisi'         => "(GMT+04:00) Tbilisi",
                                                                'Asia/Yerevan'         => "(GMT+04:00) Yerevan",
                                                                'Asia/Kabul'           => "(GMT+04:30) Kabul",
                                                                'Asia/Karachi'         => "(GMT+05:00) Karachi",
                                                                'Asia/Tashkent'        => "(GMT+05:00) Tashkent",
                                                                'Asia/Kolkata'         => "(GMT+05:30) Kolkata",
                                                                'Asia/Kathmandu'       => "(GMT+05:45) Kathmandu",
                                                                'Asia/Yekaterinburg'   => "(GMT+06:00) Ekaterinburg",
                                                                'Asia/Almaty'          => "(GMT+06:00) Almaty",
                                                                'Asia/Dhaka'           => "(GMT+06:00) Dhaka",
                                                                'Asia/Novosibirsk'     => "(GMT+07:00) Novosibirsk",
                                                                'Asia/Bangkok'         => "(GMT+07:00) Bangkok",
                                                                'Asia/Jakarta'         => "(GMT+07:00) Jakarta",
                                                                'Asia/Krasnoyarsk'     => "(GMT+08:00) Krasnoyarsk",
                                                                'Asia/Chongqing'       => "(GMT+08:00) Chongqing",
                                                                'Asia/Hong_Kong'       => "(GMT+08:00) Hong Kong",
                                                                'Asia/Kuala_Lumpur'    => "(GMT+08:00) Kuala Lumpur",
                                                                'Australia/Perth'      => "(GMT+08:00) Perth",
                                                                'Asia/Singapore'       => "(GMT+08:00) Singapore",
                                                                'Asia/Taipei'          => "(GMT+08:00) Taipei",
                                                                'Asia/Ulaanbaatar'     => "(GMT+08:00) Ulaan Bataar",
                                                                'Asia/Urumqi'          => "(GMT+08:00) Urumqi",
                                                                'Asia/Irkutsk'         => "(GMT+09:00) Irkutsk",
                                                                'Asia/Seoul'           => "(GMT+09:00) Seoul",
                                                                'Asia/Tokyo'           => "(GMT+09:00) Tokyo",
                                                                'Australia/Adelaide'   => "(GMT+09:30) Adelaide",
                                                                'Australia/Darwin'     => "(GMT+09:30) Darwin",
                                                                'Asia/Yakutsk'         => "(GMT+10:00) Yakutsk",
                                                                'Australia/Brisbane'   => "(GMT+10:00) Brisbane",
                                                                'Australia/Canberra'   => "(GMT+10:00) Canberra",
                                                                'Pacific/Guam'         => "(GMT+10:00) Guam",
                                                                'Australia/Hobart'     => "(GMT+10:00) Hobart",
                                                                'Australia/Melbourne'  => "(GMT+10:00) Melbourne",
                                                                'Pacific/Port_Moresby' => "(GMT+10:00) Port Moresby",
                                                                'Australia/Sydney'     => "(GMT+10:00) Sydney",
                                                                'Asia/Vladivostok'     => "(GMT+11:00) Vladivostok",
                                                                'Asia/Magadan'         => "(GMT+12:00) Magadan",
                                                                'Pacific/Auckland'     => "(GMT+12:00) Auckland",
                                                                'Pacific/Fiji'         => "(GMT+12:00) Fiji"
                                                            );
                                                            foreach ($timezones as $key => $value) {?>
                                                                <option value="<?php echo $key ;?>" ><?php echo $value; ?></option>
                                                        <?php    
                                                            }
                                                        ?>
                                                                
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Invoiced</label>
                                                            <select id="edit-parent-invoiced" class="form-control">
                                                                <option></option>
                                                                <option value="1">Yes</option>
                                                                <option value="0">No</option>
                                                                
                                                            </select>
                                                        </div>

                                                        <div class="form-group col-lg-6">
                                                            <label>Fee</label>
                                                            <input id="edit-parent-fee" class="form-control" type="text">
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Fee Currency</label>
                                                            <select id="edit-parent-fee_currency"  class="form-control">
                                                                <option></option>
                                                                <option>USD</option>
                                                                <option>AUD</option>
                                                                <option>EURO</option>
                                                                <option>POUND</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Fee Type</label>
                                                            <select id="edit-parent-fee_type" class="form-control">
                                                                <option></option>
                                                                <option>Paypal</option>
                                                                <option>2Checkout</option>
                                                                <option>WU/Bank Account</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>Fee Date</label>
                                                            <select id="edit-parent-fee_date" class="form-control">
                                                                <option></option>
                                                                <option>1</option>
                                                                <option>15</option>
                                                            </select>
                                                        </div>
                                                        <div class="pull-right">
                                                            <button id="update-edit-parent" type="button" class="btn btn-info">Update</button>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                        </div>    
                                                    </div>
                                                </div>        
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end edit parent modal -->


    <!--- edit book modal -->
    <div class="modal fade" id="edit_book" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit-book-id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Book Name</label>
                                                            <input type="text" id="edit-book-name" class="form-control" >
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <select id="edit-book-course" class="form-control">
                                                                <option></option>
                                                                <?php
                                                                $this->load->model('Admin_model'); 
                                                                $all_courses = $this->Admin_model->get_all_courses();
                                                                foreach($all_courses as $course){?>
                                                                <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                                <?php } ?>    
                                                            </select>
                                                        </div>
                                                        <div class="pull-right">
                                                            <button id="update-edit-book" type="button" class="btn btn-info">Update</button>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                        </div>    
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

   <!--- edit book modal -->

    <!--- send message modal -->
    <div class="modal fade" id="send_message" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form id="send-message-form" method="post" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit-book-id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Send To</label>
                                                            <select id="send-to" class="form-control">
                                                                <option></option>
                                                                <option value="manager">Manager</option>
                                                                <option value="teacher">Teacher</option>
                                                                <option value="parent">Parent</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Name</label>
                                                            <select id="edit-message-receiver" class="form-control">
                                                                <option></option>    
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Message</label>
                                                            <textarea id="message-to-send" class="form-control"></textarea>
                                                        </div>
                                                        <div class="pull-right">
                                                            <button id="send-message" type="button" class="btn btn-info">Send</button>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                        </div>    
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

   <!--- end send message modal -->

    <!--- edit year modal -->
    <div class="modal fade" id="edit_year" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <input id="edit_year_id" type="hidden"  class="form-control" name="year_id" required />
                                                        <div class="form-group col-lg-12">
                                                            <label>Year</label>
                                                            <input id="edit_year_name" type="text" class="form-control" name="year_year" required />
                                                        </div>
                                                        <button id="update-edit-year" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>        
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end edit year modal -->

    <!--- edit course modal -->

    <div class="modal fade" id="edit_course" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Person Incharge</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Title</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <button type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit course modal -->

    <!--- edit shift modal -->

    <div class="modal fade" id="edit_shift" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_shift_id" type="hidden"  class="form-control" name="shift_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Shift</label>
                                                            <input id="edit_shift_name" type="text"  class="form-control" name="shift_name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12 clockpicker" data-autoclose="true">
                                                            <label>Start Time</label>
                                                            <input id="edit_shift_start_time" type="text"  class="form-control" name="shift_s_time" required />
                                                        </div>
                                                        <div class="form-group col-lg-12 clockpicker" data-autoclose="true">
                                                            <label>End Time</label>
                                                            <input id="edit_shift_end_time" type="text"  class="form-control" name="shift_e_time" required />
                                                        </div>
                                                        <button id="update-edit-shift" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit shift modal -->

    <!--- Add Schedule modal -->

    <div class="modal fade" id="add_schedule_modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form id="add-schedule-form" method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Teacher Name</label>
                                                            <select id="teacher-schedule-name" class="form-control m-b" name="teacher_id">
                                                                <option></option>
                                                                <?php
                                                                $this->load->model('Admin_model'); 
                                                                $all_teachers = $this->Admin_model->get_all_teachers();
                                                                foreach($all_teachers as $teacher){
                                                                ?>
                                                                <option value="<?php echo $teacher['id'];?>"><?php echo $teacher['name']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>        
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Student Name</label>
                                                            <select id="schedule-student-id" class="form-control m-b" name="student_id" disabled="disabled">
                                                                <option></option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Day</label>
                                                            <select  id="schedule-day" class="form-control m-b js-source-day" multiple="multiple" name="day" disabled="disabled">
                                                                <option value=""> </option>
                                                                <option value="Monday">Monday</option>
                                                                <option value="Tuesday">Tuesday</option>
                                                                <option value="Wednesday">Wednesday</option>
                                                                <option value="Thursday">Thursday</option>
                                                                <option value="Friday">Friday</option>
                                                                <option value="Saturday">Saturday</option>
                                                                <option value="Sunday">Sunday</option>
                                                            </select>
                                                        </div>                                                    
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label >Time</label>
                                                            <select id="schedule-time" class="form-control m-b" name="time" disabled="disabled">
                                                                <option value=""> </option>
                                                                <option value="12:00 AM">12:00 AM</option>
                                                                <option value="12:30 AM">12:30 AM</option>
                                                                <option value="01:00 AM">01:00 AM</option>
                                                                <option value="01:30 AM">01:30 AM</option>
                                                                <option value="02:00 AM">02:00 AM</option>
                                                                <option value="02:30 AM">02:30 AM</option>
                                                                <option value="03:00 AM">03:00 AM</option>
                                                                <option value="03:30 AM">03:30 AM</option>
                                                                <option value="04:00 AM">04:00 AM</option>                    
                                                                <option value="04:30 AM">04:30 AM</option>
                                                                <option value="05:00 AM">05:00 AM</option>
                                                                <option value="05:30 AM">05:30 AM</option>
                                                                <option value="06:00 AM">06:00 AM</option>
                                                                <option value="06:30 AM">06:30 AM</option>
                                                                <option value="07:00 AM">07:00 AM</option>
                                                                <option value="07:30 AM">07:30 AM</option>
                                                                <option value="08:00 AM">08:00 AM</option>
                                                                <option value="08:30 AM">08:30 AM</option>
                                                                <option value="09:00 AM">09:00 AM</option>
                                                                <option value="09:30 AM">09:30 AM</option>
                                                                <option value="10:00 AM">10:00 AM</option>
                                                                <option value="10:30 AM">10:30 AM</option>
                                                                <option value="11:00 AM">11:00 AM</option>
                                                                <option value="11:30 AM">11:30 AM</option>
                                                                <option value="12:00 PM">12:00 PM</option>
                                                                <option value="12:30 PM">12:30 PM</option>
                                                                <option value="01:00 PM">01:00 PM</option>
                                                                <option value="01:30 PM">01:30 PM</option>
                                                                <option value="02:00 PM">02:00 PM</option>
                                                                <option value="02:30 PM">02:30 PM</option>
                                                                <option value="03:00 PM">03:00 PM</option>
                                                                <option value="03:30 PM">03:30 PM</option>
                                                                <option value="04:00 PM">04:00 PM</option>
                                                                <option value="04:30 PM">04:30 PM</option>
                                                                <option value="05:00 PM">05:00 PM</option>
                                                                <option value="05:30 PM">05:30 PM</option>
                                                                <option value="06:00 PM">06:00 PM</option>
                                                                <option value="06:30 PM">06:30 PM</option>
                                                                <option value="07:00 PM">07:00 PM</option>
                                                                <option value="07:30 PM">07:30 PM</option>
                                                                <option value="08:00 PM">08:00 PM</option>
                                                                <option value="08:30 PM">08:30 PM</option>
                                                                <option value="09:00 PM">09:00 PM</option>
                                                                <option value="09:30 PM">09:30 PM</option>
                                                                <option value="10:00 PM">10:00 PM</option>
                                                                <option value="10:30 PM">10:30 PM</option>
                                                                <option value="11:00 PM">11:00 PM</option>
                                                                <option value="11:30 PM">11:30 PM</option>
                                                                <option value="49">N-A</option>
                                                            </select>
                                                        </div>
                                                        <!--<div class="form-group col-lg-6 no-gap">
                                                            <label>Student Zone</label>
                                                            <select class="form-control m-b" name="student_zone">
                                                                <option value=""> </option>                                                            <option value="monday">Monday</option>
                                                                <option value="tuesday">Tuesday</option>
                                                                <option value="wednesday">Wednesday</option>
                                                                <option value="thursday">Thursday</option>
                                                                <option value="friday">Friday</option>
                                                                <option value="saturday">Saturday</option>
                                                                <option value="sunday">Sunday</option>
                                                            </select>
                                                        </div>    
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label >Course</label>
                                                            <select class="form-control m-b" name="course">
                                                                <option></option>
                                                                <?php
                                                                   // $this->load->model('Admin_model'); 
                                                                   // $all_courses = $this->Admin_model->get_all_courses();
                                                                   // foreach($all_courses as $course){
                                                                ?>
                                                                <option value="<?php //echo $course['id'];?>"><?php //echo $course['name']; ?></option>
                                                                <?php //} ?>
                                                            </select>                                
                                                        </div> -->
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-schedule" class="btn btn-info" type="submit">Save</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end Add Schedule modal -->

    <!--- Add class_remarks modal -->

    <div class="modal fade" id="class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="lesson_teach"  type="text"  class="form-control" name="lesson_teach" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Class Remaks</label>
                                                            <textarea id="class_remarks" type="text"  class="form-control" name="class_remarks" required /></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-class-remarks" class="btn btn-info" type="submit">Save</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end Add class remarks modal -->

    <!--- Add class assign teacher modal -->

    <div class="modal fade" id="class_teacher_assign" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="assign_teacher_class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Teacher Name</label>
                                                            <select id="class-assign-teacher" class="form-control" name="manager" />
                                                                <option></option>
                                                                <?php
                                                                $this->load->model('Admin_model'); 
                                                                $all_teachers = $this->Admin_model->get_all_teachers();
                                                                foreach($all_teachers as $teacher){?>
                                                                <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="assign-teacher" class="btn btn-info" type="submit">Assign</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end assign teacher modal -->

    <!--- view class_remarks modal -->

    <div class="modal fade" id="view_class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="view_lesson_teach"  type="text"  class="form-control" name="lesson_teach" disabled />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap" style="padding-top: 26px;">
                                                            <label>Class Remaks</label>
                                                            <textarea id="view_class_end_remarks" type="text"  class="form-control" name="class_remarks" disabled /></textarea>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end view class remarks modal -->

    <!--- Add class_reschedule modal -->

    <div class="modal fade" id="class_reschedule" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_reschedule_id" type="hidden" class="form-control" value="">
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Date</label>
                                                            <div class="input-group">
                                                                <input id="class_reschedule_date" type="text" class="form-control"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                            </div>  
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap" style="padding-top: 20px;">
                                                            <label>Time</label>
                                                            <input  type="text"  class="form-control class_reschedule_clockpicker" name="class_reschedule_time" required />
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4 mt-top-cus">
                                                                <button id="add-class-reschedule" class="btn btn-info" type="submit">Save</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end class_reschedule modal -->

    <!--- change teacher password modal -->

    <div class="modal fade" id="change_teacher_password" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="update_pass_teacher_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12">
                                                            <label>New Password</label>
                                                            <input id="teacher_new_pass"  type="password"  class="form-control" name="teacher_new_pass" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12">
                                                            <label>Confirm New Password</label>
                                                            <input id="teacher_confirm_new_pass"  type="password"  class="form-control" name="teacher_confirm_new_pass" required />
                                                        </div> 
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="update-teacher-password" class="btn btn-info" type="submit">Update</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end change teacher password  modal -->

    <!--- change manager password modal -->

    <div class="modal fade" id="change_manager_password" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="update_pass_manager_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12">
                                                            <label>New Password</label>
                                                            <input id="manager_new_pass"  type="password"  class="form-control" name="manager_new_pass" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12">
                                                            <label>Confirm New Password</label>
                                                            <input id="manager_confirm_new_pass"  type="password"  class="form-control" name="manager_confirm_new_pass" required />
                                                        </div> 
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="update-manager-password" class="btn btn-info" type="submit">Update</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end change manager password  modal -->

    <!--- change parent password modal -->

    <div class="modal fade" id="change_parent_password" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="update_pass_parent_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12">
                                                            <label>New Password</label>
                                                            <input id="parent_new_pass"  type="password"  class="form-control" name="parent_new_pass" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12">
                                                            <label>Confirm New Password</label>
                                                            <input id="parent_confirm_new_pass"  type="password"  class="form-control" name="parent_confirm_new_pass" required />
                                                        </div> 
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="update-parent-password" class="btn btn-info" type="submit">Update</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end change parent password  modal -->

    <!--- change parent status modal -->

    <div class="modal fade" id="change_parent_status" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="update_status_parent_id"  type="hidden" placeholder="Enter Your Name">
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <select id="parent_new_status" class="form-control" name="parent_new_status" required="">
                                                                <option></option>
                                                                <option value="active">Active</option>
                                                                <option value="deactive">Deactive</option>
                                                            </select>
                                                        </div>  
                                                        <!--<br>
                                                        <div id="parent_holiday_start_date" class="form-group col-lg-12">
                                                            <label>Start Date</label>
                                                            <div class="input-group date">
                                                              <input id="holiday_start_date" type="text" class="form-control"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                            </div>  
                                                        </div>  
                                                        <br>  
                                                        <div id="parent_holiday_end_date" class="form-group col-lg-12">
                                                            <label>End Date</label>
                                                            <div class="input-group date">
                                                              <input id="holiday_end_date" type="text" class="form-control"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                            </div>
                                                        </div>  -->
                                                        <br>     
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="update-parent-status" class="btn btn-info" type="submit">Update</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end change parent status  modal -->

    <!--- change student status modal -->

    <div class="modal fade" id="change_student_status" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="update_status_student_id"  type="hidden">
                                                        <input id="update_status_parent_id"  type="hidden">
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <select id="student_new_status" class="form-control" name="parent_new_status" required="">
                                                                <option></option>
                                                                <option value="active">Active</option>
                                                                <option value="deactive">Deactive</option>
                                                                <option value="trial">Trial</option>
                                                                <option value="holiday">On Holiday</option>
                                                                <option value="leaved">Leaved</option>
                                                                <option value="completed">Completed</option>
                                                            </select>
                                                        </div>  
                                                        <br>
                                                        <div class="form-group col-lg-12">
                                                            <label>Start Date</label>
                                                            <div class="input-group">
                                                                <input id="student_holiday_start_date" type="text" class="form-control"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                            </div>  
                                                        </div>  
                                                        <br>  
                                                        <div class="form-group col-lg-12">
                                                            <label>End Date</label>
                                                            <div class="input-group">
                                                              <input id="student_holiday_end_date" type="text" class="form-control"><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                                                            </div>
                                                        </div>  
                                                        <br>     
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="update-student-status" class="btn btn-info" type="submit">Update</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end change student status  modal -->


    <!--- edit country modal -->

    <div class="modal fade" id="edit_country" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_country_id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Country Name</label>
                                                            <input id="edit_country_name" type="text"  class="form-control" name="country_name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12" >
                                                            <label>Code</label>
                                                            <input id="edit_country_code" type="text"  class="form-control" name="country_code" required />
                                                        </div>
                                                        <div class="form-group col-lg-12" >
                                                            <label>Currency</label>
                                                            <input id="edit_country_currency" type="text"  class="form-control" name="country_currency" required />
                                                        </div>
                                                        <button id="update-edit-country" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit country modal -->

    <!--- edit student modal -->

    <div class="modal fade" id="edit_student" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_student_id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Student Name</label>
                                                            <input id="edit_student_name" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Skype ID</label>
                                                            <input id="edit_student_skype_id" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Age</label>
                                                            <input id="edit_student_age" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Gender</label>
                                                            <select id="edit_student_gender" class="form-control" name="student-gender[]" required="">
                                                                <option></option>
                                                                <option value="male">Male</option>
                                                                <option value="female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <select id="edit_student_course" class="form-control" name="course[]">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                                    foreach($all_courses as $course){?>
                                                                        <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                                    <?php } ?>  
                                                            </select>
                                                        </div>
                                                        <!--<div class="form-group col-lg-12">
                                                            <label>Number of Days</label>
                                                            <select id="edit_student_days" class="form-control" name="days" required />
                                                                <option></option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                        </div> -->
                                                        <div class="form-group col-lg-12">
                                                            <p><strong>Days</strong></p>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="mon-day[]" value="mon">
                                                                <label for="editstudentdays">Mon</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="tues-day[]" value="tues">
                                                                <label for="editstudentdays">Tues</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="wed-day[]" value="wed">
                                                                <label for="editstudentdays">Wed</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="thur-day[]" value="thur">
                                                                <label for="editstudentdays">Thur</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="fri-day[]" value="fri">
                                                                <label for="editstudentdays">Fri</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="sat-day[]" value="sat">
                                                                <label for="editstudentdays">Sat</label>
                                                            </div>
                                                            <div class="checkbox checkbox-inline">
                                                                <input type="checkbox" id="editstudentdays" name="sun-day[]" value="sun">
                                                                <label for="editstudentdays">Sun</label>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Manager</label>
                                                            <select id="edit_student_manager" class="form-control" name="student-manager[]" required />
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_managers = $this->Admin_model->get_all_managers();
                                                                    foreach($all_managers as $manager){?>
                                                                    <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Teacher</label>
                                                            <select id="edit_student_teacher" class="form-control" name="student-teacher[]" required />
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_teachers = $this->Admin_model->get_all_teachers();
                                                                    foreach($all_teachers as $teacher){?>
                                                                    <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <select id="edit_student_status" class="form-control" name="status" required />
                                                                <option></option>
                                                                <option value="active">Active</option>
                                                                <option value="deactive">Deactive</option>
                                                                <option value="trial">Trial</option>
                                                                <option value="holiday">On Holiday</option>
                                                                <option value="leaved">Leaved</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Trial Class Remarks</label>
                                                            <textarea id="edit_student_trial_remarks" class="form-control" name="trial-class-remarks[]"></textarea>
                                                        </div>
                                                        <button id="update-edit-student" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit student modal -->

    <!--- student view modal -->
    <div class="modal fade" id="view_student" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <h2>Student Profile</h2>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table class="table table-user-information">
                                            <tbody>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td id="view-student-name"></td>
                                                </tr>
                                                <tr>
                                                    <td>Age:</td>
                                                    <td id="view-student-age"></td>
                                                </tr>
                                                <tr>
                                                    <td>Gender:</td>
                                                    <td id="view-student-gender"></td>
                                                </tr>
                                                <tr>
                                                    <td>Course:</td>
                                                    <td id="view-student-course"></td>
                                                </tr>
                                                <tr>
                                                    <td>Number of Days:</td>
                                                    <td id="view-student-days"></td>
                                                </tr>
                                                <tr>
                                                    <td>Status:</td>
                                                    <td id="view-student-status"></td>
                                                </tr>
                                                <tr>
                                                    <td>Skype ID:</td>
                                                    <td id="view-student-skype"></td>
                                                </tr>
                                                <tr>
                                                    <td>Trial Class Remarks</td>
                                                    <td id="view-student-trial-class"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end student view modal -->

    

    <!--- edit student modal -->

    <div class="modal fade" id="edit_invoice" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_invoice_id" type="hidden"  class="form-control" name="invoice_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Parent Name</label>
                                                            <select id="edit_invoice-parent-id" class="form-control m-b" name="invoiced-parent-id" required="required" disabled="disabled" >
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_parents = $this->Admin_model->get_no_invoiced_parents();
                                                                    foreach($all_parents as $parent){?>
                                                                        <option value="<?php echo $parent['id']?>"><?php echo $parent['name']?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Month</label>
                                                            <select id="edit_invoice-month" class="form-control" name="month" required disabled="disabled" />
                                                                <option></option>
                                                                <option value="1">January</option>
                                                                <option value="2">February</option>
                                                                <option value="3">March</option>
                                                                <option value="4">April</option>
                                                                <option value="5">May</option>
                                                                <option value="6">June</option>
                                                                <option value="7">July</option>
                                                                <option value="8">August</option>
                                                                <option value="9">September</option>
                                                                <option value="10">October</option>
                                                                <option value="11">November</option>
                                                                <option value="12">December</option>
                                                            </select>
                                                        </div>
                                                        
                                                        <div class="form-group col-lg-12">
                                                            <label>Year</label>
                                                            <select id="edit_invoice-year" class="form-control m-b" name="invoiced-year" required="required" disabled="disabled" >
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_years = $this->Admin_model->get_all_years();
                                                                    foreach($all_years as $year){?>
                                                                        <option value="<?php echo $year['year']?>"><?php echo $year['year']?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Amount</label>
                                                            <input id="edit_invoice-amount" type="text"  class="form-control" name="invoice-amount" required  disabled="disabled"/>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Adjustment</label>
                                                            <input id="edit_invoice-adjustment" type="text" name="invoice-adjustment"  class="form-control" />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Due Date</label>
                                                            <input id="edit_invoice-due-date" type="text"  class="form-control" name="invoice-due-date" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <select id="edit_invoice-status" class="form-control" name="month" required />
                                                                <option></option>
                                                                <option value="Pending">Pending</option>
                                                                <option value="Paid">Paid</option>
                                                                <option value="Over Due">Over Due</option>
                                                            </select>
                                                        </div>
                                                        <button id="update-edit-invoice" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit student modal -->

    <!--- add student modal -->

    <div class="modal fade" id="add_student" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form id="add-pstudent" method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="record-parent-id"  type="hidden"  class="form-control" name="record-student-parent_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Student Name</label>
                                                            <input  type="text"  class="form-control" name="record-student-name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Skype ID</label>
                                                            <input  type="text"  class="form-control" name="record-student-skype" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Age</label>
                                                            <input  type="text"  class="form-control" name="record-student-age" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Gender</label>
                                                            <select  class="form-control" name="record-student-gender" required="">
                                                                <option></option>
                                                                <option value="male">Male</option>
                                                                <option value="female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <select class="form-control" name="record-student-course">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                                    foreach($all_courses as $course){?>
                                                                        <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                                    <?php } ?>  
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Manager</label>
                                                            <select class="form-control" name="record-student-manager" required />
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_managers = $this->Admin_model->get_all_managers();
                                                                    foreach($all_managers as $manager){?>
                                                                    <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Teacher</label>
                                                            <select class="form-control" name="record-student-teacher" required />
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_teachers = $this->Admin_model->get_all_teachers();
                                                                    foreach($all_teachers as $teacher){?>
                                                                    <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                                                <?php } ?> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Number of Days</label>
                                                            <!--<input type="text"  class="form-control" name="days" required />-->
                                                            <select class="form-control" name="record-student-days" required />
                                                                <option></option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>

                                                        </div>
                                                        <!--<div class="form-group col-lg-12">
                                                            <label>Fee</label>
                                                            <input type="text"  class="form-control" name="record-student-fee" required />
                                                        </div>-->
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <select class="form-control" name="record-student-status" required />
                                                                <option></option>
                                                                <option value="active">Active</option>
                                                                <option value="deactive">Deactive</option>
                                                                <option value="trial">Trial</option>
                                                                <option value="holiday">On Holiday</option>
                                                                <option value="leaved">Leaved</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Trial Class Remarks</label>
                                                            <textarea class="form-control" name="record-student-trial-class-remarks"></textarea>
                                                        </div>
                                                        <button id="add-student-record" type="submit" class="btn btn-info">Add</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div>   
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end add student modal -->

    
    <!-- Right sidebar -->
    <!--<div id="right-sidebar" class="animated fadeInRight">

        <div class="p-m">
            <button id="sidebar-close" class="right-sidebar-toggle sidebar-button btn btn-default m-b-md"><i class="pe pe-7s-close"></i>
            </button>
            <div>
                <span class="font-bold no-margins"> Analytics </span>
                <br>
                <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.</small>
            </div>
            <div class="row m-t-sm m-b-sm">
                <div class="col-lg-6">
                    <h3 class="no-margins font-extra-bold text-success">300,102</h3>

                    <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                </div>
                <div class="col-lg-6">
                    <h3 class="no-margins font-extra-bold text-success">280,200</h3>

                    <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                </div>
            </div>
            <div class="progress m-t-xs full progress-small">
                <div style="width: 25%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="25" role="progressbar"
                     class=" progress-bar progress-bar-success">
                    <span class="sr-only">35% Complete (success)</span>
                </div>
            </div>
        </div>
        <div class="p-m bg-light border-bottom border-top">
            <span class="font-bold no-margins"> Social talks </span>
            <br>
            <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.</small>
            <div class="m-t-md">
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a1.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">John Novak</span>
                            <small class="text-muted">21.03.2015</small>
                            <div class="social-content small">
                                Injected humour, or randomised words which don't look even slightly believable.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a3.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">Mark Smith</span>
                            <small class="text-muted">14.04.2015</small>
                            <div class="social-content">
                                Many desktop publishing packages and web page editors.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a4.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">Marica Morgan</span>
                            <small class="text-muted">21.03.2015</small>

                            <div class="social-content">
                                There are many variations of passages of Lorem Ipsum available, but the majority have
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-m">
            <span class="font-bold no-margins"> Sales in last week </span>
            <div class="m-t-xs">
                <div class="row">
                    <div class="col-xs-6">
                        <small>Today</small>
                        <h4 class="m-t-xs">$170,20 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                    <div class="col-xs-6">
                        <small>Last week</small>
                        <h4 class="m-t-xs">$580,90 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <small>Today</small>
                        <h4 class="m-t-xs">$620,20 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                    <div class="col-xs-6">
                        <small>Last week</small>
                        <h4 class="m-t-xs">$140,70 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                </div>
            </div>
            <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.
                Many desktop publishing packages and web page editors.
            </small>
        </div>-->
    </div>

    <!-- Footer-->
    <!--<footer class="footer">
        <span class="pull-right">
            Example text
        </span>
        Company 2015-2020
    </footer> -->

</div>

<!-- Vendor scripts -->
<script src="<?php echo base_url()?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>public/js/curvedLines.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/metisMenu.min.js"></script>
<script src="<?php echo base_url()?>public/js/icheck.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.peity.min.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/moment.min.js"></script>
<script src="<?php echo base_url()?>public/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url()?>public/js/toastr.min.js"></script>
<script src="<?php echo base_url()?>public/js/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap-clockpicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<!-- App scripts -->
<script src="<?php echo base_url()?>public/js/homer.js"></script>
<script src="<?php echo base_url()?>public/js/charts.js"></script>
<script src="<?php echo base_url()?>public/js/admin/app.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url()?>public/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>
<script src="http://responsiweb.com/themes/preview/ace/1.4/dist/js/ace-extra.min.js"></script>
<script>

    $(function () {

        // Initialize Example 2

        $('#manager-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#teacher-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_teachers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Teacher Name" },
                { "data": "Email" },
                { "data": "Username" },
                { "data": "No of Student" },
                { "data": "Shift" },
                { "data": "Gender" },
                { "data": "Skype ID" },
                {"data": "Skype Password"},
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#parent-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_parents",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Phone" },
                { "data": "Mobile" },
                { "data": "Skype" },
                { "data": "Country" },
                { "data": "Username" },
                { "data": "Manager" },
                { "data": "Students" },
                { "data": "Fee" },
                { "data": "Fee Date" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#complaint-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_complaints",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Student Name" },
                { "data": "Parent Name" },
                { "data": "Teacher Name" },
                { "data": "Complaint" },
                { "data": "Remarks" },
                { "data": "Status" },
                { "data": "Actions" }
            ],
        });

        $('#student-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_students",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Fathername" },
                { "data": "Schedule" },
                { "data": "Country" },
                { "data": "Gender" },
                { "data": "Course" },
                { "data": "Class Records" },
                { "data": "Teacher" },
                { "data": "Manager" },
                { "data": "Actions" },
                { "data": "Schedule_check" }
            ],
            "aoColumnDefs": [ 
                { "sClass": "hide_me", "aTargets": [ 11 ] },
                { "sClass": "action", "aTargets": [ 10 ] }
            ],
            "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
                switch(aData['Schedule_check']){
                    case 'No':
                        $(nRow).css('background-color', '#d8cbb4')
                        break;    
                }
            }
        });

        $('#invoices-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_invoices",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Invoice Type" },
                { "data": "Month Year" },
                { "data": "Fee Amt" },
                { "data": "Fee Adj" },
                { "data": "Full Amt" },
                { "data": "Due Date" },
                { "data": "Inv SaleNo" },
                { "data": "Status" },
                { "data": "Fee Type" },
                { "data": "Actions" }
            ],
            "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
                switch(aData['Status']){
                    case 'Paid':
                        $(nRow).css('background-color', '#62cb31')
                        break;
                    case 'Over Due':
                        $(nRow).css('background-color', '#e74c3c')
                        break;    
                }
            }
        });                                                


        $('#course-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#all-course-book-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_course_books",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Book Name" },
                { "data": "Course" },
                { "data": "Chap Nums" },
                { "data": "Total Pages" },
                { "data": "Actions" }
            ],
        });

        $('#year-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_years",
                "type": "POST"
            },
            "columns": [
                { "data": "No" },
                { "data": "School Year" },
                { "data": "Actions" }
            ],
        });
        $('#shift-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_shifts",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Shift" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Actions" }
            ],
        });
        $('#country-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_countires",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Country" },
                { "data": "Code" },
                { "data": "Currency" },
                { "data": "Actions" }
            ],
        });

        $('#classes-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/today_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "History" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
                { "data": "Actions"},
            ],  

            "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
                switch(aData['Status']){
                    case 'Taken':
                        $(nRow).css('background-color', '#62cb31')
                        break;
                    case 'Started':
                        $(nRow).css('background-color', '#ffb606')
                        break;
                    //case 'Teacher Leave':
                        //$(nRow).css('background-color', '#e74c3c')
                       // break;
                    case 'Student Leave':
                        $(nRow).css('background-color', '#e74c3c')
                        break;    
                }
            }
        });

        $('#all-classes-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
            ],
        });

        $('#classes-history-table').dataTable({
            //"processing": true,
            //"serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/classes_history",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Lesson" },
                { "data": "Remarks" },
                { "data": "Status" },
            ],
        });

        // Initialize Example 3
        $('#example3').dataTable();

        // Initialize Example 5
        $('#all-courses-table').dataTable();

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('a[data-toggle="tab"]').removeClass('btn-primary');
            $('a[data-toggle="tab"]').addClass('btn-default');
            $(this).removeClass('btn-default');
            $(this).addClass('btn-primary');
        })

        $('.next').click(function(){
            var nextId = $(this).parents('.tab-pane').next().attr("id");
            $('[href=#'+nextId+']').tab('show');
        })

        $('.prev').click(function(){
            var prevId = $(this).parents('.tab-pane').prev().attr("id");
            $('[href=#'+prevId+']').tab('show');
        })

        $('.submitWizard').click(function(){

            var approve = $(".approveCheck").is(':checked');
            
                // Got to step 1
                $('[href=#step1]').tab('show');

                // Serialize data to post method
                var datastring = $("#simpleForm").serialize();
                
                // Show notification
                swal({
                    title: "Thank you!",
                    text: "You approved our example form!",
                    type: "success"
                });
        });

        $('.clockpicker').clockpicker({autoclose: true});
        $('#student_holiday_start_date').datepicker({ dateFormat : 'dd, MM, yy'});
        $('#student_holiday_end_date').datepicker({ dateFormat : 'dd, MM, yy'});
        $('#class_reschedule_date').datepicker({ dateFormat : 'dd, MM, yy'});
        $('.class_reschedule_clockpicker').clockpicker({autoclose: true});
    });

</script>
<script>

    $(document).ready(function(){
        $('.j_all-parent').click(function(){
            $('.j_all-parent').removeClass('active');
            $(this).addClass('active');
            $(this).closest('body').find('.common-class').removeClass('active');
            var OpenTabDiv = $(this).attr('data-tab');
            $(this).closest('body').find('.'+OpenTabDiv).addClass('active'); 
        });

    });

</script>
<script>
        //setup before functions
        var typingTimer;                //timer identifier
        var doneTypingInterval = 1000;  //time in ms, 5 second for example

        //on keyup, start the countdown
        $('input[name="manager_username"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="manager_username"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_manager_username",
                data: 'username=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="manager_username"]').parent().addClass('has-error');
                        $('input[name="manager_username"]').after("<span style='color:red;'>This Username Already Exist</span>");
                        $('button#add-new-manager').attr('disabled','disabled');
                      }else{
                        $('input[name="manager_username"]').parent().removeClass('has-error');
                        $('input[name="manager_username"]').next("span").remove();
                        $('button#add-new-manager').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="manager_username"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //on keyup, start the countdown
        $('input[name="manager_email"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="manager_email"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_manager_email",
                data: 'username=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="manager_email"]').parent().addClass('has-error');
                        $('input[name="manager_email"]').after("<span style='color:red;'>This Email Already Exist</span>");
                        $('button#add-new-manager').attr('disabled','disabled');
                      }else{
                        $('input[name="manager_email"]').parent().removeClass('has-error');
                        $('input[name="manager_email"]').next("span").remove();
                        $('button#add-new-manager').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="manager_email"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //on keyup, start the countdown
        $('input[name="manager_cnic"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="manager_cnic"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_manager_cnic",
                data: 'cnic=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="manager_cnic"]').parent().addClass('has-error');
                        $('input[name="manager_cnic"]').after("<span style='color:red;'>This CNIC Already Exist</span>");
                        $('button#add-new-manager').attr('disabled','disabled');
                      }else{
                        $('input[name="manager_cnic"]').parent().removeClass('has-error');
                        $('input[name="manager_cnic"]').next("span").remove();
                        $('button#add-new-manager').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="teacher_username"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //on keyup, start the countdown
        $('input[name="teacher_username"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="teacher_username"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_teacher_username",
                data: 'username=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="teacher_username"]').parent().addClass('has-error');
                        $('input[name="teacher_username"]').after("<span style='color:red;'>This Username Already Exist</span>");
                        $('button#add-new-teacher').attr('disabled','disabled');
                      }else{
                        $('input[name="teacher_username"]').parent().removeClass('has-error');
                        $('input[name="teacher_username"]').next("span").remove();
                        $('button#add-new-teacher').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="teacher_username"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //on keyup, start the countdown
        $('input[name="teacher_email"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="teacher_email"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_teacher_email",
                data: 'email=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="teacher_email"]').parent().addClass('has-error');
                        $('input[name="teacher_email"]').after("<span style='color:red;'>This Email Already Exist</span>");
                        $('button#add-new-teacher').attr('disabled','disabled');
                      }else{
                        $('input[name="teacher_email"]').parent().removeClass('has-error');
                        $('input[name="teacher_email"]').next("span").remove();
                        $('button#add-new-teacher').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="teacher_email"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //on keyup, start the countdown
        $('input[name="teacher_cnic"]').on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(function() {
            var st = $('input[name="teacher_cnic"]').val();
            $.ajax({
                type: "POST",
                url: "https://learnquraan.co.uk/ci/index.php/admin/check_teacher_cnic",
                data: 'cnic=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('input[name="teacher_cnic"]').parent().addClass('has-error');
                        $('input[name="teacher_cnic"]').after("<span style='color:red;'>This CNIC Already Exist</span>");
                        $('button#add-new-teacher').attr('disabled','disabled');
                      }else{
                        $('input[name="teacher_cnic"]').parent().removeClass('has-error');
                        $('input[name="teacher_cnic"]').next("span").remove();
                        $('button#add-new-teacher').removeAttr('disabled');
                      }
                }
            });
        }, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $('input[name="teacher_cnic"]').on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //function to initialize select2
        function initializeSelect2(selectElementObj) {
            selectElementObj.select2({
                width: "80%",
                tags: true
            });
        }

        //onload: call the above function 
        $(".js-example-basic-multiple").each(function() {
            initializeSelect2($(this));
        });

        $('#datapicker2').datepicker();

        $('#historydate').datepicker();


    </script>

</body>
</html>
