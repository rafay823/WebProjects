
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>LEARN QURAN | Admin Panel</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/metisMenu.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.print.css" media='print'/>
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/sweet-alert.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap-clockpicker.min.css" />


    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/helper.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/style.css">
    <style>
        .parent-content {
        padding: 20px;
        width: 100%;
        }
        .parent-table {
            padding: 20px;
            width: 100%;
            }
        .common-class {
            display: none;
            }
        .common-class.active {
            display: block;
            width: 100%;
            }

        .no-gap {
            margin: 0 !important;
        }

        .double-pad-top {
            padding-top: 20px;
        }
        .no-border {
            border: 0 none !important;
        }

        .hpanel table th {
          background: #3f5872 none repeat scroll 0 0;
          color: #fff;
        }

        .hpanel table tr td:first-child {
          width: 100px;
        }

        .hpanel table tr td {
          width: 200px;
        }

        .table-box {
            background: #0486ca none repeat scroll 0 0;
            color: #fff;
            font-size: 12px;
            line-height: 15px;
            position: relative;
            text-align: center;
        }

        .table-box p {
            margin-top: 10px;
        }

        .close-btn {
          color: #fff !important;
          cursor: pointer;
          float: right;
          font-size: 12px;
          padding: 2px 5px;
          position: absolute;
          right: 0;
          text-align: right;
          top: 0;
        }


    </style>

</head>
<body class="fixed-navbar fixed-sidebar relative">

<!-- Simple splash screen-->
<div class="splash"> <div class="color-line"></div><div class="splash-title"><h1>Learn Quran Academy</h1><div class="spinner"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div> </div> </div>
<!--[if lt IE 7]>
<p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<!-- Header -->
<div id="header">
    <div class="color-line">
    </div>
    <div id="logo" class="light-version">
        <span>
            Learn Quran
        </span>
    </div>
    <nav role="navigation">
        <div class="header-link hide-menu"><i class="fa fa-bars"></i></div>
        <div class="small-logo">
            <span class="text-primary">HOMER APP</span>
        </div>
        <!--<form role="search" class="navbar-form-custom" method="post" action="#">
            <div class="form-group">
                <input type="text" placeholder="Search something special" class="form-control" name="search">
            </div>
        </form> -->
        <div class="mobile-menu">
            <button type="button" class="navbar-toggle mobile-menu-toggle" data-toggle="collapse" data-target="#mobile-collapse">
                <i class="fa fa-chevron-down"></i>
            </button>
            <div class="collapse mobile-navbar" id="mobile-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="" href="login.html">Login</a>
                    </li>
                    <li>
                        <a class="" href="login.html">Logout</a>
                    </li>
                    <li>
                        <a class="" href="profile.html">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar-right">
            <ul class="nav navbar-nav no-borders">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-speaker"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown notification animated flipInX">
                        <li>
                            <a>
                                <span class="label label-success">NEW</span> It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-warning">WAR</span> There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-danger">ERR</span> Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See all notifications</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-keypad"></i>
                    </a>

                    <div class="dropdown-menu hdropdown bigmenu animated flipInX">
                        <table>
                            <tbody>
                            <tr>
                                <td>
                                    <a href="projects.html">
                                        <i class="pe pe-7s-portfolio text-info"></i>
                                        <h5>Projects</h5>
                                    </a>
                                </td>
                                <td>
                                    <a href="mailbox.html">
                                        <i class="pe pe-7s-mail text-warning"></i>
                                        <h5>Email</h5>
                                    </a>
                                </td>
                                <td>
                                    <a href="contacts.html">
                                        <i class="pe pe-7s-users text-success"></i>
                                        <h5>Contacts</h5>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="forum.html">
                                        <i class="pe pe-7s-comment text-info"></i>
                                        <h5>Forum</h5>
                                    </a>
                                </td>
                                <td>
                                    <a href="analytics.html">
                                        <i class="pe pe-7s-graph1 text-danger"></i>
                                        <h5>Analytics</h5>
                                    </a>
                                </td>
                                <td>
                                    <a href="file_manager.html">
                                        <i class="pe pe-7s-box1 text-success"></i>
                                        <h5>Files</h5>
                                    </a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-mail"></i>
                        <span class="label label-success">4</span>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <div class="title">
                            You have 4 new messages
                        </div>
                        <li>
                            <a>
                                It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                Lorem Ipsum is simply dummy.
                            </a>
                        </li>
                        <li>
                            <a>
                                Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See All Messages</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript:;" id="sidebar" class="right-sidebar-toggle">
                        <i class="pe-7s-upload pe-7s-news-paper"></i>
                    </a>
                </li>
                <li class="dropdown">
                    <a id="logout" href="javascript:;">
                        <i class="pe-7s-upload pe-rotate-90"></i>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Navigation -->
<aside id="menu">
    <div id="navigation">
        <div class="profile-picture">
            <a href="javascript:;">
                <img src="<?php echo base_url()?>public/images/profile.jpg" class="img-circle m-b" alt="logo">
            </a>
        </div>

        <ul class="nav" id="side-menu">
            <li class="active">
                <a data-tab="dashboard-tab" href="javascript:;" class="j_all-parent"><span class="nav-label">Dashboard</span></a>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Classes</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="today-classes">Today Classes</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-classes">View All Classes</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Managers</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-manager-tab">View All Managers</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-manager-tab">Add New Managers</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Teachers</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-tech-tab">View All Teachers</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-tech-tab">Add New Teacher</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Parents</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-parent-tab">View All Parents</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-parent-tab">Add New Parent</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Students</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-student-tab">View All Students</a></li>
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="add-parent-tab">Add New Student</a></li> -->
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Invoices</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-parent-tab">Invoices Details</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="send-invoice">Send Invoice</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="instant-invoice">Instant Invoice</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Schedule</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="scheduling">Scheduling</a></li>
                    <!--<li><a href="javascript:;" class="j_all-parent" data-tab="day-two-tab">Day 2</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-three-tab">Day 3</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-four-tab">Day 4</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="day-five-tab">Day 5</a></li> -->
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Courses</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-course-tab">View All Courses</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-course">Add New Course</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Year</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="year-list">Year List</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-year">Add New Year</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Querry</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-course-tab">View All Courses</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-course">Add New Course</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Shifts</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-shift-tab">View All Shifts</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-shift-tab">Add New Shift</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Countries</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="all-country-tab">View All Countries List</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="add-country-tab">Add New Country</a></li>
                </ul>
            </li>
        </ul>
    </div>
</aside>

<!-- Main Wrapper -->
<div id="wrapper">
    <div class="common-outter">
        <div class="common-class dashboard-tab active">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12 text-center m-t-md">
                        <h2>
                            Welcome to Homer Theme
                        </h2>

                        <p>
                            Special <strong>Admin Theme</strong> for small, medium and large webapp with very clean and
                            aesthetic style and feel.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="panel-tools">
                                    <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                                    <a class="closebox"><i class="fa fa-times"></i></a>
                                </div>
                                Dashboard information and statistics
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-3 text-center">
                                        <div class="small">
                                            <i class="fa fa-bolt"></i> Page views
                                        </div>
                                        <div>
                                            <h1 class="font-extra-bold m-t-xl m-b-xs">
                                                226,802
                                            </h1>
                                            <small>Page views in last month</small>
                                        </div>
                                        <div class="small m-t-xl">
                                            <i class="fa fa-clock-o"></i> Data from January
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="text-center small">
                                            <i class="fa fa-laptop"></i> Active users in current month (December)
                                        </div>
                                        <div class="flot-chart" style="height: 160px">
                                            <div class="flot-chart-content" id="flot-line-chart"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 text-center">
                                        <div class="small">
                                            <i class="fa fa-clock-o"></i> Active duration
                                        </div>
                                        <div>
                                            <h1 class="font-extra-bold m-t-xl m-b-xs">
                                                10 Months
                                            </h1>
                                            <small>And four weeks</small>
                                        </div>
                                        <div class="small m-t-xl">
                                            <i class="fa fa-clock-o"></i> Last active in 12.10.2015
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                            <span class="pull-right">
                                  You have two new messages from <a href="">Monica Bolt</a>
                            </span>
                                Last update: 21.05.2015
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-200">
                                <i class="pe-7s-graph1 fa-4x"></i>

                                <h1 class="m-xs">$1 206,90</h1>

                                <h3 class="font-extra-bold no-margins text-success">
                                    All Income
                                </h3>
                                <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit vestibulum.</small>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Users Activity</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-share fa-4x"></i>
                                </div>
                                <div class="m-t-xl">
                                    <h3 class="m-b-xs">210</h3>
                            <span class="font-bold no-margins">
                                Social users
                            </span>

                                    <div class="progress m-t-xs full progress-small">
                                        <div style="width: 55%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="55"
                                             role="progressbar" class=" progress-bar progress-bar-success">
                                            <span class="sr-only">35% Complete (success)</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-6">
                                            <small class="stats-label">Pages / Visit</small>
                                            <h4>7.80</h4>
                                        </div>

                                        <div class="col-xs-6">
                                            <small class="stats-label">% New Visits</small>
                                            <h4>76.43%</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Page Views</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-monitor fa-4x"></i>
                                </div>
                                <div class="m-t-xl">
                                    <h1 class="text-success">860k+</h1>
                            <span class="font-bold no-margins">
                                Social users
                            </span>
                                    <br/>
                                    <small>
                                        Lorem Ipsum is simply dummy text of the printing and <strong>typesetting
                                        industry</strong>. Lorem Ipsum has been.
                                    </small>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Today income</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-cash fa-4x"></i>
                                </div>
                                <div class="clearfix"></div>
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-income-chart"></div>
                                </div>
                                <div class="m-t-xs">

                                    <div class="row">
                                        <div class="col-xs-5">
                                            <small class="stat-label">Today</small>
                                            <h4>$230,00 </h4>
                                        </div>
                                        <div class="col-xs-7">
                                            <small class="stat-label">Last week</small>
                                            <h4>$7 980,60 <i class="fa fa-level-up text-success"></i></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-heading">
                                <div class="panel-tools">
                                    <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                                    <a class="closebox"><i class="fa fa-times"></i></a>
                                </div>
                                Last active
                            </div>
                            <div class="panel-body list">
                                <div class="stats-title pull-left">
                                    <h4>Activity</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-science fa-4x"></i>
                                </div>
                                <div class="m-t-xl">
                                    <span class="font-bold no-margins">
                                        Social users
                                    </span>
                                    <br/>
                                    <small>
                                        Lorem Ipsum is simply dummy text of the printing simply all dummy text. Lorem Ipsum is
                                        simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.
                                    </small>
                                </div>
                                <div class="row m-t-md">
                                    <div class="col-lg-6">
                                        <h3 class="no-margins font-extra-bold text-success">300,102</h3>

                                        <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                                    </div>
                                    <div class="col-lg-6">
                                        <h3 class="no-margins font-extra-bold text-success">280,200</h3>

                                        <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                                    </div>
                                </div>
                                <div class="row m-t-md">
                                    <div class="col-lg-6">
                                        <h3 class="no-margins font-extra-bold ">120,108</h3>

                                        <div class="font-bold">38% <i class="fa fa-level-down"></i></div>
                                    </div>
                                    <div class="col-lg-6">
                                        <h3 class="no-margins font-extra-bold ">450,600</h3>

                                        <div class="font-bold">28% <i class="fa fa-level-down"></i></div>
                                    </div>

                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="panel-tools">
                                    <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                                    <a class="closebox"><i class="fa fa-times"></i></a>
                                </div>
                                Recently active projects
                            </div>
                            <div class="panel-body list">
                                <div class="table-responsive project-list">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>

                                            <th colspan="2">Project</th>
                                            <th>Completed</th>
                                            <th>Task</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><input type="checkbox" class="i-checks" checked></td>
                                            <td>Contract with Zender Company
                                                <br/>
                                                <small><i class="fa fa-clock-o"></i> Created 14.08.2015</small>
                                            </td>
                                            <td>
                                                <span class="pie">1/5</span>
                                            </td>
                                            <td><strong>20%</strong></td>
                                            <td>Jul 14, 2013</td>
                                            <td><a href=""><i class="fa fa-check text-success"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" class="i-checks"></td>
                                            <td>There are many variations of passages
                                                <br/>
                                                <small><i class="fa fa-clock-o"></i> Created 21.07.2015</small>
                                            </td>
                                            <td>
                                                <span class="pie">1/4</span>
                                            </td>
                                            <td><strong>40%</strong></td>
                                            <td>Jul 16, 2013</td>
                                            <td><a href=""><i class="fa fa-check text-navy"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" class="i-checks" checked></td>
                                            <td>Contrary to popular belief
                                                <br/>
                                                <small><i class="fa fa-clock-o"></i> Created 12.06.2015</small>
                                            </td>
                                            <td>
                                                <span class="pie">0.52/1.561</span>
                                            </td>
                                            <td><strong>75%</strong></td>
                                            <td>Jul 18, 2013</td>
                                            <td><a href=""><i class="fa fa-check text-navy"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" class="i-checks"></td>
                                            <td>Gamma project
                                                <br/>
                                                <small><i class="fa fa-clock-o"></i> Created 06.03.2015</small>
                                            </td>
                                            <td>
                                                <span class="pie">226/360</span>
                                            </td>
                                            <td><strong>16%</strong></td>
                                            <td>Jul 22, 2013</td>
                                            <td><a href=""><i class="fa fa-check text-navy"></i></a></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="panel-tools">
                                    <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                                    <a class="closebox"><i class="fa fa-times"></i></a>
                                </div>
                                Activity
                            </div>
                            <div class="panel-body list">

                                <div class="pull-right">
                                    <a href="javascript:;" class="btn btn-xs btn-default">Today</a>
                                    <a href="javascript:;" class="btn btn-xs btn-default">Month</a>
                                </div>
                                <div class="panel-title">Last Activity</div>
                                <small class="fo">This is simple example</small>
                                <div class="list-item-container">
                                    <div class="list-item">
                                        <h3 class="no-margins font-extra-bold text-success">2,773</h3>
                                        <small>Tota Messages Sent</small>
                                        <div class="pull-right font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                                    </div>
                                    <div class="list-item">
                                        <h3 class="no-margins font-extra-bold text-color3">4,422</h3>
                                        <small>Last activity</small>
                                        <div class="pull-right font-bold">13% <i class="fa fa-level-down text-color3"></i></div>
                                    </div>
                                    <div class="list-item">
                                        <h3 class="no-margins font-extra-bold text-color3">9,180</h3>
                                        <small>Monthly income</small>
                                        <div class="pull-right font-bold">22% <i class="fa fa-bolt text-color3"></i></div>
                                    </div>
                                    <div class="list-item">
                                        <h3 class="no-margins font-extra-bold text-success">1,450</h3>
                                        <small>Tota Messages Sent</small>
                                        <div class="pull-right font-bold">44% <i class="fa fa-level-up text-success"></i></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class today-classes">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class all-classes">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="all-classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="common-class all-manager-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="manager-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Skype ID</th>
                                                        <th>Username</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Skype ID</th>
                                                        <th>Username</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-manager-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <form id="add-manager-form" action="javascript:;" method="post">
                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                    <div id="step1" class="p-m tab-pane active">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="form-group col-lg-6">
                                                        <label>Name</label>
                                                        <input type="text" class="form-control" name="manager_name" placeholder="Name" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>CNIC</label>
                                                        <input type="text" class="form-control" name="manager_cnic" placeholder="XXXXX-XXXXXXXXXXX-X" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Address</label>
                                                        <input type="text" class="form-control" name="manager_address" placeholder="Steet,Town,City" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Telephone #</label>
                                                        <input type="text" class="form-control" name="manager_landline" placeholder="" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Mobile #</label>
                                                        <input type="text" class="form-control" name="manager_mobile" placeholder="" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Email Address</label>
                                                        <input type="text" class="form-control" name="manager_email" placeholder="user@email.com" required />
                                                    </div>
                                                </div>
                                                <div class="text-center m-b-md" id="wizardControl">
                                                    <a class="btn btn-primary" data-toggle="tab">Step 2 - Offical Data</a>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-lg-6">
                                                        <label>Username</label>
                                                        <input type="text" class="form-control" name="manager_username" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Password</label>
                                                        <input type="password" class="form-control" name="manager_password" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Skype ID</label>
                                                        <input type="text" class="form-control" name="manager_skype_id" required />
                                                    </div>
                                                    <div class="form-group col-lg-6">
                                                        <label>Salaray Package</label>
                                                        <input type="text" class="form-control" name="manager_sal_pack" required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-right m-t-xs">
                                            <button id="clear-manager-form" class="btn btn-default">Clear</button>
                                            <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                            <button id='add-new-manager' type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </div>    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
        <div class="common-class all-tech-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="teacher-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Teacher Name</th>
                                                        <th>Email</th>
                                                        <th>No. of Student</th>
                                                        <th>Shift</th>
                                                        <th>Gender</th>
                                                        <th>Skype ID</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Teacher Name</th>
                                                        <th>Email</th>
                                                        <th>No. of Student</th>
                                                        <th>Shift</th>
                                                        <th>Gender</th>
                                                        <th>Skype ID</th>
                                                        <th>Password</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_teachers = $this->Admin_model->get_all_teachers();
                                                    foreach($all_teachers as $teacher){?>
                                                        <tr>
                                                            <td><?php echo $teacher['id']?></td>
                                                            <td><?php echo $teacher['name']?></td>
                                                            <td><?php echo $teacher['email']?></td>
                                                            <td></td>
                                                            <td><?php echo $teacher['shift']?></td>
                                                            <td><?php echo $teacher['gender']?></td>
                                                            <td><?php echo $teacher['skype_id']?></td>
                                                            <td><?php echo $teacher['passwrd']?></td>
                                                            <td>
                                                                <button data-id="<?php echo $teacher['id']?>"  data-toggle="modal" data-target="#edit_teacher" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm demo4 delete-teacher" data-id="<?php echo $teacher['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-tech-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <form id="add-teacher-form" action="javascript:;" method="post">
                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Teacher Name</label>
                                                    <input type="" value="" id="" class="form-control" name="teacher_name" placeholder="Teacher Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Father Name</label>
                                                    <input type="" value="" id="" class="form-control" name="father_name" placeholder="Father Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>CNIC</label>
                                                    <input type="text" value="" id="" class="form-control" name="cnic" placeholder="XXXXX-XXXXXXXXXXX-X" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Address</label>
                                                    <input type="text" value="" id="" class="form-control" name="address" placeholder="Steet,Town,City" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Telephone #</label>
                                                    <input type="text" value="" id="" class="form-control" name="landline" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Mobile #</label>
                                                    <input type="text" value="" id="" class="form-control" name="mobile" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Email Address</label>
                                                    <input type="" value="" id="" class="form-control" name="email" placeholder="user@email.com" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Gender</label>
                                                    <select class="form-control" name="gender" required />
                                                        <option></option>
                                                        <option>Male</option>
                                                        <option>Female</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Marital Status</label>
                                                    <select class="form-control" name="martial_status" required />
                                                        <option></option>
                                                        <option>Married</option>
                                                        <option>Single</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Qualification</label>
                                                    <input type="text" value="" id="" class="form-control" name="qualification" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Experience</label>
                                                    <input type="text" value="" id="" class="form-control" name="experience" placeholder="" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Shift</label>
                                                    <select class="form-control" name="shift_id" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_shifts = $this->Admin_model->get_all_shifts();
                                                            foreach($all_shifts as $shift){?>
                                                            <option value="<?php echo $shift['id']?>"><?php echo $shift['shift']?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 2 - Offical Data</a>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Username</label>
                                                    <input type="text" value="" id="" class="form-control" name="username" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Password</label>
                                                    <input type="password" value="" id="" class="form-control" name="password" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Designation</label>
                                                    <input type="text" value="" id="" class="form-control" name="designation" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text" value="" id="" class="form-control" name="skype_id" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Salaray Package</label>
                                                    <input type="text" value="" id="" class="form-control" name="sal_pack" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Interview Remarks</label>
                                                    <textarea id="" class="form-control" name="inter_remarks" ></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-teacher-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-teacher' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <div class="common-class all-parent-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="parent-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Fee</th>
                                                        <th>Email</th>
                                                        <th>Username</th>
                                                        <th>Manager</th>
                                                        <th>Fee Date</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Fee</th>
                                                        <th>Email</th>
                                                        <th>Username</th>
                                                        <th>Manager</th>
                                                        <th>Fee Date</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-parent-tab">
            <div class="content">

            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">

                            <form name="add-parent"  id="add-parent-form" action="javascript:;" method="post">

                                <div class="text-center m-b-md" id="wizardControl">
                                    <a class="btn btn-primary" href="#step4" data-toggle="tab">Step 1 - Personal data</a>
                                </div>
                                <div class="tab-content">
                                <div id="step4" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Parent Name</label>
                                                    <input type="text" class="form-control" name="parent-name" placeholder="Parent Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Email</label>
                                                    <input type="email" class="form-control" name="parent-email" placeholder="user@email.com" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Username</label>
                                                    <input type="text" class="form-control" name="username"  required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Password</label>
                                                    <input type="password" class="form-control" name="password" placeholder="*********" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Telephone</label>
                                                    <input type="text" class="form-control" name="landline" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Mobile</label>
                                                    <input type="text" class="form-control" name="mobile" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text"  class="form-control" name="parent-skype" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Notes</label>
                                                    <input type="text" class="form-control" name="notes" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Manager</label>
                                                    <select class="form-control" name="manager" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_managers = $this->Admin_model->get_all_managers();
                                                            foreach($all_managers as $manager){?>
                                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Country</label>
                                                    <select class="form-control" name="country" required />
                                                        <option></option>
                                                        <?php
                                                        $this->load->model('Admin_model'); 
                                                        $all_countries = $this->Admin_model->get_all_countries();
                                                        foreach($all_countries as $country){?>
                                                            <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                                                    <?php }?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 2 - Student data</a>
                                            </div>    
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Student Name</label>
                                                    <input type="text" class="form-control" name="student-name[]" placeholder="Student Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Skype ID</label>
                                                    <input type="text" class="form-control" name="student-skype[]" placeholder="user@email.com" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Age</label>
                                                    <input type="text" class="form-control" name="student-age[]" placeholder="Company Name" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Gender</label>
                                                    <select class="form-control" name="student-gender[]" required />
                                                        <option></option>
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Course</label>
                                                     <select class="form-control" name="course[]">
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_courses = $this->Admin_model->get_all_courses();
                                                            foreach($all_courses as $course){?>
                                                            <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                        <?php } ?>    
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Number of Days </label>
                                                    <select class="form-control" name="days[]" required />
                                                        <option></option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Manager</label>
                                                    <select class="form-control" name="student-manager[]" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_managers = $this->Admin_model->get_all_managers();
                                                            foreach($all_managers as $manager){?>
                                                            <option value="<?php echo $manager['id']?>"><?php echo $manager['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Teacher</label>
                                                    <select class="form-control" name="student-teacher[]" required />
                                                        <option></option>
                                                        <?php
                                                            $this->load->model('Admin_model'); 
                                                            $all_teachers = $this->Admin_model->get_all_teachers();
                                                            foreach($all_teachers as $teacher){?>
                                                            <option value="<?php echo $teacher['id']?>"><?php echo $teacher['name']?></option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Fee </label>
                                                    <input type="text" class="form-control" name="student-fee[]" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Status</label>
                                                    <input type="text" class="form-control" name="status[]" required />
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Trial Class Remarks</label>
                                                    <textarea class="form-control" name="trial-class-remarks[]"></textarea>
                                                </div>
                                            </div>
                                            <div id="extra-students"></div>
                                            <div class="text-center m-b-md" id="wizardControl">
                                                <a class="btn btn-primary" data-toggle="tab">Step 3 - Payment data</a>
                                            </div>    
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <div class="row">
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee</label>
                                                            <input class="form-control"  type="text" name="fee" required />
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Currency</label>
                                                            <select class="form-control" name="fee-currency" required />
                                                                <option></option>
                                                                <option>USD</option>
                                                                <option>AUD</option>
                                                                <option>EURO</option>
                                                                <option>POUND</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Type</label>
                                                            <select class="form-control" name="fee-type" required />
                                                                <option></option>
                                                                <option>Paypal</option>
                                                                <option>2Checkout</option>
                                                                <option>WU/Bank Account</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-3 form-group">
                                                            <label>Fee Date</label>
                                                            <select class="form-control" name="fee-date" required />
                                                                <option></option>
                                                                <option>1</option>
                                                                <option>15</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-right m-t-xs">
                                        <a class="btn btn-success pull-left" id="add-new-stud-fields">Add new student</a>
                                        <button id="clear-parent-form" class="btn btn-default">Clear</button>
                                        <button id='add-new-parent' type="submit" class="btn btn-success">Submit</button>
                                    </div>

                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <div class="common-class all-student-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_students = $this->Admin_model->get_all_students();
                                                    foreach($all_students as $student){?>
                                                        <tr>
                                                            <td><?php echo $student['id']?></td>
                                                            <td><?php echo $student['name']?></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td><?php echo $student['gender']?></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td>
                                                                <button data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#edit_student" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm delete-student" data-id="<?php echo $student['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class send-invoice">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>Invoices</span>
                                    </li>
                                    <li class="active">
                                        <span>Send Invoice</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Create Invoice
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Month</label>
                                <div class="col-sm-10">
                                    <select class="form-control m-b" name="account">
                                        <option></option>
                                        <option>option 1</option>
                                        <option>option 2</option>
                                        <option>option 3</option>
                                        <option>option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Year</label>
                                <div class="col-sm-10">
                                    <select class="form-control m-b" name="account">
                                        <option></option>
                                        <option>2014</option>
                                        <option>2015</option>
                                        <option>2016</option>
                                        <option>2017</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Fee Date</label>
                                <div class="col-sm-10">
                                    <select class="form-control m-b" name="account">
                                        <option></option>
                                        <option>1</option>
                                        <option>15</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Due Date</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <button class="btn btn-default" type="submit">Cancel</button>
                                    <button class="btn btn-primary" type="submit">Save changes</button>
                                </div>
                            </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class instant-invoice">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>Invoices</span>
                                    </li>
                                    <li class="active">
                                        <span>Instant Invoice</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Send Instant Invoice
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Name</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="account">
                                            <option></option>
                                            <option>Zahik</option>
                                            <option>Umair</option>
                                            <option>Lareb</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Month</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="account">
                                            <option></option>
                                            <option>option 1</option>
                                            <option>option 2</option>
                                            <option>option 3</option>
                                            <option>option 4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Year</label>
                                    <div class="col-sm-10">
                                        <select class="form-control m-b" name="account">
                                            <option></option>
                                            <option>2014</option>
                                            <option>2015</option>
                                            <option>2016</option>
                                            <option>2017</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Due Date</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button class="btn btn-primary" type="submit">Save changes</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class all-course-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="example5" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Course </th>
                                                        <th>Person In charge</th>
                                                        <th>Title</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Course</th>
                                                        <th>Person In charge</th>
                                                        <th>Title</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                    foreach($all_courses as $course){?>
                                                        <tr>
                                                            <td>1</td>
                                                            <td><?php echo $course['name']?></td>
                                                            <td><?php echo $course['incharge']?></td>
                                                            <td><?php echo $course['title']?></td>
                                                            <td>
                                                                <button  data-toggle="modal" data-target="#edit_course" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm delete-course" data-id="<?php echo $course['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-course">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Course</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Course
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Course</label>
                                    <div class="col-sm-10">
                                        <input name="course-name" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Person Incharge</label>
                                    <div class="col-sm-10">
                                        <input name="course-incharge" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Title</label>
                                    <div class="col-sm-10">
                                        <input name="course-title" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button id="add-new-course" class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class year-list">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="year-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid">
                                                <thead>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>School Year</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>School Year</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_years = $this->Admin_model->get_all_years();
                                                    foreach($all_years as $year){?>
                                                    <tr>
                                                        <td><?php echo $year['id']?></td>
                                                        <td><?php echo $year['year']?></td>
                                                        <td>
                                                            <button data-id="<?php echo $year['id']?>"  data-toggle="modal" data-target="#edit_year" class="btn btn-info btn-sm">Edit</button>
                                                            <button class="btn btn-danger btn-sm delete-year" data-id="<?php echo $year['id']?>">Delete</button>
                                                        </td>
                                                    </tr><?php }?>    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-year">
            <div class="content ">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">
                                Add Year
                            </h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                            <form method="get" class="form-horizontal">
                            
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Year</label>
                                    <div class="col-sm-10">
                                        <input  name="year" type="text" class="form-control" required>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn btn-default" type="submit">Cancel</button>
                                        <button id="add-year" class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>    
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class scheduling">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">Scheduling</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel no-gap">
                            <div class="panel-heading"></div> 
                            <div class="panel-body no-border">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6 no-gap">
                                                <label>Teacher Name</label>
                                                <select id="select-teacher-schedule" class="form-control m-b" name="teacher_id">
                                                    <option></option>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_teachers = $this->Admin_model->get_all_teachers();
                                                    foreach($all_teachers as $teacher){
                                                    ?>
                                                    <option value="<?php echo $teacher['id'];?>"><?php echo $teacher['name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>        
                                            <div class="form-group col-lg-6 no-gap text-right double-pad-top">
                                                <button type="submit" class="btn btn-primary" data-target="#add_schedule_modal" data-toggle="modal">Add</button>
                                            </div>  
                                        </div>
                                    </div>        
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-body no-border">
                                <div class="table-responsive">
                                <table cellpadding="1" cellspacing="1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Friday</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>01:00 AM</td>
                                        <td class="Monday_01_00_AM"></td>
                                        <td class="Tuesday_01_00_AM"></td>
                                        <td class="Wednesday_01_00_AM"></td>
                                        <td class="Thursday_01_00_AM"></td>
                                        <td class="Friday_01_00_AM"></td>
                                        <td class="Saturday_01_00_AM"></td>
                                        <td class="Sunday_01_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>01:30 AM</td>
                                        <td class="Monday_01_30_AM"></td>
                                        <td class="Tuesday_01_30_AM"></td>
                                        <td class="Wednesday_01_30_AM"></td>
                                        <td class="Thursday_01_30_AM"></td>
                                        <td class="Friday_01_30_AM"></td>
                                        <td class="Saturday_01_30_AM"></td>
                                        <td class="Sunday_01_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:00 AM</td>
                                        <td class="Monday_02_00_AM"></td>
                                        <td class="Tuesday_02_00_AM"></td>
                                        <td class="Wednesday_02_00_AM"></td>
                                        <td class="Thursday_02_00_AM"></td>
                                        <td class="Friday_02_00_AM"></td>
                                        <td class="Saturday_02_00_AM"></td>
                                        <td class="Sunday_02_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:30 AM</td>
                                        <td class="Monday_02_30_AM"></td>
                                        <td class="Tuesday_02_30_AM"></td>
                                        <td class="Wednesday_02_30_AM"></td>
                                        <td class="Thursday_02_30_AM"></td>
                                        <td class="Friday_02_30_AM"></td>
                                        <td class="Saturday_02_30_AM"></td>
                                        <td class="Sunday_02_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:00 AM</td>
                                        <td class="Monday_03_00_AM"></td>
                                        <td class="Tuesday_03_00_AM"></td>
                                        <td class="Wednesday_03_00_AM"></td>
                                        <td class="Thursday_03_00_AM"></td>
                                        <td class="Friday_03_00_AM"></td>
                                        <td class="Saturday_03_00_AM"></td>
                                        <td class="Sunday_03_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:30 AM</td>
                                        <td class="Monday_03_30_AM"></td>
                                        <td class="Tuesday_03_30_AM"></td>
                                        <td class="Wednesday_03_30_AM"></td>
                                        <td class="Thursday_03_30_AM"></td>
                                        <td class="Friday_03_30_AM"></td>
                                        <td class="Saturday_03_30_AM"></td>
                                        <td class="Sunday_03_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:00 AM</td>
                                        <td class="Monday_04_00_AM"></td>
                                        <td class="Tuesday_04_00_AM"></td>
                                        <td class="Wednesday_04_00_AM"></td>
                                        <td class="Thursday_04_00_AM"></td>
                                        <td class="Friday_04_00_AM"></td>
                                        <td class="Saturday_04_00_AM"></td>
                                        <td class="Sunday_04_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:30 AM</td>
                                        <td class="Monday_04_30_AM"></td>
                                        <td class="Tuesday_04_30_AM"></td>
                                        <td class="Wednesday_04_30_AM"></td>
                                        <td class="Thursday_04_30_AM"></td>
                                        <td class="Friday_04_30_AM"></td>
                                        <td class="Saturday_04_30_AM"></td>
                                        <td class="Sunday_04_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:00 AM</td>
                                        <td class="Monday_05_00_AM"></td>
                                        <td class="Tuesday_05_00_AM"></td>
                                        <td class="Wednesday_05_00_AM"></td>
                                        <td class="Thursday_05_00_AM"></td>
                                        <td class="Friday_05_00_AM"></td>
                                        <td class="Saturday_05_00_AM"></td>
                                        <td class="Sunday_05_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:30 AM</td>
                                        <td class="Monday_05_30_AM"></td>
                                        <td class="Tuesday_05_30_AM"></td>
                                        <td class="Wednesday_05_30_AM"></td>
                                        <td class="Thursday_05_30_AM"></td>
                                        <td class="Friday_05_30_AM"></td>
                                        <td class="Saturday_05_30_AM"></td>
                                        <td class="Sunday_05_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:00 AM</td>
                                        <td class="Monday_06_00_AM"></td>
                                        <td class="Tuesday_06_00_AM"></td>
                                        <td class="Wednesday_06_00_AM"></td>
                                        <td class="Thursday_06_00_AM"></td>
                                        <td class="Friday_06_00_AM"></td>
                                        <td class="Saturday_06_00_AM"></td>
                                        <td class="Sunday_06_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:30 AM</td>
                                        <td class="Monday_06_30_AM"></td>
                                        <td class="Tuesday_06_30_AM"></td>
                                        <td class="Wednesday_06_30_AM"></td>
                                        <td class="Thursday_06_30_AM"></td>
                                        <td class="Friday_06_30_AM"></td>
                                        <td class="Saturday_06_30_AM"></td>
                                        <td class="Sunday_06_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:00 AM</td>
                                        <td class="Monday_07_00_AM"></td>
                                        <td class="Tuesday_07_00_AM"></td>
                                        <td class="Wednesday_07_00_AM"></td>
                                        <td class="Thursday_07_00_AM"></td>
                                        <td class="Friday_07_00_AM"></td>
                                        <td class="Saturday_07_00_AM"></td>
                                        <td class="Sunday_07_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:30 AM</td>
                                        <td class="Monday_07_30_AM"></td>
                                        <td class="Tuesday_07_30_AM"></td>
                                        <td class="Wednesday_07_30_AM"></td>
                                        <td class="Thursday_07_30_AM"></td>
                                        <td class="Friday_07_30_AM"></td>
                                        <td class="Saturday_07_30_AM"></td>
                                        <td class="Sunday_07_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:00 AM</td>
                                        <td class="Monday_08_00_AM"></td>
                                        <td class="Tuesday_08_00_AM"></td>
                                        <td class="Wednesday_08_00_AM"></td>
                                        <td class="Thursday_08_00_AM"></td>
                                        <td class="Friday_08_00_AM"></td>
                                        <td class="Saturday_08_00_AM"></td>
                                        <td class="Sunday_08_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:30 AM</td>
                                        <td class="Monday_08_30_AM"></td>
                                        <td class="Tuesday_08_30_AM"></td>
                                        <td class="Wednesday_08_30_AM"></td>
                                        <td class="Thursday_08_30_AM"></td>
                                        <td class="Friday_08_30_AM"></td>
                                        <td class="Saturday_08_30_AM"></td>
                                        <td class="Sunday_08_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>09:00 AM</td>
                                        <td class="Monday_09_00_AM"></td>
                                        <td class="Tuesday_09_00_AM"></td>
                                        <td class="Wednesday_09_00_AM"></td>
                                        <td class="Thursday_09_00_AM"></td>
                                        <td class="Friday_09_00_AM"></td>
                                        <td class="Saturday_09_00_AM"></td>
                                        <td class="Sunday_09_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>09:30 AM</td>
                                        <td class="Monday_09_30_AM"></td>
                                        <td class="Tuesday_09_30_AM"></td>
                                        <td class="Wednesday_09_30_AM"></td>
                                        <td class="Thursday_09_30_AM"></td>
                                        <td class="Friday_09_30_AM"></td>
                                        <td class="Saturday_09_30_AM"></td>
                                        <td class="Sunday_09_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:00 AM</td>
                                        <td class="Monday_10_00_AM"></td>
                                        <td class="Tuesday_10_00_AM"></td>
                                        <td class="Wednesday_10_00_AM"></td>
                                        <td class="Thursday_10_00_AM"></td>
                                        <td class="Friday_10_00_AM"></td>
                                        <td class="Saturday_10_00_AM"></td>
                                        <td class="Sunday_10_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:30 AM</td>
                                        <td class="Monday_10_30_AM"></td>
                                        <td class="Tuesday_10_30_AM"></td>
                                        <td class="Wednesday_10_30_AM"></td>
                                        <td class="Thursday_10_30_AM"></td>
                                        <td class="Friday_10_30_AM"></td>
                                        <td class="Saturday_10_30_AM"></td>
                                        <td class="Sunday_10_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:00 AM</td>
                                        <td class="Monday_11_00_AM"></td>
                                        <td class="Tuesday_11_00_AM"></td>
                                        <td class="Wednesday_11_00_AM"></td>
                                        <td class="Thursday_11_00_AM"></td>
                                        <td class="Friday_11_00_AM"></td>
                                        <td class="Saturday_11_00_AM"></td>
                                        <td class="Sunday_11_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:30 AM</td>
                                        <td class="Monday_11_30_AM"></td>
                                        <td class="Tuesday_11_30_AM"></td>
                                        <td class="Wednesday_11_30_AM"></td>
                                        <td class="Thursday_11_30_AM"></td>
                                        <td class="Friday_11_30_AM"></td>
                                        <td class="Saturday_11_30_AM"></td>
                                        <td class="Sunday_11_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:00 AM</td>
                                        <td class="Monday_12_00_AM"></td>
                                        <td class="Tuesday_12_00_AM"></td>
                                        <td class="Wednesday_12_00_AM"></td>
                                        <td class="Thursday_12_00_AM"></td>
                                        <td class="Friday_12_00_AM"></td>
                                        <td class="Saturday_12_00_AM"></td>
                                        <td class="Sunday_12_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:30 AM</td>
                                        <td class="Monday_12_30_AM"></td>
                                        <td class="Tuesday_12_30_AM"></td>
                                        <td class="Wednesday_12_30_AM"></td>
                                        <td class="Thursday_12_30_AM"></td>
                                        <td class="Friday_12_30_AM"></td>
                                        <td class="Saturday_12_30_AM"></td>
                                        <td class="Sunday_12_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>01:00 PM</td>
                                        <td class="Monday_01_00_PM"></td>
                                        <td class="Tuesday_01_00_PM"></td>
                                        <td class="Wednesday_01_00_PM"></td>
                                        <td class="Thursday_01_00_PM"></td>
                                        <td class="Friday_01_00_PM"></td>
                                        <td class="Saturday_01_00_PM"></td>
                                        <td class="Sunday_01_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>01:30 PM</td>
                                        <td class="Monday_01_30_PM"></td>
                                        <td class="Tuesday_01_30_PM"></td>
                                        <td class="Wednesday_01_30_PM"></td>
                                        <td class="Thursday_01_30_PM"></td>
                                        <td class="Friday_01_30_PM"></td>
                                        <td class="Saturday_01_30_PM"></td>
                                        <td class="Sunday_01_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:00 PM</td>
                                        <td class="Monday_02_00_PM"></td>
                                        <td class="Tuesday_02_00_PM"></td>
                                        <td class="Wednesday_02_00_PM"></td>
                                        <td class="Thursday_02_00_PM"></td>
                                        <td class="Friday_02_00_PM"></td>
                                        <td class="Saturday_02_00_PM"></td>
                                        <td class="Sunday_02_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:30 PM</td>
                                        <td class="Monday_02_30_PM"></td>
                                        <td class="Tuesday_02_30_PM"></td>
                                        <td class="Wednesday_02_30_PM"></td>
                                        <td class="Thursday_02_30_PM"></td>
                                        <td class="Friday_02_30_PM"></td>
                                        <td class="Saturday_02_30_PM"></td>
                                        <td class="Sunday_02_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:00 PM</td>
                                        <td class="Monday_03_00_PM"></td>
                                        <td class="Tuesday_03_00_PM"></td>
                                        <td class="Wednesday_03_00_PM"></td>
                                        <td class="Thursday_03_00_PM"></td>
                                        <td class="Friday_03_00_PM"></td>
                                        <td class="Saturday_03_00_PM"></td>
                                        <td class="Sunday_03_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:30 PM</td>
                                        <td class="Monday_03_30_PM"></td>
                                        <td class="Tuesday_03_30_PM"></td>
                                        <td class="Wednesday_03_30_PM"></td>
                                        <td class="Thursday_03_30_PM"></td>
                                        <td class="Friday_03_30_PM"></td>
                                        <td class="Saturday_03_30_PM"></td>
                                        <td class="Sunday_03_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:00 PM</td>
                                        <td class="Monday_04_00_PM"></td>
                                        <td class="Tuesday_04_00_PM"></td>
                                        <td class="Wednesday_04_00_PM"></td>
                                        <td class="Thursday_04_00_PM"></td>
                                        <td class="Friday_04_00_PM"></td>
                                        <td class="Saturday_04_00_PM"></td>
                                        <td class="Sunday_04_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:30 PM</td>
                                        <td class="Monday_04_30_PM"></td>
                                        <td class="Tuesday_04_30_PM"></td>
                                        <td class="Wednesday_04_30_PM"></td>
                                        <td class="Thursday_04_30_PM"></td>
                                        <td class="Friday_04_30_PM"></td>
                                        <td class="Saturday_04_30_PM"></td>
                                        <td class="Sunday_04_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:00 PM</td>
                                        <td class="Monday_05_00_PM"></td>
                                        <td class="Tuesday_05_00_PM"></td>
                                        <td class="Wednesday_05_00_PM"></td>
                                        <td class="Thursday_05_00_PM"></td>
                                        <td class="Friday_05_00_PM"></td>
                                        <td class="Saturday_05_00_PM"></td>
                                        <td class="Sunday_05_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:30 PM</td>
                                        <td class="Monday_05_30_PM"></td>
                                        <td class="Tuesday_05_30_PM"></td>
                                        <td class="Wednesday_05_30_PM"></td>
                                        <td class="Thursday_05_30_PM"></td>
                                        <td class="Friday_05_30_PM"></td>
                                        <td class="Saturday_05_30_PM"></td>
                                        <td class="Sunday_05_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:00 PM</td>
                                        <td class="Monday_06_00_PM"></td>
                                        <td class="Tuesday_06_00_PM"></td>
                                        <td class="Wednesday_06_00_PM"></td>
                                        <td class="Thursday_06_00_PM"></td>
                                        <td class="Friday_06_00_PM"></td>
                                        <td class="Saturday_06_00_PM"></td>
                                        <td class="Sunday_06_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:30 PM</td>
                                        <td class="Monday_06_30_PM"></td>
                                        <td class="Tuesday_06_30_PM"></td>
                                        <td class="Wednesday_06_30_PM"></td>
                                        <td class="Thursday_06_30_PM"></td>
                                        <td class="Friday_06_30_PM"></td>
                                        <td class="Saturday_06_30_PM"></td>
                                        <td class="Sunday_06_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:00 PM</td>
                                        <td class="Monday_07_00_PM"></td>
                                        <td class="Tuesday_07_00_PM"></td>
                                        <td class="Wednesday_07_00_PM"></td>
                                        <td class="Thursday_07_00_PM"></td>
                                        <td class="Friday_07_00_PM"></td>
                                        <td class="Saturday_07_00_PM"></td>
                                        <td class="Sunday_07_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:30 PM</td>
                                        <td class="Monday_07_30_PM"></td>
                                        <td class="Tuesday_07_30_PM"></td>
                                        <td class="Wednesday_07_30_PM"></td>
                                        <td class="Thursday_07_30_PM"></td>
                                        <td class="Friday_07_30_PM"></td>
                                        <td class="Saturday_07_30_PM"></td>
                                        <td class="Sunday_07_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:00 PM</td>
                                        <td class="Monday_08_00_PM"></td>
                                        <td class="Tuesday_08_00_PM"></td>
                                        <td class="Wednesday_08_00_PM"></td>
                                        <td class="Thursday_08_00_PM"></td>
                                        <td class="Friday_08_00_PM"></td>
                                        <td class="Saturday_08_00_PM"></td>
                                        <td class="Sunday_08_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:30 PM</td>
                                        <td class="Monday_08_30_PM"></td>
                                        <td class="Tuesday_08_30_PM"></td>
                                        <td class="Wednesday_08_30_PM"></td>
                                        <td class="Thursday_08_30_PM"></td>
                                        <td class="Friday_08_30_PM"></td>
                                        <td class="Saturday_08_30_PM"></td>
                                        <td class="Sunday_08_30_PM"></td>
                                    </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--- shifts -->
        <div class="common-class all-shift-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="shift-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Shift</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Shift</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_shifts = $this->Admin_model->get_all_shifts();
                                                    foreach($all_shifts as $shift){?>
                                                        <tr>
                                                            <td><?php echo $shift['id']?></td>
                                                            <td><?php echo $shift['shift']?></td>
                                                            <td><?php echo $shift['s_time']?></td>
                                                            <td><?php echo $shift['e_time']?></td>
                                                            <td>
                                                                <button data-id="<?php echo $shift['id']?>" data-toggle="modal" data-target="#edit_shift" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm delete-shift" data-id="<?php echo $shift['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-shift-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">

                            <form id="add-shift-form" action="javascript:;" method="post">
                                
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <label>Shift</label>
                                                    <input type="" value="" id="" class="form-control" name="shift" required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Start Time</label>
                                                    <div class="input-group clockpicker" data-autoclose="true">
                                                        <input name="shift-start-time" type="text" class="form-control" required />
                                                            <span class="input-group-addon">
                                                                <span class="fa fa-clock-o"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>End Time</label>
                                                    <div class="input-group clockpicker" data-autoclose="true">
                                                        <input name="shift-end-time" type="text" class="form-control" required />
                                                            <span class="input-group-addon">
                                                                <span class="fa fa-clock-o"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-shift-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-shift' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <!-- end shifts -->
        <!--countries -->
        <div class="common-class all-country-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="country-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Country</th>
                                                        <th>Code</th>
                                                        <th>Currency</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Country</th>
                                                        <th>Code</th>
                                                        <th>Currency</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                    $this->load->model('Admin_model'); 
                                                    $all_countries = $this->Admin_model->get_all_countries();
                                                    foreach($all_countries as $country){?>
                                                        <tr>
                                                            <td><?php echo $country['id']?></td>
                                                            <td><?php echo $country['name']?></td>
                                                            <td><?php echo $country['code']?></td>
                                                            <td><?php echo $country['currency']?></td>
                                                            <td>
                                                                <button data-id="<?php echo $country['id']?>"  data-toggle="modal" data-target="#edit_country" class="btn btn-info btn-sm">Edit</button>
                                                                <button class="btn btn-danger btn-sm delete-country" data-id="<?php echo $country['id']?>">Delete</button>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class add-country-tab">
            <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <form id="add-country-form" action="javascript:;" method="post">
                                <div class="tab-content">
                                <div id="step1" class="p-m tab-pane active">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row">
                                                <div class="form-group col-lg-12">
                                                    <label>Country Name</label>
                                                    <input type="text"  class="form-control" name="count-name"  required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Code</label>
                                                    <input type="text"  class="form-control" name="count-code"  required />
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label>Currency</label>
                                                    <input type="text"  class="form-control" name="count-currency"  required />
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="text-right m-t-xs">
                                        <button id="clear-country-form" class="btn btn-default">Clear</button>
                                        <!-- <button type="submit" class="btn btn-success submitWizard">Submit</button> -->
                                        <button id='add-new-country' type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
        <!--end country -->
    </div>

    <!--- teacher modal -->
    <div class="modal fade" id="myModal5" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-header">
                    <h4 class="modal-title">Modal title</h4>
                    <small class="font-bold">Lorem Ipsum is simply dummy text.</small>
                </div>
                <div class="modal-body">
                    <p><strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,
                    remaining essentially unchanged.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher modal -->

     <!--- manager edit modal -->
    <div class="modal fade" id="edit_manager" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <input id="edit-manager-id" type="hidden" class="form-control">
                                            <div class="text-center"><strong>Personal Bio Data</strong></div>
                                            <div class="hr-line-dashed"></div>  
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-name" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">CNIC</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-cnic" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Address</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-address" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Telephone</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-landline" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-mobile" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Email</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-email" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                        </form>
                                    </div>
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <div class="text-center"><strong> Office Details</strong></div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">User Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-username" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Password</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-pass" type="password" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Skype ID</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-skype" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Salary Package</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-manager-salary" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="pull-right">
                                                <button id="update-edit-manager" type="button" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end manager edit modal -->



    <!--- teacher profile modal -->
    <div class="modal fade" id="edit_teacher" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <input id="edit-teacher-id" type="hidden" class="form-control">
                                            <div class="text-center"><strong>Personal Bio Data</strong></div>
                                            <div class="hr-line-dashed"></div>  
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Teacher Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-name" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Father Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-fname" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">CNIC</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-cnic" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Address</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-address" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Telephone</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-landline" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-mobile" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Email</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-email" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Shift</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-shift" class="form-control" name="shift" required />
                                                        <option></option>
                                                        <option value="Day">Day</option>
                                                        <option value="Night">Night</option>
                                                        <option value="Both">Both</option>
                                                    </select>
                                                </div>    
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Gender</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-gender" class="form-control" name="account">
                                                    <option></option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Marital Status</label>
                                                <div class="col-sm-8">
                                                    <select id="edit-teacher-mat-status" class="form-control" name="account">
                                                        <option></option>
                                                        <option value="Single">Single</option>
                                                        <option value="Married">Married</option>
                                                        <option value="Divorced">Divorced</option>
                                                    </select>    
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Qualification</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-qualification" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Experience</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-experience" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                        </form>
                                    </div>
                                    <div class="col-lg-6">
                                        <form method="get" class="form-horizontal">
                                            <div class="text-center"><strong> Office Details</strong></div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Designation</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-designation" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Skype ID</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-skype" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Salary Package</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-salary" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">User Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-username" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Password</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-pass" type="password" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Interview remarks</label>
                                                <div class="col-sm-8">
                                                    <textarea id="edit-teacher-interremarks" type="text" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="right">
                                                <button id="update-edit-teacher" type="button" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher profile modal -->


    <!--- edit parent modal -->
    <div class="modal fade" id="edit_parent" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form method="get" class="form-horizontal">
                                            <div class="row">
                                                <div class="col-lg-12">
                                            <div class="form-group col-lg-6">
                                                <label>Parent Name</label>
                                                <input type="text" id="edit-parent-name" class="form-control" >
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                                <label>Email</label>
                                                <input type="email" id="edit-parent-email" class="form-control">
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                                <label>Username</label>
                                                <input type="text" id="edit-parent-username" class="form-control">
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                                <label>Password</label>
                                                <input type="password" id="edit-parent-password" class="form-control">
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                                <label>Telephone</label>
                                                <input type="text" id="edit-parent-telephone" class="form-control">
                                            </div>
                                            
                                            <div class="form-group col-lg-6">
                                                <label>Mobile</label>
                                                <input type="text" id="edit-parent-mobile" class="form-control">
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Skype ID</label>
                                                <input type="text" id="edit-parent-skype" class="form-control">
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Notes</label>
                                                <input type="text" id="edit-parent-note" class="form-control">
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Manager</label>
                                                <select id="edit-parent-note" class="form-control">
                                                    <option></option>
                                                    <option>Day</option>
                                                    <option>Night</option>
                                                    <option>Both</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Country</label>
                                                <select id="edit-parent-country" class="form-control">
                                                    <option></option>
                                                    <option>In Office</option>
                                                    <option>Out Office</option>
                                                </select>
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <label>Fee</label>
                                                <input id="edit-parent-fee" class="form-control" type="text">
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Fee Currency</label>
                                                <select id="edit-parent-fee_currency"  class="form-control">
                                                    <option></option>
                                                    <option>USD</option>
                                                    <option>AUD</option>
                                                    <option>EURO</option>
                                                    <option>POUND</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Fee Type</label>
                                                <select id="edit-parent-fee_type" class="form-control">
                                                    <option></option>
                                                    <option>Paypal</option>
                                                    <option>2Checkout</option>
                                                    <option>WU/Bank Account</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Fee Date</label>
                                                <select id="edit-parent-fee_date" class="form-control">
                                                    <option></option>
                                                    <option>1</option>
                                                    <option>15</option>
                                                </select>
                                            </div>
                                            <button type="button" class="btn btn-info">Update</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                        </form>
                                    </div>
                                </div>   
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end edit parent modal -->

    <!--- edit year modal -->
    <div class="modal fade" id="edit_year" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <input id="edit_year_id" type="hidden"  class="form-control" name="year_id" required />
                                                        <div class="form-group col-lg-12">
                                                            <label>Year</label>
                                                            <input id="edit_year_name" type="text" class="form-control" name="year_year" required />
                                                        </div>
                                                        <button id="update-edit-year" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>        
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end edit year modal -->

    <!--- edit course modal -->

    <div class="modal fade" id="edit_course" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Person Incharge</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Title</label>
                                                            <input type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <button type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit course modal -->

    <!--- edit shift modal -->

    <div class="modal fade" id="edit_shift" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_shift_id" type="hidden"  class="form-control" name="shift_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Shift</label>
                                                            <input id="edit_shift_name" type="text"  class="form-control" name="shift_name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12 clockpicker" data-autoclose="true">
                                                            <label>Start Time</label>
                                                            <input id="edit_shift_start_time" type="text"  class="form-control" name="shift_s_time" required />
                                                        </div>
                                                        <div class="form-group col-lg-12 clockpicker" data-autoclose="true">
                                                            <label>End Time</label>
                                                            <input id="edit_shift_end_time" type="text"  class="form-control" name="shift_e_time" required />
                                                        </div>
                                                        <button id="update-edit-shift" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit shift modal -->

    <!--- Add Schedule modal -->

    <div class="modal fade" id="add_schedule_modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Teacher Name</label>
                                                            <select class="form-control m-b" name="teacher_id">
                                                                <option></option>
                                                                <?php
                                                                $this->load->model('Admin_model'); 
                                                                $all_teachers = $this->Admin_model->get_all_teachers();
                                                                foreach($all_teachers as $teacher){
                                                                ?>
                                                                <option value="<?php echo $teacher['id'];?>"><?php echo $teacher['name']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>        
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Student Name</label>
                                                            <select class="form-control m-b" name="student_id">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_students = $this->Admin_model->get_all_students();
                                                                    foreach($all_students as $student){
                                                                ?>
                                                                <option value="<?php echo $student['id'];?>"><?php echo $student['name']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label>Day</label>
                                                            <select class="form-control m-b" name="day">
                                                                <option value=""> </option>
                                                                <option value="Monday">Monday</option>
                                                                <option value="Tuesday">Tuesday</option>
                                                                <option value="Wednesday">Wednesday</option>
                                                                <option value="Thursday">Thursday</option>
                                                                <option value="Friday">Friday</option>
                                                                <option value="Saturday">Saturday</option>
                                                                <option value="Sunday">Sunday</option>
                                                            </select>
                                                        </div>                                                    
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label >Time</label>
                                                            <select class="form-control m-b" name="time">
                                                                <option value=""> </option>
                                                                <option value="12:00 AM">12:00 AM</option>
                                                                <option value="12:30 AM">12:30 AM</option>
                                                                <option value="01:00 AM">01:00 AM</option>
                                                                <option value="01:30 AM">01:30 AM</option>
                                                                <option value="02:00 AM">02:00 AM</option>
                                                                <option value="02:30 AM">02:30 AM</option>
                                                                <option value="03:00 AM">03:00 AM</option>
                                                                <option value="03:30 AM">03:30 AM</option>
                                                                <option value="04:00 AM">04:00 AM</option>                    
                                                                <option value="04:30 AM">04:30 AM</option>
                                                                <option value="05:00 AM">05:00 AM</option>
                                                                <option value="05:30 AM">05:30 AM</option>
                                                                <option value="06:00 AM">06:00 AM</option>
                                                                <option value="06:30 AM">06:30 AM</option>
                                                                <option value="07:00 AM">07:00 AM</option>
                                                                <option value="07:30 AM">07:30 AM</option>
                                                                <option value="08:00 AM">08:00 AM</option>
                                                                <option value="08:30 AM">08:30 AM</option>
                                                                <option value="09:00 AM">09:00 AM</option>
                                                                <option value="09:30 AM">09:30 AM</option>
                                                                <option value="10:00 AM">10:00 AM</option>
                                                                <option value="10:30 AM">10:30 AM</option>
                                                                <option value="11:00 AM">11:00 AM</option>
                                                                <option value="11:30 AM">11:30 AM</option>
                                                                <option value="12:00 PM">12:00 PM</option>
                                                                <option value="12:30 PM">12:30 PM</option>
                                                                <option value="01:00 PM">01:00 PM</option>
                                                                <option value="01:30 PM">01:30 PM</option>
                                                                <option value="02:00 PM">02:00 PM</option>
                                                                <option value="02:30 PM">02:30 PM</option>
                                                                <option value="03:00 PM">03:00 PM</option>
                                                                <option value="03:30 PM">03:30 PM</option>
                                                                <option value="04:00 PM">04:00 PM</option>
                                                                <option value="04:30 PM">04:30 PM</option>
                                                                <option value="05:00 PM">05:00 PM</option>
                                                                <option value="05:30 PM">05:30 PM</option>
                                                                <option value="06:00 PM">06:00 PM</option>
                                                                <option value="06:30 PM">06:30 PM</option>
                                                                <option value="07:00 PM">07:00 PM</option>                                                            <option value="07:30 PM">07:30 PM</option>
                                                                <option value="08:00 PM">08:00 PM</option>
                                                                <option value="08:30 PM">08:30 PM</option>
                                                                <option value="09:00 PM">09:00 PM</option>
                                                                <option value="09:30 PM">09:30 PM</option>
                                                                <option value="10:00 PM">10:00 PM</option>
                                                                <option value="10:30 PM">10:30 PM</option>
                                                                <option value="11:00 PM">11:00 PM</option>
                                                                <option value="11:30 PM">11:30 PM</option>
                                                                <option value="49">N-A</option>
                                                            </select>
                                                        </div>
                                                        <!--<div class="form-group col-lg-6 no-gap">
                                                            <label>Student Zone</label>
                                                            <select class="form-control m-b" name="student_zone">
                                                                <option value=""> </option>                                                            <option value="monday">Monday</option>
                                                                <option value="tuesday">Tuesday</option>
                                                                <option value="wednesday">Wednesday</option>
                                                                <option value="thursday">Thursday</option>
                                                                <option value="friday">Friday</option>
                                                                <option value="saturday">Saturday</option>
                                                                <option value="sunday">Sunday</option>
                                                            </select>
                                                        </div>    
                                                        <div class="form-group col-lg-6 no-gap">
                                                            <label >Course</label>
                                                            <select class="form-control m-b" name="course">
                                                                <option></option>
                                                                <?php
                                                                   // $this->load->model('Admin_model'); 
                                                                   // $all_courses = $this->Admin_model->get_all_courses();
                                                                   // foreach($all_courses as $course){
                                                                ?>
                                                                <option value="<?php //echo $course['id'];?>"><?php //echo $course['name']; ?></option>
                                                                <?php //} ?>
                                                            </select>                                
                                                        </div> -->
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-schedule" class="btn btn-info" type="submit">Save</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end Add Schedule modal -->

    <!--- Add class_remarks modal -->

    <div class="modal fade" id="class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="lesson_teach"  type="text"  class="form-control" name="lesson_teach" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Class Remaks</label>
                                                            <textarea id="class_remarks" type="text"  class="form-control" name="class_remarks" required /></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-class-remarks" class="btn btn-info" type="submit">Save</button>
                                                                <button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end Add class remarks modal -->


    <!--- edit country modal -->

    <div class="modal fade" id="edit_country" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_country_id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Country Name</label>
                                                            <input id="edit_country_name" type="text"  class="form-control" name="country_name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12" >
                                                            <label>Code</label>
                                                            <input id="edit_country_code" type="text"  class="form-control" name="country_code" required />
                                                        </div>
                                                        <div class="form-group col-lg-12" >
                                                            <label>Currency</label>
                                                            <input id="edit_country_currency" type="text"  class="form-control" name="country_currency" required />
                                                        </div>
                                                        <button id="update-edit-country" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit country modal -->

    <!--- edit student modal -->

    <div class="modal fade" id="edit_student" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input id="edit_student_id" type="hidden"  class="form-control" name="country_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Student Name</label>
                                                            <input id="edit_student_name" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Skype ID</label>
                                                            <input id="edit_student_skype_id" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Age</label>
                                                            <input id="edit_student_age" type="text"  class="form-control" name="username" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Gender</label>
                                                            <select id="edit_student_gender" class="form-control" name="student-gender[]" required="">
                                                                <option></option>
                                                                <option value="male">Male</option>
                                                                <option value="female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <select id="edit_student_course" class="form-control" name="course[]">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                                    foreach($all_courses as $course){?>
                                                                        <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                                    <?php } ?>  
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Number of Days</label>
                                                            <!--<input id="edit_student_days" type="text"  class="form-control" name="days" required />-->
                                                            <select id="edit_student_days" class="form-control" name="days" required />
                                                                <option></option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Fee</label>
                                                            <input id="edit_student_fee" type="text"  class="form-control" name="fee" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <input id="edit_student_status" type="text"  class="form-control" name="status" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Trial Class Remarks</label>
                                                            <textarea id="edit_student_trial_remarks" class="form-control" name="trial-class-remarks[]"></textarea>
                                                        </div>
                                                        <button id="update-edit-student" type="button" class="btn btn-info">Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end edit student modal -->

    <!--- add student modal -->

    <div class="modal fade" id="add_student" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="color-line"></div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form id="add-pstudent" method="get" class="form-horizontal">
                                                <div class="row">
                                                    <input  type="hidden"  class="form-control" name="parent_id" required />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Student Name</label>
                                                            <input  type="text"  class="form-control" name="student-name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Skype ID</label>
                                                            <input  type="text"  class="form-control" name="student-skype" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Age</label>
                                                            <input  type="text"  class="form-control" name="student-age" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Gender</label>
                                                            <select  class="form-control" name="student-gender" required="">
                                                                <option></option>
                                                                <option value="male">Male</option>
                                                                <option value="female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Course</label>
                                                            <select class="form-control" name="course">
                                                                <option></option>
                                                                <?php
                                                                    $this->load->model('Admin_model'); 
                                                                    $all_courses = $this->Admin_model->get_all_courses();
                                                                    foreach($all_courses as $course){?>
                                                                        <option value="<?php echo $course['id']?>"><?php echo $course['name']?></option>
                                                                    <?php } ?>  
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Teacher</label>
                                                            <select class="form-control" name="teacher">
                                                                <option></option>
                                                                <option value="1">Lareb</option>
                                                                <option value="2">Zahik</option> 
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Number of Days</label>
                                                            <!--<input type="text"  class="form-control" name="days" required />-->
                                                            <select class="form-control" name="days" required />
                                                                <option></option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>

                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Fee</label>
                                                            <input type="text"  class="form-control" name="student-fee" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Status</label>
                                                            <input type="text"  class="form-control" name="student-status" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Trial Class Remarks</label>
                                                            <textarea class="form-control" name="trial-class-remarks"></textarea>
                                                        </div>
                                                        <button type="submit" class="btn btn-info">Add</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div>   
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end add student modal -->

    
    <!-- Right sidebar -->
    <!--<div id="right-sidebar" class="animated fadeInRight">

        <div class="p-m">
            <button id="sidebar-close" class="right-sidebar-toggle sidebar-button btn btn-default m-b-md"><i class="pe pe-7s-close"></i>
            </button>
            <div>
                <span class="font-bold no-margins"> Analytics </span>
                <br>
                <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.</small>
            </div>
            <div class="row m-t-sm m-b-sm">
                <div class="col-lg-6">
                    <h3 class="no-margins font-extra-bold text-success">300,102</h3>

                    <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                </div>
                <div class="col-lg-6">
                    <h3 class="no-margins font-extra-bold text-success">280,200</h3>

                    <div class="font-bold">98% <i class="fa fa-level-up text-success"></i></div>
                </div>
            </div>
            <div class="progress m-t-xs full progress-small">
                <div style="width: 25%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="25" role="progressbar"
                     class=" progress-bar progress-bar-success">
                    <span class="sr-only">35% Complete (success)</span>
                </div>
            </div>
        </div>
        <div class="p-m bg-light border-bottom border-top">
            <span class="font-bold no-margins"> Social talks </span>
            <br>
            <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.</small>
            <div class="m-t-md">
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a1.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">John Novak</span>
                            <small class="text-muted">21.03.2015</small>
                            <div class="social-content small">
                                Injected humour, or randomised words which don't look even slightly believable.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a3.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">Mark Smith</span>
                            <small class="text-muted">14.04.2015</small>
                            <div class="social-content">
                                Many desktop publishing packages and web page editors.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="social-talk">
                    <div class="media social-profile clearfix">
                        <a class="pull-left">
                            <img src="<?php //echo base_url()?>public/images/a4.jpg" alt="profile-picture">
                        </a>

                        <div class="media-body">
                            <span class="font-bold">Marica Morgan</span>
                            <small class="text-muted">21.03.2015</small>

                            <div class="social-content">
                                There are many variations of passages of Lorem Ipsum available, but the majority have
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-m">
            <span class="font-bold no-margins"> Sales in last week </span>
            <div class="m-t-xs">
                <div class="row">
                    <div class="col-xs-6">
                        <small>Today</small>
                        <h4 class="m-t-xs">$170,20 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                    <div class="col-xs-6">
                        <small>Last week</small>
                        <h4 class="m-t-xs">$580,90 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <small>Today</small>
                        <h4 class="m-t-xs">$620,20 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                    <div class="col-xs-6">
                        <small>Last week</small>
                        <h4 class="m-t-xs">$140,70 <i class="fa fa-level-up text-success"></i></h4>
                    </div>
                </div>
            </div>
            <small> Lorem Ipsum is simply dummy text of the printing simply all dummy text.
                Many desktop publishing packages and web page editors.
            </small>
        </div>-->
    </div>

    <!-- Footer-->
    <footer class="footer">
        <span class="pull-right">
            Example text
        </span>
        Company 2015-2020
    </footer>

</div>

<!-- Vendor scripts -->
<script src="<?php echo base_url()?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>public/js/curvedLines.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/metisMenu.min.js"></script>
<script src="<?php echo base_url()?>public/js/icheck.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.peity.min.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/moment.min.js"></script>
<script src="<?php echo base_url()?>public/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url()?>public/js/toastr.min.js"></script>
<script src="<?php echo base_url()?>public/js/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap-clockpicker.min.js"></script>


<!-- App scripts -->
<script src="<?php echo base_url()?>public/js/homer.js"></script>
<script src="<?php echo base_url()?>public/js/charts.js"></script>
<script src="<?php echo base_url()?>public/js/app.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url()?>public/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>

<script>

    $(function () {

        /**
         * Flot charts data and options
         */
        var data1 = [ [0, 55], [1, 48], [2, 40], [3, 36], [4, 40], [5, 60], [6, 50], [7, 51] ];
        var data2 = [ [0, 56], [1, 49], [2, 41], [3, 38], [4, 46], [5, 67], [6, 57], [7, 59] ];

        var chartUsersOptions = {
            series: {
                splines: {
                    show: true,
                    tension: 0.4,
                    lineWidth: 1,
                    fill: 0.4
                },
            },
            grid: {
                tickColor: "#f0f0f0",
                borderWidth: 1,
                borderColor: 'f0f0f0',
                color: '#6a6c6f'
            },
            colors: [ "#62cb31", "#efefef"],
        };

        $.plot($("#flot-line-chart"), [data1, data2], chartUsersOptions);

        /**
         * Flot charts 2 data and options
         */
        var chartIncomeData = [
            {
                label: "line",
                data: [ [1, 10], [2, 26], [3, 16], [4, 36], [5, 32], [6, 51] ]
            }
        ];

        var chartIncomeOptions = {
            series: {
                lines: {
                    show: true,
                    lineWidth: 0,
                    fill: true,
                    fillColor: "#64cc34"

                }
            },
            colors: ["#62cb31"],
            grid: {
                show: false
            },
            legend: {
                show: false
            }
        };

        $.plot($("#flot-income-chart"), chartIncomeData, chartIncomeOptions);

        // Initialize Example 2

        $('#manager-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#teacher-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_teachers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Teacher Name" },
                { "data": "Email" },
                { "data": "No of Student" },
                { "data": "Shift" },
                { "data": "Gender" },
                { "data": "Skype ID" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });

        $('#parent-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_parents",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Fee" },
                { "data": "Email" },
                { "data": "Username" },
                { "data": "Manager" },
                { "data": "Fee Date" },
                { "data": "Actions" }
            ],
        });

        $('#student-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_students",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Fathername" },
                { "data": "Country" },
                { "data": "Gender" },
                { "data": "Course" },
                { "data": "Class Records" },
                { "data": "Teacher" },
                { "data": "Manager" },
                { "data": "Actions" }
            ],
        });
        $('#course-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_managers",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Name" },
                { "data": "Email" },
                { "data": "Skype ID" },
                { "data": "Username" },
                { "data": "Password" },
                { "data": "Actions" }
            ],
        });
        $('#year-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_years",
                "type": "POST"
            },
            "columns": [
                { "data": "No" },
                { "data": "School Year" },
                { "data": "Actions" }
            ],
        });
        $('#shift-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_shifts",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Shift" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Actions" }
            ],
        });
        $('#country-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_countires",
                "type": "POST"
            },
            "columns": [
                { "data": "ID" },
                { "data": "Country" },
                { "data": "Code" },
                { "data": "Currency" },
                { "data": "Actions" }
            ],
        });

        $('#classes-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/today_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
                { "data": "Actions"},
            ],
        });

        $('#all-classes-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/Admin/all_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
            ],
        });


        // Initialize Example 3
        $('#example3').dataTable();

        // Initialize Example 5
        $('#example5').dataTable();

        // Initialize Example 6
        //$('#example6').DataTable( {
          //  "ajax": 'https://learnquraan.co.uk/ci/index.php/Admin/all_courses',
          //  "columnDefs": [ {
            //    "targets": -1,
              //  "data": null,
            //    "defaultContent": '<button  data-toggle="modal" data-target="#edit_year" class="btn btn-info btn-sm">Edit</button>&nbsp;<button class="btn btn-danger btn-sm delete-year" data-id="">Delete</button>'
          //  }]
       // });

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('a[data-toggle="tab"]').removeClass('btn-primary');
            $('a[data-toggle="tab"]').addClass('btn-default');
            $(this).removeClass('btn-default');
            $(this).addClass('btn-primary');
        })

        $('.next').click(function(){
            var nextId = $(this).parents('.tab-pane').next().attr("id");
            $('[href=#'+nextId+']').tab('show');
        })

        $('.prev').click(function(){
            var prevId = $(this).parents('.tab-pane').prev().attr("id");
            $('[href=#'+prevId+']').tab('show');
        })

        $('.submitWizard').click(function(){

            var approve = $(".approveCheck").is(':checked');
            
                // Got to step 1
                $('[href=#step1]').tab('show');

                // Serialize data to post method
                var datastring = $("#simpleForm").serialize();
                console.log(datastring);
                // Show notification
                swal({
                    title: "Thank you!",
                    text: "You approved our example form!",
                    type: "success"
                });
        });

    // ClockPicker
            $('.clockpicker').clockpicker({autoclose: true});


    });

</script>
<script>

    $(document).ready(function(){
        $('.j_all-parent').click(function(){
            $('.j_all-parent').removeClass('active');
            $(this).addClass('active');
            $(this).closest('body').find('.common-class').removeClass('active');
            var OpenTabDiv = $(this).attr('data-tab');
            $(this).closest('body').find('.'+OpenTabDiv).addClass('active'); 
        });

    });

</script>
<script>
        //setup before functions
        var typingTimer;                //timer identifier
        var doneTypingInterval = 2000;  //time in ms, 5 second for example
        var $input = $('#email');

        //on keyup, start the countdown
        $input.on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(doneTyping, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $input.on('keydown', function () {
          clearTimeout(typingTimer);
        });

        //user is "finished typing," do something
        function doneTyping () {
        var st = $('#email').val();
           $.ajax({
                type: "POST",
                url: "http://comparebox.pk/index.php/admin/check_user_email",
                data: 'email=' + st,
               success: function(data) {
                      if(data == 'yes'){
                        $('#email').parent().addClass('has-error');
                        $("#email").after("<span style='color:red;'>This Email Already Exist</span>");
                        $('button[type="submit"]').attr('disabled','disabled');
                      }else{
                        $('#email').parent().removeClass('has-error');
                        $('#email').next("span").remove();
                        $('button[type="submit"]').removeAttr('disabled');
                      }
                }
            });
        }
    </script>

</body>
</html>