<!DOCTYPE html>
<html class="no-js">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Book Reading</title>
        <link rel="stylesheet" href="<?php echo base_url()?>public/lesson/css/normalize.css"/>
        <link rel="stylesheet" href="<?php echo base_url()?>public/lesson/css/responsive-book.css">
        <!-- Custom Font / Icons -->
        <link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
        <link href="<?php echo base_url()?>public/lesson/css/font-awesome.min.css" rel="stylesheet">
        <link href="<?php echo base_url()?>public/lesson/css/A.font-awesome.min.css%2cq1.6.8.pagespeed.cf.5pdU8hfnbw.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url()?>public/lesson/css/jquery-ui.css">
        <script src="<?php echo base_url()?>public/lesson/js/jquery-1.11.3.min.js"></script>
        <script src="<?php echo base_url()?>public/lesson/js/modernizr-2.6.2.min.js"></script>
        <style>
            .slider-wrap{
                position:relative;
                margin:50px auto;
            }
            .slider{
                position:relative;
                width:450px;
                margin:auto;
            }
            .slider ul{
                margin:0;
                padding:0;
            }
            .slider ul li{
                list-style:none;
                text-align:center;
            }
            .slider ul li span{
                display:inline-block;
                vertical-align:middle;
                width:100px;
                height:100px;
            }
            .slider-arrow{
                position:absolute;
                top:0;
                width:20px;
                height:20px;
                color:#fff;
                text-align:center;
                text-decoration:none;
                border-radius:50%;
            }
            .sa-left{
                left:10px;
            }
            .sa-right{
                right:10px;
            }

            .readlist li p {
                padding: 2px 30px;
            }

            .pagelist li p {
                padding: 10px 30px;
                float: left;
                font-size: 20px!important;
                color: #a09d9d!important;
                border-bottom: 1px solid #000!important;
                line-height: 1.428571!important;
            }

            .func-btn {
                float: right;
            }
            .func-btn a {
                color: #fff;
                font-family: myriad pro;
                font-size: 20px;
                padding: 2px 5px;
            }

            .copyright{background-color:#1D9C73;color:#fff;bottom:0;padding-top:0;margin:0;font-family:"PT Sans","Helvetica Neue",Helvetica,Arial,sans-serif}
            .copyright h5{font-family:san-serif!important;margin:10px 0!important}

            #page-actions{
                padding: 10px 40px;
            }

            #page-actions span{
                cursor: pointer;
            }

            .action-btn {
                position: absolute;
                right: 17px;
                top: -14px;
            }

            .action-btn a {
                background: #1d9c73;
                padding: 5px;
                width: 24px;
                float: left;
                margin: 2px;
                text-align: center;
                color: #fff;
                font-size: 13px;
                line-height: 15px;
            }

             .contentWrap {
                margin-top: 20px;
            }

            .page-thumb.selected {
                background: #ddd;float: left;border: 1px  solid #000;
            }

            #page_teach .page-thumb p {
                margin: 0 !important;
            }

            #page_teach .page-thumb {
                position: relative;
                float: left;
            }

            .note {
                position: absolute;
                right: -7px;
                top: -5px;
                background: #1d9c73;
                color: #fff;
                font-size: 15px;
                width: 24px;
                height: 24px;
                border-radius: 4px;
                text-align: center;
            }

            #book_teach{
                background-color: black;
            }

            .relatedbooks .selected {
                background: #ddd;
                color: #000 !important;
                border: 1px solid #000;
            }

            .pace {
              -webkit-pointer-events: none;
              pointer-events: none;

              -webkit-user-select: none;
              -moz-user-select: none;
              user-select: none;

              z-index: 2000;
              position: fixed;
              height: 90px;
              width: 90px;
              margin: auto;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
            }

            .pace.pace-inactive .pace-activity {
              display: none;
            }

            .pace .pace-activity {
              position: fixed;
              z-index: 2000;
              display: block;
              position: absolute;
              left: -30px;
              top: -30px;
              height: 90px;
              width: 90px;
              display: block;
              border-width: 30px;
              border-style: double;
              border-color: #098157 transparent transparent;
              border-radius: 50%;

              -webkit-animation: spin 1s linear infinite;
              -moz-animation: spin 1s linear infinite;
              -o-animation: spin 1s linear infinite;
              animation: spin 1s linear infinite;
            }

            .pace .pace-activity:before {
              content: ' ';
              position: absolute;
              top: 10px;
              left: 10px;
              height: 50px;
              width: 50px;
              display: block;
              border-width: 10px;
              border-style: solid;
              border-color: #098157 transparent transparent;
              border-radius: 50%;
            }

            @-webkit-keyframes spin {
              100% { -webkit-transform: rotate(359deg); }
            }

            @-moz-keyframes spin {
              100% { -moz-transform: rotate(359deg); }
            }

            @-o-keyframes spin {
              100% { -moz-transform: rotate(359deg); }
            }

            @keyframes spin {
              100% {  transform: rotate(359deg); }
            }

            header{
                        margin-bottom:55px;
                        width:100%;
                        position:relative;
                        z-index:100;
                    }

                    .navbar-fixed-top{
                        background:#1d9c73 !important;
                    }
                    .navbar-inverse .navbar-toggle{
                        border-color:#333;
                    }
                    .sr-only{
                        position:absolute;
                        width:1px;
                        height:1px;
                        margin:-1px;
                        padding:0;
                        overflow:hidden;
                        clip:rect(0,0,0,0);
                        border:0;
                    }
                    .navbar-inverse .navbar-toggle .icon-bar{
                        background-color:#fff;
                    }

                    .navbar-toggle .icon-bar{
                        display:block;
                        width:22px;
                        height:2px;
                        border-radius:1px;
                    }

                    .navbar-brand{
                        padding:6px
                    }
                    .navbar-brand img{
                        height:33px;
                        display:inline-block;
                    }
                    .navbar-inverse .navbar-nav>li>a{
                        color:#fff!important;
                        font-size:13px;
                        font-family:'PT Sans',sans-serif!important;
                    }

                    .nav>li>a{
                        padding:15px 12px!important;
                    }

                    @media (min-width:768px) and (max-width:1200px){
                        .navbar-nav .open .dropdown-menu{position:static;float:none;width:auto;margin-top:0;background-color:transparent;border:0;-webkit-box-shadow:none;box-shadow:none}
                        .navbar-nav .open .dropdown-menu>li>a{line-height:20px}
                        .navbar-nav .open .dropdown-menu>li>a,.navbar-nav .open .dropdown-menu .dropdown-header{padding:5px 15px 5px 25px}
                        .dropdown-menu>li>a{display:block;padding:3px 20px;clear:both;font-weight:normal;line-height:1.42857143;color:#f1c152!important;white-space:nowrap}
                        .navbar-header{float:none}
                        .navbar-toggle{display:block}
                        .navbar-collapse{border-top:1px solid transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.1)}
                        .navbar-collapse.collapse{display:none!important;overflow-y:auto!important}
                        .navbar-nav{float:none!important;margin:7.5px 50px 7.5px 0}
                        .navbar-nav>li{float:none}
                        .navbar-nav>li>a{padding-top:10px;padding-bottom:10px}
                        .navbar-text{float:none;margin:15px 0}
                        .navbar-collapse.collapse.in{display:block!important}
                        .collapsing{overflow:hidden!important}}
                        .cont-far{width:97%!important;max-width:97%;margin:auto}
                        @media (min-width:300px) and (max-width:767px){
                            .cont-far{width:93%;max-width:93%;margin:auto}}



        </style>
    </head>
    <body>
        <main>
            <div class="innerPage booksLiberary_Wrap">
                <input type="hidden" id="searchurl" value="/bookslibrary/"> 
                <!-- <Content start>-->
                <section class="contentWrap">
                    <div class="container-fluid content-body" id="checkhighlight">
                        <div class="row content-row"> 
                            <input type="hidden" id="searcUrl" value="/bookslibrary/ajax/booksearch">
                            <input type="hidden" id="resultUrl" value="/bookslibrary/ajax/resultpage">
                            <!--<Left Container>-->  
                            <!--</Left Container - end>--> 
                            <!--<Right Container>-->
                            <aside class="right-Container col-md-2 hidden-sm hidden-xs">
                                <div class="asideInner col-md-12"> 
                                    <!--<Recently Added Media>-->
                                    <div class="asideBox aside-margin_top">
                                        <h2 class="aside-ListTitle">Pages</h2>
                                        <nav class="relatedbooks">
                                            <ul id="page_teach" class="relatedbooksList pagelist" style="height: 846px;"> 
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--</Recently Added Media>-->
                                </div>
                            </aside>
                            <!--</Right Container - end>--> 
                            <!--<Center Content>-->
                            <div class="content-Container col-md-8">
                                <div class="col-md-12 pg_header">
                                    <div class="col-md-5">
                                        <h4>Book:
                                            <span>
                                                <select id="book_teach">
                                                    <option></option>
                                                    <?php 
                                                        $all_books = $this->Teacher_model->get_all_books();
                                                        foreach ($all_books as $book) { ?>
                                                        <option value="<?php echo $book['id']?>" <?php if($book['id'] == $book_id){ echo 'selected';}?>><?php echo $book['book_name']?></option>
                                                    <?php }?>
                                                </select>
                                            </span>
                                        </h4>
                                    </div>
                                    <div class="col-md-3">
                                    </div>
                                    <div class="col-md-3">
                                    </div>
                                    <div class="col-md-1 hidden-sm hidden-xs" style="text-align:right;">
                                        <p class="btn" onclick="javascript:window.print();" id="">Print</p>
                                    </div>
                                </div>
                                <div class="col-md-12 pg_inner">
                                    <div class="col-md-12 unicode-search-rslt" id="showsearch"></div>
                                    <div class="col-md-12 text-container" id="readdata">
                                        <div class="text-bg">
                                            <div dir="rtl"> 
                                                <div class=current-page> 
                                                    <?php if(!empty($current_page)){?>
                                                        <img src="<?php echo $current_page;?>" style="margin-bottom: 15px; margin-right: 15px;">
                                                        <?php }else{?>
                                                        <p>Please Select the page</p>
                                                        <?php }?>
                                                </div>
                                            </div>
                                            <br><br>        
                                        </div>
                                    </div>
                                    <div class="col-md-12 book-data">
                                        <div class="col-md-1 hidden-sm hidden-xs custom_width-page">
                                            <p>Total Pages</p>
                                        </div>
                                        <div class="col-md-1 hidden-sm hidden-xs custom_width-num">
                                            <p><?php //echo $total_pages?></p>
                                        </div>
                                        <div class="col-md-7 col-sm-12 col-xs-12 text-center custom_pagination" id="pagination">
                                            <!--<ul>
                                                <a id="kwPrev" class="disabled"><button class="btn btn-success">Previous</button></a>
                                                <a title="1"><button class="btn btn-success">1</button></a>
                                                <a href="javascript:;" title="2"><button class="btn">2</button></a>
                                                <a href="javascript:;" title="3"><button class="btn">3</button></a>
                                                <a href="javascript:;" title="4"><button class="btn">4</button></a>
                                                <a href="javascript:;" title="5"><button class="btn">5</button></a>
                                                <a href="javascript:;"><button class="btn">Next</button></a>
                                                <a href="javascript:;"><button class="btn">Last</button></a>
                                            </ul> -->
                                        </div> 
                                        <div class="col-md-1 hidden-sm hidden-xs">
                                            ,<!--<p>Go To</p> -->
                                        </div>
                                        <div class="col-md-1 hidden-sm hidden-xs">
                                            <input type="hidden" id="book" value="3168">
                                            <input type="hidden" id="lastPage" value="20">
                                            <input type="number" id="manualpage" style="width:100%;">
                                            <input type="hidden" id="bookid" value="3168">
                                        </div>
                                    </div>
                                    <font id="pageerror" color="red"></font>    
                                </div>
                                <!--</Center Content - end>-->
                            </div>
                            <aside class="right-Container col-md-2 hidden-sm hidden-xs">
                                <div class="asideInner col-md-12"> 
                                    <div class="action-btn">
                                        <a class="close-it" href="#">X</a>
                                    </div>
                                    <!--<Recently Added Media>-->
                                    <div class="asideBox aside-margin_top">
                                        <h2 class="aside-ListTitle">Chapters</h2>
                                        <nav class="relatedbooks">
                                        <?php 
                                        $all_chpas = $this->Teacher_model->get_book_chaps($book_id); 
                                        if(count($all_chpas) > 0){?>
                                            <ul id="chapter_teach" class="relatedbooksList readlist" style="height: 846px;">
                                                <?php foreach ($all_chpas as $chap) { ?>
                                                <li>
                                                    <a id="chapter-click" href="javascript:;" data-id="<?php echo $chap['id']?>">
                                                        <p><?php echo $chap['chapter_name']?></p>
                                                    </a>
                                                </li>
                                                <?php }?>
                                            </ul>
                                            <?php } ?>
                                        </nav>
                                    </div>
                                    <!--</Recently Added Media>-->
                                </div>
                            </aside>
                        </div>
                    </section>
                    <!-- </Content End>-->

                    <!-- <Footer start>-->
                    <section class="copyright col-md-12 col-sm-12 col-xs-12">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <h5 class="text-center">Copyright © <span class="currentYear">2016</span> by Learn Quraan</h5>
                        </div>
                    </section>
    </body>

        <!-- </Footer end>--> 
    
   </div>
</main>

<!-- All Script placed below this comment -->

<script src="<?php echo base_url()?>public/lesson/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/lesson/js/select2.full.min.js"></script>
<script src="<?php echo base_url()?>public/lesson/js/jquery.nicescroll.minc656.js"></script>
<script src="<?php echo base_url()?>public/lesson/js/plugins.js"></script>
<script src="<?php echo base_url()?>public/lesson/js/jquery-ui.js"></script>
<script type="text/javascript">
    $( document ).ready(function() {
        $('body').on('click','.page-thumb',function(){
            $('.page-thumb').removeClass('selected');
            $(this).addClass('selected');
            var img = $(this).find('img').attr('src');

            if($('.current-page img').length > 0){
                $('.current-page img').attr('src',img);
            }else{
                $('.current-page').empty();
                $('.current-page').append('<img src="" style="margin-bottom: 15px; margin-right: 15px;">');
                $('.current-page img').attr('src',img);
            }
            var page_id = $(this).attr('data-id');
            var book_id = $('#book_teach').val();
            var chap_id = $('p.selected').parent().attr('data-id');
            var student_id = $('#student_id').val();
            var teacher_id = $('#teacher_id').val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/lesson/current_lesson",
                type: "POST",
                dataType: "json",
                data: 'student-id='+student_id+'&teacher-id='+teacher_id+'&page-id='+page_id+'&book-id='+book_id+'&chap-id='+chap_id,
                success: function (data) {
                    
                }    
            });
        });

        $('body').on('click','.close-it',function(){
            parent.closeRFrame();
        });

        $('body').on('change','#book_teach',function(){
            var select = $('#chapter_teach');
            select.empty();
            var book_id = $(this).val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_chapters",
                type: "POST",
                dataType: "json",
                data: 'book-id='+book_id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $.each(data , function( index, value ) {
                            select.append('<li><a id="chapter-click" href="javascript:;" data-id="'+value.id+'"><p>'+value.chapter_name+'</p></a></li>');
                        });
                    }
                }    
            });
        });

        $('body').on('click','#chapter-click',function(){
            $('p.selected').removeClass('selected');
            $(this).children('p').addClass('selected');
            var select = $('#page_teach');
            select.empty();
            select.attr('disabled',false);
            var chap_id = $(this).attr('data-id');
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_pages",
                type: "POST",
                dataType: "json",
                data: 'chap-id='+chap_id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $('.current-page').empty();
                        $('.current-page').append('<p>Please Select the page</p>');
                        $.each(data , function( index, value ) {
                            var src = "https://www.learnquraan.co.uk/uploads/chap/pages/"+value.image;
                            select.append('<li><a class="page-thumb" href="javascript:;" data-id="'+value.id+'"><p><img src="'+src+'" style="display: block; float: left; margin-bottom: 15px; margin-right: 15px; width: 100px; height: 153px;"><span class="note">'+value.page_no+'</span></p></a></li>');
                        });

                    }
                }    
            });
            
        });
    });
</script>
</body>
</html>
