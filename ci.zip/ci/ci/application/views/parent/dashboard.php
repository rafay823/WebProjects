<?php
if (!isset($this->session->userdata['parent_logged_in'])) {
    header("location:https://learnquraan.co.uk/ci/index.php/Parents");
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>LEARN QURAN | Parent Panel</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/metisMenu.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.print.css" media='print'/>
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/sweet-alert.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap-clockpicker.min.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/helper.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/style.css">
    <style>
        .parent-content {
        padding: 20px;
        width: 100%;
        }
        .parent-table {
            padding: 20px;
            width: 100%;
            }
        .common-class {
            display: none;
            }
        .common-class.active {
            display: block;
            width: 100%;
            }

        .no-gap {
            margin: 0 !important;
        }

        .double-pad-top {
            padding-top: 20px;
        }
        .no-border {
            border: 0 none !important;
        }

        .hpanel table th {
          background: #3f5872 none repeat scroll 0 0;
          color: #fff;
        }

        #d_h_v{
            cursor:pointer;
        }

        .hpanel table tr td:first-child {
          width: 100px;
        }

        .hpanel table tr td {
          width: 200px;
        }

        .table-box {
            background: #0486ca none repeat scroll 0 0;
            color: #fff;
            font-size: 12px;
            line-height: 15px;
            position: relative;
            text-align: center;
        }

        .table-box p {
            margin-top: 10px;
        }

        .close-btn {
          color: #fff !important;
          cursor: pointer;
          float: right;
          font-size: 12px;
          padding: 2px 5px;
          position: absolute;
          right: 0;
          text-align: right;
          top: 0;
        }

        .social-board{
            padding-top: 21px;
        }

        .intro {
            float: left;
            padding: 20px 0;
            height: 60px;
            font-weight: 600;
            color: #34495e;
            font-size: 14px;
        }

        table#classes-table tr td:first-child {
            width: 150px;
        }

        table#unpaid-invoices-table tr td:first-child {
            width: 35px;
        }

        table#classes-table tr td:last-child {
            width: 200px;
        }

        table#all-classes-table{
            width:100% !important;
        }

        #parent-classes-history-filter-btn{
            margin-top: 23px;
        }

        iframe {position:absolute;
            z-index:1;
            top:0px;
            left:0px;
        }

    </style>

</head>
<body class="fixed-navbar fixed-sidebar relative">
<input type="hidden" id="login-name" value="<?php echo $this->session->userdata['parent_logged_in']['username'] ?>"></input>

<!-- Simple splash screen-->
<div class="splash"><div class="splash-title"><h1>Learn Quran Academy</h1><div class="spinner"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div> </div> </div>
<!--[if lt IE 7]>
<p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<!-- Header -->
<div id="header">
    <div id="logo" class="light-version">
        <span>
            Learn Quran
        </span>
    </div>
    <nav role="navigation">
        <div class="header-link hide-menu"><i class="fa fa-bars"></i></div>
        <div class="small-logo">
            <span class="text-primary">HOMER APP</span>
        </div>
        
        <div class="mobile-menu">
            <button type="button" class="navbar-toggle mobile-menu-toggle" data-toggle="collapse" data-target="#mobile-collapse">
                <i class="fa fa-chevron-down"></i>
            </button>
            <div class="collapse mobile-navbar" id="mobile-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="" href="login.html">Login</a>
                    </li>
                    <li>
                        <a class="" href="login.html">Logout</a>
                    </li>
                    <li>
                        <a class="" href="profile.html">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar-right">
            <ul class="nav navbar-nav no-borders">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-speaker"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown notification animated flipInX">
                        <li>
                            <a>
                                <span class="label label-success">NEW</span> It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-warning">WAR</span> There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="label label-danger">ERR</span> Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See all notifications</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-mail"></i>
                        <span class="label label-success">4</span>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <div class="title">
                            You have 4 new messages
                        </div>
                        <li>
                            <a>
                                It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                Lorem Ipsum is simply dummy.
                            </a>
                        </li>
                        <li>
                            <a>
                                Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See All Messages</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-upload pe-rotate-90"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <li>
                            <a id="parent-logout" href="javascript:;">
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <div class="intro">
        <span>Asalam-o-Alaikum , </span>
        <span><?php $parent_name = $this->session->userdata['parent_logged_in']['username']; echo $parent_name ;?></span>
    </div>
</div>

<!-- Navigation -->
<aside id="menu">
    <div id="navigation">
        <div class="profile-picture">
            <a href="javascript:;">
                <img src="<?php echo base_url()?>public/images/profile.jpg" class="img-circle m-b" alt="logo">
            </a>
        </div>

        <ul class="nav" id="side-menu">
            <li class="active">
                <a data-tab="dashboard-tab" href="javascript:;" class="j_all-parent"><span class="nav-label">Dashboard</span></a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="all-student-tab">Student List</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="scheduling">Time Table</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="all-classes">Class History</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="test-history">Test History</a>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Invoices</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="unpaid-invoices-tab">Unpaid Invoices</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="paid-invoices-tab">Paid Invoices</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;"><span class="nav-label">Complaints</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="new-complaint-tab">New Complaints</a></li>
                    <li><a href="javascript:;" class="j_all-parent" data-tab="complaint-history-tab">Complaints History</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="view-books">Learning Material</a>
            </li>
        </ul>
    </div>
</aside>

<!-- Main Wrapper -->
<div id="wrapper">
    <div class="common-outter">
        <div class="common-class dashboard-tab active">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12 text-center m-t-md">
                        <h2>
                            Welcome to Learn Quran Parent Panel
                        </h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-200">
                                <i class="pe-7s-graph1 fa-4x"></i>

                                <h1 class="m-xs">$1 206,90</h1>

                                <h3 class="font-extra-bold no-margins text-success">
                                    All Income
                                </h3>
                                <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit vestibulum.</small>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Users Activity</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-share fa-4x"></i>
                                </div>
                                <div class="m-t-xl">
                                    <h3 class="m-b-xs">210</h3>
                            <span class="font-bold no-margins">
                                Social users
                            </span>

                                    <div class="progress m-t-xs full progress-small">
                                        <div style="width: 55%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="55"
                                             role="progressbar" class=" progress-bar progress-bar-success">
                                            <span class="sr-only">35% Complete (success)</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-6">
                                            <small class="stats-label">Pages / Visit</small>
                                            <h4>7.80</h4>
                                        </div>

                                        <div class="col-xs-6">
                                            <small class="stats-label">% New Visits</small>
                                            <h4>76.43%</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Page Views</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-monitor fa-4x"></i>
                                </div>
                                <div class="m-t-xl">
                                    <h1 class="text-success">860k+</h1>
                            <span class="font-bold no-margins">
                                Social users
                            </span>
                                    <br/>
                                    <small>
                                        Lorem Ipsum is simply dummy text of the printing and <strong>typesetting
                                        industry</strong>. Lorem Ipsum has been.
                                    </small>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel stats">
                            <div class="panel-body h-200">
                                <div class="stats-title pull-left">
                                    <h4>Today income</h4>
                                </div>
                                <div class="stats-icon pull-right">
                                    <i class="pe-7s-cash fa-4x"></i>
                                </div>
                                <div class="clearfix"></div>
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-income-chart"></div>
                                </div>
                                <div class="m-t-xs">

                                    <div class="row">
                                        <div class="col-xs-5">
                                            <small class="stat-label">Today</small>
                                            <h4>$230,00 </h4>
                                        </div>
                                        <div class="col-xs-7">
                                            <small class="stat-label">Last week</small>
                                            <h4>$7 980,60 <i class="fa fa-level-up text-success"></i></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                This is standard panel footer
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <!--<th>Class Time</th>-->
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <!--<th>End Time</th>-->
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <!--<th>Class Time</th>-->
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <!--<th>End Time</th>-->
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class all-classes">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Classes History</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div class="row col-lg-12">
                                    <div class="form-group col-lg-2">
                                        <label>Student</label>
                                        <select id="classes-history-filter-student" class="form-control" name="student" />
                                            <option value="all">All</option>
                                            <?php
                                            $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                            $all_students = $this->Parent_model->get_all_students($parent_id);
                                            foreach($all_students as $student){?>
                                            <option value="<?php echo $student['id']?>"><?php echo $student['name']?></option>
                                            <?php } ?> 
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <button id="parent-classes-history-filter-btn"  type="submit" class="btn btn-success">Filter</button>
                                    </div>
                                </div>
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="all-classes-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Lesson</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Lesson</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class unpaid-invoices-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Unpaid Invoices</h2>
                            <small></small>
                            <?php
                                $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                $pay_method =  $this->Parent_model->get_payment_method($parent_id);
                                if($pay_method->fee_type == '2Checkout'){?>
                                <button id="pay_all_button_invoice"  data-id="pay_all" data-toggle="modal" data-target="#pay_checkout_invoice" class="btn btn-success pull-right">Pay All</button>
                            <?php }elseif($pay_method->fee_type  == 'Paypal'){
                                $paypal_url='https://www.sandbox.paypal.com/cgi-bin/webscr';
                                $paypal_id='mani.shah009-facilitator@gmail.com';
                            ?>	
                                <form action="<?php echo $paypal_url; ?>" method="post">
                                    <input type="hidden" name="business" value="<?php echo $paypal_id; ?>">
                                    <input type="hidden" name="cmd" value="_xclick">
                                    <input type="hidden" name="item_name" value="Test Product">
                                    <input type="hidden" name="item_number" value="4566">
                                    <input type="hidden" name="parent_id" value="<?php echo $parent_id; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $pay_method->amount+$pay_method->adjustment; ?>">
                                    <input type="hidden" name="currency_code" value="USD">
                                    <input type="hidden" name="cancel_return" value="https://learnquraan.co.uk/ci/index.php/Parents/panel">
                                    <input type="hidden" name="return" value="https://learnquraan.co.uk/ci/index.php/Parents/panel">
                                    <input type="hidden" name="notify_url" value="https://learnquraan.co.uk/ci/index.php/Parents/pay_paypal_success" />
                                    <button id="pay_all_button_invoice" class="btn btn-success pull-right" type = "submit">Pay All</button>
                                </form>
                            <?php } ?>
                           <!-- <button id="pay_all_button_invoice" class="btn btn-success pull-right">Pay All</button>&ensp; -->
                            <!--<button class="btn btn-success pull-right" style="margin-right: 12px;">Pay Selected</button> -->
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="unpaid-invoices-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="allunpaid" name="allunpaid"/></th>
                                                        <th>Name</th>
                                                        <th>Month</th>
                                                        <th>Invoice Type</th>
                                                        <th>Amount</th>
                                                        <th>Pay Method</th>
                                                        <th>Due Date</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th><input type="checkbox" id="allunpaid" name="allunpaid"/></th>
                                                        <th>Name</th>
                                                        <th>Month</th>
                                                        <th>Invoice Type</th>
                                                        <th>Amount</th>
                                                        <th>Pay Method</th>
                                                        <th>Due Date</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                <?php
                                                    $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                    $all_paid_invoices = $this->Parent_model->get_all_unpaid_invoices($parent_id);
                                                    $months = array('1' => 'Jan',
                                                            '2' => 'Feb',
                                                            '3' => 'March',
                                                            '4' => 'April',
                                                            '5' => 'May',
                                                            '6' => 'June',
                                                            '7' => 'July',
                                                            '8' => 'Aug',
                                                            '9' => 'Sep',
                                                            '10' => 'Oct',
                                                            '11' => 'Nov',
                                                            '12' => 'Dec');
                                                    foreach ($all_paid_invoices as $invoice) {
                                                        $invoice_id = $invoice['id'];
                                                        $parent = $this->Parent_model->get_parent_name_pay_method($invoice['parent_id']);
                                                        if($parent){
                                                            $parent_name = $parent->name;
                                                            $pay = $parent->fee_type;
                                                        }else{
                                                            $parent_name = '';
                                                            $pay = '';
                                                        }
                                                        ?>
                                                            
                                                        <tr>
                                                            <td><input type="checkbox" class="select_checkbox_to_pay" data-id="<?php echo $invoice['id']; ?>" /></td>
                                                            <td><?php echo $parent_name; ?></td>
                                                            <td><?php echo $months[$invoice['month']]; ?></td>
                                                            <td><?php echo $invoice['type']; ?></td>
                                                            <td><?php echo $invoice['amount'] + $invoice['adjustment']; ?></td>
                                                            <td><?php echo $pay; ?></td>
                                                            <td><?php echo $invoice['due_date']; ?></td>
                                                            <td><?php echo $invoice['status']; ?></td>
                                                            <td>
                                                                <?php if($pay == '2Checkout'){?>
                                                                <button data-id="<?php echo $invoice['id']; ?>" data-toggle="modal" data-target="#pay_checkout_invoice" class="btn btn-info btn-sm">Pay Via 2Checkout</button>
                                                                <?php }elseif($pay == 'Paypal'){
                                                                    $paypal_url='https://www.sandbox.paypal.com/cgi-bin/webscr';
                                                                    $paypal_id='mani.shah009-facilitator@gmail.com';
                                                                    ?>
                                                                    <form action="<?php echo $paypal_url; ?>" method="post">
                                                                        <input type="hidden" name="business" value="<?php echo $paypal_id; ?>">
                                                                        <input type="hidden" name="cmd" value="_xclick">
                                                                        <input type="hidden" name="item_name" value="Test Product">
                                                                        <input type="hidden" name="item_number" value="<?php echo $invoice['id']; ?>">
                                                                        <input type="hidden" name="parent_id" value="<?php echo $invoice['parent_id']; ?>">
                                                                        <input type="hidden" name="amount" value="<?php echo $invoice['amount']; ?>">
                                                                        <input type="hidden" name="currency_code" value="USD">
                                                                        <input type="hidden" name="cancel_return" value="https://learnquraan.co.uk/ci/index.php/Parents/panel">
                                                                        <input type="hidden" name="return" value="https://learnquraan.co.uk/ci/index.php/Parents/panel">
                                                                        <input type="hidden" name="notify_url" value="https://learnquraan.co.uk/ci/index.php/Parents/pay_paypal_success" />
                                                                        <button class="btn btn-info btn-sm" data-id="<?php echo $invoice['id']; ?>" type = "submit">Pay Via Paypal</button>
                                                                    </form>
                                                                <?php } ?>
                                                            </td>
                                                        </tr>
                                                    <?php }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class paid-invoices-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Paid Invoices</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="paid-invoices-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Month</th>
                                                        <th>Invoice Type</th>
                                                        <th>Amount</th>
                                                        <th>Pay Method</th>
                                                        <th>Due Date</th>
                                                        <th>Status</th>
                                                
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Month</th>
                                                        <th>Invoice Type</th>
                                                        <th>Amount</th>
                                                        <th>Pay Method</th>
                                                        <th>Due Date</th>
                                                        <th>Status</th>
                                                        
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                        $all_paid_invoices = $this->Parent_model->get_all_paid_invoices($parent_id);
                                                        $months = array('1' => 'Jan',
                                                            '2' => 'Feb',
                                                            '3' => 'March',
                                                            '4' => 'April',
                                                            '5' => 'May',
                                                            '6' => 'June',
                                                            '7' => 'July',
                                                            '8' => 'Aug',
                                                            '9' => 'Sep',
                                                            '10' => 'Oct',
                                                            '11' => 'Nov',
                                                            '12' => 'Dec');
                                                        foreach ($all_paid_invoices as $invoice) {
                                                            $invoice_id = $invoice['id'];
                                                            $parent = $this->Parent_model->get_parent_name_pay_method($invoice['parent_id']);
                                                            if($parent){
                                                                $parent_name = $parent->name;
                                                                $pay = $parent->fee_type;
                                                            }else{
                                                                $parent_name = '';
                                                                $pay = '';
                                                            }
                                                            ?>
                                                            
                                                            <tr>
                                                                <td><?php echo $invoice['id']; ?></td>
                                                                <td><?php echo $parent_name; ?></td>
                                                                <td><?php echo $months[$invoice['month']]; ?></td>
                                                                <td><?php echo $invoice['type']; ?></td>
                                                                <td><?php echo $invoice['amount']; ?></td>
                                                                <td><?php echo $pay; ?></td>
                                                                <td><?php echo $invoice['due_date']; ?></td>
                                                                <td><?php echo $invoice['status']; ?></td>
                                                            </tr>
                                                        <?php }

                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class new-complaint-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Add New Complaint</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <form id="add-complaint-form" action="javascript:;" method="post">
                                <div class="tab-content">
                                    <div id="step1" class="p-m tab-pane active">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="form-group col-lg-4">
                                                        <label>Student Name</label>
                                                        <select class="form-control" name="complaint-student-id" required="">
                                                            <option></option>
                                                            <?php
                                                                $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                                $all_names = $this->Parent_model->get_all_students_names($parent_id);
                                                                foreach($all_names as $name){?>
                                                                    <option value="<?php echo $name['id']?>"><?php echo $name['name']?></option>

                                                               <?php  }
                                                            ?>   
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-lg-4">
                                                        <label>Complaint Of</label>
                                                        <select class="form-control" name="complaint-for" required="">
                                                            <option></option>
                                                            <option value="teacher">Teacher</option>
                                                            <option value="manager">Manager</option>   
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-lg-4">
                                                        <label>Email Address</label>
                                                        <input type="email" class="form-control" name="complaint-email" placeholder="user@email.com" required="">
                                                    </div>
                                                    <div class="form-group col-lg-12">
                                                        <label>Complaint</label>
                                                        <textarea  class="form-control" name="complaint" required="required"></textarea>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="text-right m-t-xs">
                                            <button id="clear-complaint-form" class="btn btn-default">Clear</button>
                                            <button id="add-complaint" type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </div>    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--<div class="common-class complaint-history-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            
                            <h2 class="font-light m-b-xs">Complaint History</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="complaints-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Student Name</th>
                                                        <th>Parent Name</th>
                                                        <th>Teacher Name</th>
                                                        <th>Complaint</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Student Name</th>
                                                        <th>Parent Name</th>
                                                        <th>Teacher Name</th>
                                                        <th>Complaint</th>
                                                        <th>Remarks</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                <?php
                                                    //$parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                    //$all_complaints = $this->Parent_model->get_all_complaints($parent_id);
                                                    //foreach ($all_complaints as $complaint) {
                                                           /* $teacher = $this->Parent_model->get_student_teacher($complaint['teacher_id']);
                                                            if($teacher){
                                                                $teacher_name = $teacher->name;
                                                            }else{
                                                                $teacher_name = '';
                                                            }
                                                            $student = $this->Parent_model->get_student_name($complaint['student_id']);
                                                            if($student){
                                                                $student_name = $student->name;
                                                            }else{
                                                                $student_name = '';
                                                            }
                                                            $parent = $this->Parent_model->get_parent_name($complaint['parent_id']);
                                                            if($parent){
                                                                $parent_name = $parent->name;
                                                            }else{
                                                                $parent_name = '';
                                                            } */
                                                            ?>
                                                        <tr>
                                                            <td><?php //echo $complaint['id']; ?></td>
                                                            <td><?php //echo $student_name; ?></td>
                                                            <td><?php //echo $parent_name; ?></td>
                                                            <td><?php //echo $teacher_name; ?></td>
                                                            <td><?php //echo $complaint['complaint']; ?></td>
                                                            <td><?php //echo $complaint['remarks']; ?></td>
                                                            <td><?php //echo $complaint['status']; ?></td>
                                                        </tr>
                                                    <?php // }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="common-class complaint-history-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Complaint History</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row social-board">
                    <?php 
                    $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                    $all_complaints = $this->Parent_model->get_parent_complaints($parent_id);
                    foreach ($all_complaints as $complaint) {?>
                    <div class="col-lg-4 hpanel hgreen">
                        <div class="panel-body">
                            <div class="media social-profile clearfix">
                                <span class="label label-success pull-right">NEW</span>
                                <a class="pull-left">
                                    <!-- <img src="images/a7.jpg" alt="profile-picture"> -->
                                </a>
                                  
                                <div class="media-body">
                                    <h5><?php echo $complaint['pname']?></h5>
                                    <small class="text-muted"></small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['tname']?></h5>
                                    <small class="text-muted">Teacher</small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['sname']?></h5>
                                    <small class="text-muted">Student</small>
                                </div>
                            </div>

                            <div class="social-content m-t-md">
                                <?php echo $complaint['complaint']?>
                                <!--<img class="img-responsive m-t-md" src="images/p2.jpg" alt=""> -->

                            </div>
                        </div>
                        <div class="panel-footer">
                        <?php 
                            $remarks = json_decode($complaint['remarks'] , true);
                            if(count($remarks) != 0){
                            foreach ($remarks as $remark) {?>
                            <div class="social-talk">
                                <div class="media social-profile clearfix">
                                    <a class="pull-left">
                                        <!--<img src="images/a1.jpg" alt="profile-picture"> -->
                                    </a>
                                    <div class="media-body">
                                        <span class="font-bold"><?php echo $remark['name']?></span>
                                        <small class="text-muted"><?php echo $remark['date']?></small>
                                        <div class="social-content">
                                            <?php echo $remark['remarks']?>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                            <?php } }?>
                            <div class="social-form social-form-<?php echo $complaint['id']?>">
                                <input class="form-control" placeholder="Your comment" id="complaint-comment" data-complaint-id="<?php echo $complaint['id']?>">
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        
        
        <div class="common-class all-student-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Kids Info</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Class Records</th>
                                                        <th>Teacher</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                        $all_students = $this->Parent_model->get_all_students($parent_id);
                                                        foreach ($all_students as $student) {
                                                            $course = $this->Parent_model->get_student_course($student['course_id']);
                                                             if($course){
                                                                $course_name = $course->name;
                                                            }else{
                                                                $course_name = '';
                                                            }
                                                            $manager = $this->Parent_model->get_student_manager($student['manage_id']);
                                                            if($manager){
                                                                $manager_name = $manager->name;
                                                            }else{
                                                                $manager_name = '';
                                                            }
                                                            $teacher = $this->Parent_model->get_student_teacher($student['teacher_id']);
                                                            if($teacher){
                                                                $teacher_name = $teacher->name;
                                                            }else{
                                                                $teacher_name = '';
                                                            }
                                                            $country = $this->Parent_model->get_student_country($student['parent_id']);
                                                            if($country){
                                                                $country_code = $country->code;
                                                            }else{
                                                                $country_code = '';
                                                            }
                                                            $fname = $this->Parent_model->get_student_fname($student['parent_id']);
                                                            if($fname){
                                                                $father_name = $fname->name;
                                                            }else{
                                                                $father_name = '';
                                                            }
                                                            $classrecords = $this->Parent_model->get_student_classrecords($student['id']);
                                                            ?>
                                                        <tr>
                                                            
                                                            <td> <?php echo $student['name'] ?> </td>
                                                            <td> <?php echo $father_name ?> </td>
                                                            <td> <?php echo $country_code ?> </td>
                                                            <td> <?php echo $student['gender'] ?> </td>
                                                            <td> <?php echo $course_name ?> </td>
                                                            <td> <?php echo $classrecords ?> </td>
                                                            <td> <?php echo $teacher_name ?> </td>
                                                            <td> <?php echo $manager_name ?> </td>
                                                            <td class=" action"><button data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#student_class_history" class="btn btn-info btn-sm">History</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#schedule_student_test">Test</button></td>
                                                        </tr>
                                                            
                                                    <?php   }  
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class view-books">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Course Books</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="learning-material-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                        $all_books = $this->Parent_model->get_course_books();
                                                        foreach ($all_books as $book) {
                                                        	$book_id = $book['id'];
                                                            $course = $this->Parent_model->get_student_course($student['course_id']);
                                                             if($course){
                                                                $course_name = $course->name;
                                                            }else{
                                                                $course_name = '';
                                                            }
                                                            $chap_nums = $this->Parent_model->get_chap_num($book['id']);
												            if($chap_nums){
												                $chap_nums = $chap_nums;
												            }else{
												                $chap_nums = '0';
												            }
												            $total_pages = $this->Parent_model->get_total_pages($book['id']);
												            if($chap_nums){
												                $total_pages = $total_pages;
												            }else{
												                $total_pages = '0';
												            }
                                                            ?>
                                                        <tr>
                                                            <td> <?php echo $book['id'] ?> </td>
                                                            <td> <?php echo $book['book_name'] ?> </td>
                                                            <td> <?php echo $course_name ?> </td>
                                                            <td> <?php echo $chap_nums ?> </td>
                                                            <td> <?php echo $total_pages ?> </td>
                                                            <td> <?php echo '<button id="read-book" data-id="'.$book_id.'" data-book="'.$book_id.'" class="btn btn-info btn-sm">Read</button>' ?> </td>
                                                        </tr>
                                                            
                                                    <?php   }  
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="common-class scheduling">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                        
                            <h2 class="font-light m-b-xs">Time Table</h2>
                            <small></small>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel no-gap">
                            <div class="panel-heading"></div> 
                            <div class="panel-body no-border">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="form-group col-lg-6 no-gap">
                                                <label>Select Student</label>
                                                <select id="select-student-timetable" class="form-control m-b" name="timetable_student_name">
                                                    <option></option>
                                                    <?php
                                                        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                        $all_names = $this->Parent_model->get_all_students_names($parent_id);
                                                        foreach($all_names as $name){?>
                                                            <option value="<?php echo $name['id']?>"><?php echo $name['name']?></option>

                                                <?php  }
                                                    ?>  
                                                </select>
                                            </div>        
                                              
                                        </div>
                                    </div>        
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-body no-border">
                                <div class="table-responsive">
                                <table id="show-schedule-table" cellpadding="1" cellspacing="1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Day</th>
                                            <th>Teacher</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Course</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Day</th>
                                            <th>Teacher</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Course</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <tr>
                                            <td>Monday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Tuesday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Wednesday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                        <tr>
                                            <td>Thursday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Friday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Saturday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Sunday</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--- edit pay checkout modal -->

    <div class="modal fade" id="pay_checkout_invoice" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="post" class="form-horizontal" action='https://www.2checkout.com/checkout/purchase'>
                                                <div class="row">
                                                    <input id="edit_student_id" type="hidden"  class="form-control" name="country_id" required />
                                                    <input type='hidden' name='sid' value='102983281' />
                                                    <input type='hidden' name='mode' value='2CO' />
                                                    <input type='hidden' name='li_0_type' value='product' />
                                                    <input type='hidden' name='li_0_name' value='Online Quran Classes' />
                                                    <input type="hidden" name="li_#_recurrence" value="1 Month">
                                                    <input type="hidden" name="li_#_duration" value="Forever">
                                                    <input id="pay_invoice_price" type='hidden' name='li_0_price' value='50' />
                                                    <input id="pay_invoice_id" type='hidden' name='inv_id' value='34' />
                                                    <input id="pay_invoice_parent_id" type='hidden' name='parent_id' value='34' />
                                                    <div class="col-lg-12">
                                                        <div class="form-group col-lg-12">
                                                            <label>Full Name</label>
                                                            <input  type="text"  class="form-control" name="card_holder_name" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Street Address</label>
                                                            <input  type="text"  class="form-control" name="street_address" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Street Address 2 (Optional)</label>
                                                            <input  type="text"  class="form-control" name="street_address2" >
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>City</label>
                                                            <input  type="text"  class="form-control" name="city" required />
                                                        </div>
                                                         <div class="form-group col-lg-12">
                                                            <label>State</label>
                                                            <input type="text"  class="form-control" name="state" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Zip</label>
                                                            <input type="text"  class="form-control" name="zip" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Country</label>
                                                            <input  type="text"  class="form-control" name="country" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Email</label>
                                                            <input type="text"  class="form-control" name="email" required />
                                                        </div>
                                                        <div class="form-group col-lg-12">
                                                            <label>Phone</label>
                                                            <input  type="text"  class="form-control" name="phone" required />
                                                        </div>

                                                        <input name='submit' type='submit' class="btn btn-info" value='Checkout' />
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    </div> 
                                                           
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div id="mydiv" style="display:none;">
        <iframe id="frame" src="" width="100%" height="100%">
        </iframe>
    </div>

    <div id="readbook" style="display:none;">
        <iframe id="readbookframe" src="" width="100%" height="100%">
        </iframe>
    </div>
    <!-- end pay checkout modal -->

    <!--- class modal -->
    <div class="modal fade" id="student_class_history" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="text-center"><strong>Class History</strong></div>
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-classes-history-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end class history modal -->

    <!--- view class_remarks modal -->

    <div class="modal fade" id="view_class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="view_lesson_teach"  type="text"  class="form-control" name="lesson_teach" disabled />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap" style="padding-top: 26px;">
                                                            <label>Class Remaks</label>
                                                            <textarea id="view_class_end_remarks" type="text"  class="form-control" name="class_remarks" disabled /></textarea>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end view class remarks modal -->
    </div>

    <!-- Footer-->
    <!--<footer class="footer">
        <span class="pull-right">
            Example text
        </span>
        Company 2015-2020
    </footer> -->

</div>

<!-- Vendor scripts -->
<script src="<?php echo base_url()?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>public/js/curvedLines.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/metisMenu.min.js"></script>
<script src="<?php echo base_url()?>public/js/icheck.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.peity.min.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/moment.min.js"></script>
<script src="<?php echo base_url()?>public/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url()?>public/js/toastr.min.js"></script>
<script src="<?php echo base_url()?>public/js/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap-clockpicker.min.js"></script>
<script src="https://www.2checkout.com/static/checkout/javascript/direct.min.js"></script>


<!-- App scripts -->
<script src="<?php echo base_url()?>public/js/homer.js"></script>
<script src="<?php echo base_url()?>public/js/charts.js"></script>
<script src="<?php echo base_url()?>public/js/parent/app.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url()?>public/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>
</body>
</html>