<?php
if (!isset($this->session->userdata['teacher_logged_in'])) {
    header("location:https://learnquraan.co.uk/ci/index.php/teacher");
//error_reporting(0);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Page title -->
    <title>LEARN QURAN | Teacher Panel</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/metisMenu.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.print.css" media='print'/>
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/fullcalendar.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/sweet-alert.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/bootstrap-clockpicker.min.css" />


    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/helper.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/style.css">
    <style>

        .parent-content {
            padding: 20px;
            width: 100%;
        }

        .parent-table {
            padding: 20px;
            width: 100%;
        }

        .common-class {
            display: none;
        }

        .common-class.active {
            display: block;
            width: 100%;
        }

        .no-gap {
            margin: 0 !important;
        }

        .double-pad-top {
            padding-top: 20px;
        }

        .no-border {
            border: 0 none !important;
        }

        #d_h_v{
            cursor:pointer;
        }

        .intro {
            float: left;
            padding: 20px 0;
            height: 60px;
            font-weight: 600;
            color: #34495e;
            font-size: 14px;
        }

        .social-board{
            padding-top: 21px;
        }

        .social-talk-holder {
            min-height: 132px;
            max-height: 132px;
            overflow-y: auto;
        }

        #reopen-frame {
            cursor: pointer;
        }

        .hpanel table th {
          background: #3f5872 none repeat scroll 0 0;
          color: #fff;
        }

        .hpanel table tr td:first-child {
          width: 100px;
        }

        .hpanel table tr td {
          width: 200px;
        }

        .table-box {
            background: #0486ca none repeat scroll 0 0;
            color: #fff;
            font-size: 12px;
            line-height: 15px;
            position: relative;
            text-align: center;
        }

        .table-box p {
            margin-top: 10px;
        }

        .close-btn {
          color: #fff !important;
          cursor: pointer;
          float: right;
          font-size: 12px;
          padding: 2px 5px;
          position: absolute;
          right: 0;
          text-align: right;
          top: 0;
        }

        .mt-10 {
            margin-top: 10px;
        }

        iframe {position:absolute;
            z-index:1;
            top:0px;
            left:0px;
        }


    </style>

</head>
<body class="fixed-navbar fixed-sidebar relative">
<input type="hidden" id="login-name" value="<?php echo $this->session->userdata['teacher_logged_in']['username'] ?>"></input>
<!-- Simple splash screen-->
<div class="splash">
<div class="splash-title"><h1>Learn Quran Academy</h1><div class="spinner"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div> </div> </div>
<!--[if lt IE 7]>
<p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<!-- Header -->
<div id="header">
    <div id="logo" class="light-version">
        <span>
            Learn Quran
        </span>
    </div>
    <nav role="navigation">
        <div class="header-link hide-menu"><i class="fa fa-bars"></i></div>
        <div class="small-logo">
            <span class="text-primary">HOMER APP</span>
        </div>
        <!--<form role="search" class="navbar-form-custom" method="post" action="#">
            <div class="form-group">
                <input type="text" placeholder="Search something special" class="form-control" name="search">
            </div>
        </form> -->
        <div class="mobile-menu">
            <button type="button" class="navbar-toggle mobile-menu-toggle" data-toggle="collapse" data-target="#mobile-collapse">
                <i class="fa fa-chevron-down"></i>
            </button>
            <div class="collapse mobile-navbar" id="mobile-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="" href="login.html">Login</a>
                    </li>
                    <li>
                        <a class="" href="login.html">Logout</a>
                    </li>
                    <li>
                        <a class="" href="profile.html">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar-right">
            <ul class="nav navbar-nav no-borders">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-speaker"></i>
                    </a>
                    <?php 
                        $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id']; 
                        $new_notifications = $this->Teacher_model->get_new_notifications($teacher_id);
                        //echo json_encode($new_notifications) ;
                    ?>
                    <ul class="dropdown-menu hdropdown notification animated flipInX">
                        <? foreach($new_notifications as $noti){?>
                        <li>
                            <a data-id="<?php echo $noti['id']?>" data-topggle="modal" data-target="#view_single_notification" >
                                <span class="label label-success">NEW</span> <?php echo $noti['content']?>
                            </a>
                        </li>
                        <?php } ?>
                        <li class="summary"><a href="javascript:;">See all notifications</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-mail"></i>
                        <span class="label label-success">4</span>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <div class="title">
                            You have 4 new messages
                        </div>
                        <li>
                            <a>
                                It is a long established.
                            </a>
                        </li>
                        <li>
                            <a>
                                There are many variations.
                            </a>
                        </li>
                        <li>
                            <a>
                                Lorem Ipsum is simply dummy.
                            </a>
                        </li>
                        <li>
                            <a>
                                Contrary to popular belief.
                            </a>
                        </li>
                        <li class="summary"><a href="javascript:;">See All Messages</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle label-menu-corner" href="javascript:;" data-toggle="dropdown">
                        <i class="pe-7s-upload pe-rotate-90"></i>
                    </a>
                    <ul class="dropdown-menu hdropdown animated flipInX">
                        <li>
                            <a data-id="<?php $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id']; echo $teacher_id ;?>" data-toggle="modal" data-target="#edit_profile" data-backdrop="static" data-keyboard="false" >
                                Edit Profile
                            </a>
                        </li>
                        <li>
                            <a>
                                Change Password
                            </a>
                        </li>
                        <li>
                            <a id="teacher-logout" href="javascript:;">
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <div class="intro">
        <span>Asalam-o-Alaikum , </span>
        <span><?php $teacher_name = $this->session->userdata['teacher_logged_in']['username']; echo $teacher_name ;?></span>
    </div>
</div>

<!-- Navigation -->
<aside id="menu">
    <div id="navigation">
        <div class="profile-picture">
            <a href="javascript:;">
                <img src="<?php echo base_url()?>public/images/profile.jpg" class="img-circle m-b" alt="logo">
            </a>
        </div>

        <ul class="nav" id="side-menu">
            <li class="active">
                <a data-tab="dashboard-tab" href="javascript:;" class="j_all-parent"><span class="nav-label">Dashboard</span></a>
            </li>
            <!--<li>
                <a href="javascript:;"><span class="nav-label">Classes</span><span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li><a href="javascript:;" class="j_all-parent" data-tab="today-classes">Today Classes</a></li>
                </ul>
            </li> -->
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="view-books">Books</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="all-student-tab">Students</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="scheduling">Schedule</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="complaint-history-tab">Complaints</a>
            </li>
            <li>
                <a href="javascript:;" class="j_all-parent" data-tab="notifications">Notifications</a>
            </li>
            
        </ul>
    </div>
</aside>

<!-- Main Wrapper -->
<div id="wrapper">
    <div class="common-outter">
        <div class="common-class dashboard-tab active">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12 text-center m-t-md">
                        <h2>
                            Welcome to Learn Quran Teacher Panel
                        </h2>
                    </div>
                </div>
                <!--<div class="row">
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Today Classes
                                </h3>
                                <h1><?php 
                                    //$teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
                                    //echo $this->Teacher_model->get_total_classes($teacher_id); 
                                    ?>
                                </h1>   
                            </div> 
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Taken Classes
                                </h3>
                                <h1><?php 
                                    //$teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
                                    //echo $this->Teacher_model->get_taken_classes($teacher_id); 
                                    ?>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Pending Classes
                                </h3>
                                <h1><?php
                                    //$teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id']; 
                                    //echo $this->Teacher_model->get_remianing_classes($teacher_id); ?>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="hpanel">
                            <div class="panel-body text-center h-100">
                                <h3 class="font-extra-bold no-margins text-success">
                                    Total Students
                                </h3>
                                <h1><?php
                                    //$teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id']; 
                                    //echo $this->Teacher_model->get_total_students($teacher_id); 
                                    ?>
                                    
                                </h1>
                            </div>
                        </div>
                    </div>    
                </div> -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classess-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Course</th>
                                                        <th>History</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Course</th>
                                                        <th>History</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class today-classes">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading"></div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="classess-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="common-class complaint-history-tab">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Complaint History</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row social-board">
                    <?php 
                    $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
                    $all_complaints = $this->Teacher_model->get_teacher_complaints($teacher_id);
                    foreach ($all_complaints as $complaint) {?>
                    <div class="col-lg-4 hpanel hgreen">
                        <div class="panel-body">
                            <div class="media social-profile clearfix">
                                <span class="label label-success pull-right">NEW</span>
                                <a class="pull-left">
                                    <!-- <img src="images/a7.jpg" alt="profile-picture"> -->
                                </a>
                                  
                                <div class="media-body">
                                    <h5><?php echo $complaint['pname']?></h5>
                                    <small class="text-muted"></small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['tname']?></h5>
                                    <small class="text-muted">Teacher</small>
                                </div>
                                <div class="media-body">
                                    <h5><?php echo $complaint['sname']?></h5>
                                    <small class="text-muted">Student</small>
                                </div>
                            </div>

                            <div class="social-content m-t-md">
                                <?php echo $complaint['complaint']?>
                                <!--<img class="img-responsive m-t-md" src="images/p2.jpg" alt=""> -->

                            </div>
                        </div>
                        <div class="panel-footer">
                        <div class="social-talk-holder">
                        <?php 
                            $remarks = json_decode($complaint['remarks'] , true);
                            if(count($remarks) != 0){
                            foreach ($remarks as $remark) {?>
                                <div class="social-talk">
                                    <div class="media social-profile clearfix">
                                        <a class="pull-left">
                                            <!--<img src="images/a1.jpg" alt="profile-picture"> -->
                                        </a>
                                        <div class="media-body">
                                            <span class="font-bold"><?php echo $remark['name']?></span>
                                            <small class="text-muted"><?php echo $remark['date']?></small>
                                            <div class="social-content">
                                                <?php echo $remark['remarks']?>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            <?php } }?>
                            </div>
                            <div class="social-form social-form-<?php echo $complaint['id']?>">
                                <input class="form-control" placeholder="Your comment" id="complaint-comment" data-complaint-id="<?php echo $complaint['id']?>">
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>


        <div class="common-class view-books">
            <div class="content">
            <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <h2 class="font-light m-b-xs">Course Books</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Book Name</th>
                                                        <th>Course </th>
                                                        <th>Num of Chapters</th>
                                                        <th>Total Pages</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        //$parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
                                                        $all_books = $this->Teacher_model->get_course_books();
                                                        foreach ($all_books as $book) {
                                                            $book_id = $book['id'];
                                                            $course = $this->Teacher_model->get_all_course();
                                                             if($course){
                                                                $course_name = $course->name;
                                                            }else{
                                                                $course_name = '';
                                                            }
                                                            $chap_nums = $this->Teacher_model->get_chap_num($book['id']);
                                                            if($chap_nums){
                                                                $chap_nums = $chap_nums;
                                                            }else{
                                                                $chap_nums = '0';
                                                            }
                                                            $total_pages = $this->Teacher_model->get_total_pages($book['id']);
                                                            if($chap_nums){
                                                                $total_pages = $total_pages;
                                                            }else{
                                                                $total_pages = '0';
                                                            }
                                                            ?>
                                                        <tr>
                                                            <td> <?php echo $book['id'] ?> </td>
                                                            <td> <?php echo $book['book_name'] ?> </td>
                                                            <td> <?php echo $course_name ?> </td>
                                                            <td> <?php echo $chap_nums ?> </td>
                                                            <td> <?php echo $total_pages ?> </td>
                                                            <td> <?php echo '<button id="read-book" data-id="'.$book_id.'" data-book="'.$book_id.'" class="btn btn-info btn-sm">Read</button>' ?> </td>
                                                        </tr>
                                                            
                                                    <?php   }  
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="common-class all-student-tab">
            <div class="content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="studentt-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Country</th>
                                                        <th>Gender</th>
                                                        <th>Course</th>
                                                        <th>Manager</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php 
                                                        $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
                                                        $all_students = $this->Teacher_model->get_all_students($teacher_id);
                                                        foreach ($all_students as $student) {
                                                            $student_id = $student['id'];
                                                            $course = $this->Teacher_model->get_student_course($student['course_id']);
                                                             if($course){
                                                                $course_name = $course->name;
                                                            }else{
                                                                $course_name = '';
                                                            }
                                                            $manager = $this->Teacher_model->get_student_manager($student['manage_id']);
                                                            if($manager){
                                                                $manager_name = $manager->name;
                                                            }else{
                                                                $manager_name = '';
                                                            }
                                                            $country = $this->Teacher_model->get_student_country($student['parent_id']);
                                                            if($country){
                                                                $country_code = $country->code;
                                                            }else{
                                                                $country_code = '';
                                                            }
                                                            $fname = $this->Teacher_model->get_student_fname($student['parent_id']);
                                                            if($fname){
                                                                $father_name = $fname->name;
                                                            }else{
                                                                $father_name = '';
                                                            }
                                                            $classrecords = $this->Teacher_model->get_student_classrecords($student['id']);
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $student['id']?></td>
                                                            <td><?php echo $student['name']?></td>
                                                            <td><?php echo $father_name ?></td>
                                                            <td><?php echo $country_code ?></td>
                                                            <td><?php echo $student['gender']?></td>
                                                            <td><?php echo $course_name ?></td>
                                                            <td><?php echo $manager_name ?></td>
                                                            <td class=" action"><button data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#student_class_history" class="btn btn-info btn-sm">History</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#schedule_student_test">Test</button>&nbsp;<button class="btn btn-danger btn-sm demo4 delete-student" data-id="<?php echo $student['id']?>" data-toggle="modal" data-target="#add_student_notes">Add Note</button></td>
                                                        </tr>        
                                                            
                                                        <?php }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="common-class scheduling">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">Scheduling</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-body no-border">
                                <div class="table-responsive">
                                <table id="show-schedule-table" cellpadding="1" cellspacing="1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                        <th>Friday</th>
                                        <th>Saturday</th>
                                        <th>Sunday</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1:00 AM</td>
                                        <td class="Monday_1_00_AM"></td>
                                        <td class="Tuesday_1_00_AM"></td>
                                        <td class="Wednesday_1_00_AM"></td>
                                        <td class="Thursday_1_00_AM"></td>
                                        <td class="Friday_1_00_AM"></td>
                                        <td class="Saturday_1_00_AM"></td>
                                        <td class="Sunday_1_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>1:30 AM</td>
                                        <td class="Monday_1_30_AM"></td>
                                        <td class="Tuesday_1_30_AM"></td>
                                        <td class="Wednesday_1_30_AM"></td>
                                        <td class="Thursday_1_30_AM"></td>
                                        <td class="Friday_1_30_AM"></td>
                                        <td class="Saturday_1_30_AM"></td>
                                        <td class="Sunday_1_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:00 AM</td>
                                        <td class="Monday_2_00_AM"></td>
                                        <td class="Tuesday_2_00_AM"></td>
                                        <td class="Wednesday_2_00_AM"></td>
                                        <td class="Thursday_2_00_AM"></td>
                                        <td class="Friday_2_00_AM"></td>
                                        <td class="Saturday_2_00_AM"></td>
                                        <td class="Sunday_2_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>2:30 AM</td>
                                        <td class="Monday_2_30_AM"></td>
                                        <td class="Tuesday_2_30_AM"></td>
                                        <td class="Wednesday_2_30_AM"></td>
                                        <td class="Thursday_2_30_AM"></td>
                                        <td class="Friday_2_30_AM"></td>
                                        <td class="Saturday_2_30_AM"></td>
                                        <td class="Sunday_2_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:00 AM</td>
                                        <td class="Monday_3_00_AM"></td>
                                        <td class="Tuesday_3_00_AM"></td>
                                        <td class="Wednesday_3_00_AM"></td>
                                        <td class="Thursday_3_00_AM"></td>
                                        <td class="Friday_3_00_AM"></td>
                                        <td class="Saturday_3_00_AM"></td>
                                        <td class="Sunday_3_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>3:30 AM</td>
                                        <td class="Monday_3_30_AM"></td>
                                        <td class="Tuesday_3_30_AM"></td>
                                        <td class="Wednesday_3_30_AM"></td>
                                        <td class="Thursday_3_30_AM"></td>
                                        <td class="Friday_3_30_AM"></td>
                                        <td class="Saturday_3_30_AM"></td>
                                        <td class="Sunday_3_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>4:00 AM</td>
                                        <td class="Monday_4_00_AM"></td>
                                        <td class="Tuesday_4_00_AM"></td>
                                        <td class="Wednesday_4_00_AM"></td>
                                        <td class="Thursday_4_00_AM"></td>
                                        <td class="Friday_4_00_AM"></td>
                                        <td class="Saturday_4_00_AM"></td>
                                        <td class="Sunday_4_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:30 AM</td>
                                        <td class="Monday_4_30_AM"></td>
                                        <td class="Tuesday_4_30_AM"></td>
                                        <td class="Wednesday_4_30_AM"></td>
                                        <td class="Thursday_4_30_AM"></td>
                                        <td class="Friday_4_30_AM"></td>
                                        <td class="Saturday_4_30_AM"></td>
                                        <td class="Sunday_4_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:00 AM</td>
                                        <td class="Monday_5_00_AM"></td>
                                        <td class="Tuesday_5_00_AM"></td>
                                        <td class="Wednesday_5_00_AM"></td>
                                        <td class="Thursday_5_00_AM"></td>
                                        <td class="Friday_5_00_AM"></td>
                                        <td class="Saturday_5_00_AM"></td>
                                        <td class="Sunday_5_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:30 AM</td>
                                        <td class="Monday_5_30_AM"></td>
                                        <td class="Tuesday_5_30_AM"></td>
                                        <td class="Wednesday_5_30_AM"></td>
                                        <td class="Thursday_5_30_AM"></td>
                                        <td class="Friday_5_30_AM"></td>
                                        <td class="Saturday_5_30_AM"></td>
                                        <td class="Sunday_5_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:00 AM</td>
                                        <td class="Monday_6_00_AM"></td>
                                        <td class="Tuesday_6_00_AM"></td>
                                        <td class="Wednesday_6_00_AM"></td>
                                        <td class="Thursday_6_00_AM"></td>
                                        <td class="Friday_6_00_AM"></td>
                                        <td class="Saturday_6_00_AM"></td>
                                        <td class="Sunday_6_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>6:30 AM</td>
                                        <td class="Monday_6_30_AM"></td>
                                        <td class="Tuesday_6_30_AM"></td>
                                        <td class="Wednesday_6_30_AM"></td>
                                        <td class="Thursday_6_30_AM"></td>
                                        <td class="Friday_6_30_AM"></td>
                                        <td class="Saturday_6_30_AM"></td>
                                        <td class="Sunday_6_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:00 AM</td>
                                        <td class="Monday_7_00_AM"></td>
                                        <td class="Tuesday_7_00_AM"></td>
                                        <td class="Wednesday_7_00_AM"></td>
                                        <td class="Thursday_7_00_AM"></td>
                                        <td class="Friday_7_00_AM"></td>
                                        <td class="Saturday_7_00_AM"></td>
                                        <td class="Sunday_7_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>7:30 AM</td>
                                        <td class="Monday_7_30_AM"></td>
                                        <td class="Tuesday_7_30_AM"></td>
                                        <td class="Wednesday_7_30_AM"></td>
                                        <td class="Thursday_7_30_AM"></td>
                                        <td class="Friday_7_30_AM"></td>
                                        <td class="Saturday_7_30_AM"></td>
                                        <td class="Sunday_7_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:00 AM</td>
                                        <td class="Monday_8_00_AM"></td>
                                        <td class="Tuesday_8_00_AM"></td>
                                        <td class="Wednesday_8_00_AM"></td>
                                        <td class="Thursday_8_00_AM"></td>
                                        <td class="Friday_8_00_AM"></td>
                                        <td class="Saturday_8_00_AM"></td>
                                        <td class="Sunday_8_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>8:30 AM</td>
                                        <td class="Monday_8_30_AM"></td>
                                        <td class="Tuesday_8_30_AM"></td>
                                        <td class="Wednesday_8_30_AM"></td>
                                        <td class="Thursday_8_30_AM"></td>
                                        <td class="Friday_8_30_AM"></td>
                                        <td class="Saturday_8_30_AM"></td>
                                        <td class="Sunday_8_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:00 AM</td>
                                        <td class="Monday_9_00_AM"></td>
                                        <td class="Tuesday_9_00_AM"></td>
                                        <td class="Wednesday_9_00_AM"></td>
                                        <td class="Thursday_9_00_AM"></td>
                                        <td class="Friday_9_00_AM"></td>
                                        <td class="Saturday_9_00_AM"></td>
                                        <td class="Sunday_9_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:30 AM</td>
                                        <td class="Monday_9_30_AM"></td>
                                        <td class="Tuesday_9_30_AM"></td>
                                        <td class="Wednesday_9_30_AM"></td>
                                        <td class="Thursday_9_30_AM"></td>
                                        <td class="Friday_9_30_AM"></td>
                                        <td class="Saturday_9_30_AM"></td>
                                        <td class="Sunday_9_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:00 AM</td>
                                        <td class="Monday_10_00_AM"></td>
                                        <td class="Tuesday_10_00_AM"></td>
                                        <td class="Wednesday_10_00_AM"></td>
                                        <td class="Thursday_10_00_AM"></td>
                                        <td class="Friday_10_00_AM"></td>
                                        <td class="Saturday_10_00_AM"></td>
                                        <td class="Sunday_10_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:30 AM</td>
                                        <td class="Monday_10_30_AM"></td>
                                        <td class="Tuesday_10_30_AM"></td>
                                        <td class="Wednesday_10_30_AM"></td>
                                        <td class="Thursday_10_30_AM"></td>
                                        <td class="Friday_10_30_AM"></td>
                                        <td class="Saturday_10_30_AM"></td>
                                        <td class="Sunday_10_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:00 AM</td>
                                        <td class="Monday_11_00_AM"></td>
                                        <td class="Tuesday_11_00_AM"></td>
                                        <td class="Wednesday_11_00_AM"></td>
                                        <td class="Thursday_11_00_AM"></td>
                                        <td class="Friday_11_00_AM"></td>
                                        <td class="Saturday_11_00_AM"></td>
                                        <td class="Sunday_11_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:30 AM</td>
                                        <td class="Monday_11_30_AM"></td>
                                        <td class="Tuesday_11_30_AM"></td>
                                        <td class="Wednesday_11_30_AM"></td>
                                        <td class="Thursday_11_30_AM"></td>
                                        <td class="Friday_11_30_AM"></td>
                                        <td class="Saturday_11_30_AM"></td>
                                        <td class="Sunday_11_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:00 AM</td>
                                        <td class="Monday_12_00_AM"></td>
                                        <td class="Tuesday_12_00_AM"></td>
                                        <td class="Wednesday_12_00_AM"></td>
                                        <td class="Thursday_12_00_AM"></td>
                                        <td class="Friday_12_00_AM"></td>
                                        <td class="Saturday_12_00_AM"></td>
                                        <td class="Sunday_12_00_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:30 AM</td>
                                        <td class="Monday_12_30_AM"></td>
                                        <td class="Tuesday_12_30_AM"></td>
                                        <td class="Wednesday_12_30_AM"></td>
                                        <td class="Thursday_12_30_AM"></td>
                                        <td class="Friday_12_30_AM"></td>
                                        <td class="Saturday_12_30_AM"></td>
                                        <td class="Sunday_12_30_AM"></td>
                                    </tr>
                                    <tr>
                                        <td>1:00 PM</td>
                                        <td class="Monday_1_00_PM"></td>
                                        <td class="Tuesday_1_00_PM"></td>
                                        <td class="Wednesday_1_00_PM"></td>
                                        <td class="Thursday_1_00_PM"></td>
                                        <td class="Friday_1_00_PM"></td>
                                        <td class="Saturday_1_00_PM"></td>
                                        <td class="Sunday_1_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>01:30 PM</td>
                                        <td class="Monday_1_30_PM"></td>
                                        <td class="Tuesday_1_30_PM"></td>
                                        <td class="Wednesday_1_30_PM"></td>
                                        <td class="Thursday_1_30_PM"></td>
                                        <td class="Friday_1_30_PM"></td>
                                        <td class="Saturday_1_30_PM"></td>
                                        <td class="Sunday_1_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:00 PM</td>
                                        <td class="Monday_2_00_PM"></td>
                                        <td class="Tuesday_2_00_PM"></td>
                                        <td class="Wednesday_2_00_PM"></td>
                                        <td class="Thursday_2_00_PM"></td>
                                        <td class="Friday_2_00_PM"></td>
                                        <td class="Saturday_2_00_PM"></td>
                                        <td class="Sunday_2_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>02:30 PM</td>
                                        <td class="Monday_2_30_PM"></td>
                                        <td class="Tuesday_2_30_PM"></td>
                                        <td class="Wednesday_2_30_PM"></td>
                                        <td class="Thursday_2_30_PM"></td>
                                        <td class="Friday_2_30_PM"></td>
                                        <td class="Saturday_2_30_PM"></td>
                                        <td class="Sunday_2_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:00 PM</td>
                                        <td class="Monday_3_00_PM"></td>
                                        <td class="Tuesday_3_00_PM"></td>
                                        <td class="Wednesday_3_00_PM"></td>
                                        <td class="Thursday_3_00_PM"></td>
                                        <td class="Friday_3_00_PM"></td>
                                        <td class="Saturday_3_00_PM"></td>
                                        <td class="Sunday_3_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>03:30 PM</td>
                                        <td class="Monday_3_30_PM"></td>
                                        <td class="Tuesday_3_30_PM"></td>
                                        <td class="Wednesday_3_30_PM"></td>
                                        <td class="Thursday_3_30_PM"></td>
                                        <td class="Friday_3_30_PM"></td>
                                        <td class="Saturday_3_30_PM"></td>
                                        <td class="Sunday_3_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:00 PM</td>
                                        <td class="Monday_4_00_PM"></td>
                                        <td class="Tuesday_4_00_PM"></td>
                                        <td class="Wednesday_4_00_PM"></td>
                                        <td class="Thursday_4_00_PM"></td>
                                        <td class="Friday_4_00_PM"></td>
                                        <td class="Saturday_4_00_PM"></td>
                                        <td class="Sunday_4_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>04:30 PM</td>
                                        <td class="Monday_4_30_PM"></td>
                                        <td class="Tuesday_4_30_PM"></td>
                                        <td class="Wednesday_4_30_PM"></td>
                                        <td class="Thursday_4_30_PM"></td>
                                        <td class="Friday_4_30_PM"></td>
                                        <td class="Saturday_4_30_PM"></td>
                                        <td class="Sunday_4_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:00 PM</td>
                                        <td class="Monday_5_00_PM"></td>
                                        <td class="Tuesday_5_00_PM"></td>
                                        <td class="Wednesday_5_00_PM"></td>
                                        <td class="Thursday_5_00_PM"></td>
                                        <td class="Friday_5_00_PM"></td>
                                        <td class="Saturday_5_00_PM"></td>
                                        <td class="Sunday_5_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>05:30 PM</td>
                                        <td class="Monday_5_30_PM"></td>
                                        <td class="Tuesday_5_30_PM"></td>
                                        <td class="Wednesday_5_30_PM"></td>
                                        <td class="Thursday_5_30_PM"></td>
                                        <td class="Friday_5_30_PM"></td>
                                        <td class="Saturday_5_30_PM"></td>
                                        <td class="Sunday_5_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:00 PM</td>
                                        <td class="Monday_6_00_PM"></td>
                                        <td class="Tuesday_6_00_PM"></td>
                                        <td class="Wednesday_6_00_PM"></td>
                                        <td class="Thursday_6_00_PM"></td>
                                        <td class="Friday_6_00_PM"></td>
                                        <td class="Saturday_6_00_PM"></td>
                                        <td class="Sunday_6_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>06:30 PM</td>
                                        <td class="Monday_6_30_PM"></td>
                                        <td class="Tuesday_6_30_PM"></td>
                                        <td class="Wednesday_6_30_PM"></td>
                                        <td class="Thursday_6_30_PM"></td>
                                        <td class="Friday_6_30_PM"></td>
                                        <td class="Saturday_6_30_PM"></td>
                                        <td class="Sunday_6_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:00 PM</td>
                                        <td class="Monday_7_00_PM"></td>
                                        <td class="Tuesday_7_00_PM"></td>
                                        <td class="Wednesday_7_00_PM"></td>
                                        <td class="Thursday_7_00_PM"></td>
                                        <td class="Friday_7_00_PM"></td>
                                        <td class="Saturday_7_00_PM"></td>
                                        <td class="Sunday_7_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>07:30 PM</td>
                                        <td class="Monday_7_30_PM"></td>
                                        <td class="Tuesday_7_30_PM"></td>
                                        <td class="Wednesday_7_30_PM"></td>
                                        <td class="Thursday_7_30_PM"></td>
                                        <td class="Friday_7_30_PM"></td>
                                        <td class="Saturday_7_30_PM"></td>
                                        <td class="Sunday_7_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:00 PM</td>
                                        <td class="Monday_8_00_PM"></td>
                                        <td class="Tuesday_8_00_PM"></td>
                                        <td class="Wednesday_8_00_PM"></td>
                                        <td class="Thursday_8_00_PM"></td>
                                        <td class="Friday_8_00_PM"></td>
                                        <td class="Saturday_8_00_PM"></td>
                                        <td class="Sunday_8_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>08:30 PM</td>
                                        <td class="Monday_8_30_PM"></td>
                                        <td class="Tuesday_8_30_PM"></td>
                                        <td class="Wednesday_8_30_PM"></td>
                                        <td class="Thursday_8_30_PM"></td>
                                        <td class="Friday_8_30_PM"></td>
                                        <td class="Saturday_8_30_PM"></td>
                                        <td class="Sunday_8_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:00 PM</td>
                                        <td class="Monday_9_00_PM"></td>
                                        <td class="Tuesday_9_00_PM"></td>
                                        <td class="Wednesday_9_00_PM"></td>
                                        <td class="Thursday_9_00_PM"></td>
                                        <td class="Friday_9_00_PM"></td>
                                        <td class="Saturday_9_00_PM"></td>
                                        <td class="Sunday_9_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>9:30 PM</td>
                                        <td class="Monday_9_30_PM"></td>
                                        <td class="Tuesday_9_30_PM"></td>
                                        <td class="Wednesday_9_30_PM"></td>
                                        <td class="Thursday_9_30_PM"></td>
                                        <td class="Friday_9_30_PM"></td>
                                        <td class="Saturday_9_30_PM"></td>
                                        <td class="Sunday_9_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:00 PM</td>
                                        <td class="Monday_10_00_PM"></td>
                                        <td class="Tuesday_10_00_PM"></td>
                                        <td class="Wednesday_10_00_PM"></td>
                                        <td class="Thursday_10_00_PM"></td>
                                        <td class="Friday_10_00_PM"></td>
                                        <td class="Saturday_10_00_PM"></td>
                                        <td class="Sunday_10_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>10:30 PM</td>
                                        <td class="Monday_10_30_PM"></td>
                                        <td class="Tuesday_10_30_PM"></td>
                                        <td class="Wednesday_10_30_PM"></td>
                                        <td class="Thursday_10_30_PM"></td>
                                        <td class="Friday_10_30_PM"></td>
                                        <td class="Saturday_10_30_PM"></td>
                                        <td class="Sunday_10_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:00 PM</td>
                                        <td class="Monday_11_00_PM"></td>
                                        <td class="Tuesday_11_00_PM"></td>
                                        <td class="Wednesday_11_00_PM"></td>
                                        <td class="Thursday_11_00_PM"></td>
                                        <td class="Friday_11_00_PM"></td>
                                        <td class="Saturday_11_00_PM"></td>
                                        <td class="Sunday_11_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>11:30 PM</td>
                                        <td class="Monday_11_30_PM"></td>
                                        <td class="Tuesday_11_30_PM"></td>
                                        <td class="Wednesday_11_30_PM"></td>
                                        <td class="Thursday_11_30_PM"></td>
                                        <td class="Friday_11_30_PM"></td>
                                        <td class="Saturday_11_30_PM"></td>
                                        <td class="Sunday_11_30_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:00 PM</td>
                                        <td class="Monday_12_00_PM"></td>
                                        <td class="Tuesday_12_00_PM"></td>
                                        <td class="Wednesday_12_00_PM"></td>
                                        <td class="Thursday_12_00_PM"></td>
                                        <td class="Friday_12_00_PM"></td>
                                        <td class="Saturday_12_00_PM"></td>
                                        <td class="Sunday_12_00_PM"></td>
                                    </tr>
                                    <tr>
                                        <td>12:30 PM</td>
                                        <td class="Monday_12_30_PM"></td>
                                        <td class="Tuesday_12_30_PM"></td>
                                        <td class="Wednesday_12_30_PM"></td>
                                        <td class="Thursday_12_30_PM"></td>
                                        <td class="Friday_12_30_PM"></td>
                                        <td class="Saturday_12_30_PM"></td>
                                        <td class="Sunday_12_30_PM"></td>
                                    </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-class notifications">
            <div class="content">
                <div class="small-header">
                    <div class="hpanel">
                        <div class="panel-body">
                            <div id="hbreadcrumb" class="pull-right">
                                <ol class="hbreadcrumb breadcrumb">
                                    <li><a href="javascript:;">Dashboard</a></li>
                                    <li>
                                        <span>courses</span>
                                    </li>
                                    <li class="active">
                                        <span>Add New Year</span>
                                    </li>
                                </ol>
                            </div>
                            <h2 class="font-light m-b-xs">Notifications</h2>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="row">
    <div class="col-md-6">
        <div class="hpanel">
                <div class="v-timeline vertical-container animate-panel" data-child="vertical-timeline-block" data-delay="1">
                    <div class="vertical-timeline-block">
                        <div class="vertical-timeline-icon navy-bg">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="vertical-timeline-content">
                            <div class="p-sm">
                                <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                                <h2>The standard chunk of Lorem Ipsum</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                                </p>
                            </div>
                            <div class="panel-footer">
                                It is a long established fact that
                            </div>
                        </div>
                    </div>
                    <div class="vertical-timeline-block">
                        <div class="vertical-timeline-icon navy-bg">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="vertical-timeline-content">
                            <div class="p-sm">
                                <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                                <h2>There are many variations</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                                </p>
                            </div>
                            <div class="panel-footer">
                                It is a long established fact that
                            </div>
                        </div>
                    </div>
                    <div class="vertical-timeline-block">
                        <div class="vertical-timeline-icon navy-bg">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="vertical-timeline-content">
                            <div class="p-sm">
                                <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                                <h2>Contrary to popular belief</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                                </p>
                            </div>
                            <div class="panel-footer">
                                It is a long established fact that
                            </div>
                        </div>
                    </div>
                    <div class="vertical-timeline-block">
                        <div class="vertical-timeline-icon navy-bg">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="vertical-timeline-content">
                            <div class="p-sm">
                                <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                                <h2>The generated Lorem Ipsum</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                                </p>
                            </div>
                            <div class="panel-footer">
                                It is a long established fact that
                            </div>
                        </div>
                    </div>
                    <div class="vertical-timeline-block">
                        <div class="vertical-timeline-icon navy-bg">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="vertical-timeline-content">
                            <div class="p-sm">
                                <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                                <h2>The standard chunk</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                                </p>
                            </div>
                            <div class="panel-footer">
                                It is a long established fact that
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="hpanel">
            <div class="v-timeline vertical-container animate-panel" data-child="vertical-timeline-block" data-delay="1">
                <div class="vertical-timeline-block">
                    <div class="vertical-timeline-icon navy-bg">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="vertical-timeline-content">
                        <div class="p-sm">
                            <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                            <h2>The standard chunk of Lorem Ipsum</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                            </p>
                        </div>
                        <div class="panel-footer">
                            It is a long established fact that
                        </div>
                    </div>
                </div>
                <div class="vertical-timeline-block">
                    <div class="vertical-timeline-icon navy-bg">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="vertical-timeline-content">
                        <div class="p-sm">
                            <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                            <h2>There are many variations</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                            </p>
                        </div>
                        <div class="panel-footer">
                            It is a long established fact that
                        </div>
                    </div>
                </div>
                <div class="vertical-timeline-block">
                    <div class="vertical-timeline-icon navy-bg">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="vertical-timeline-content">
                        <div class="p-sm">
                            <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                            <h2>Contrary to popular belief</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                            </p>
                        </div>
                        <div class="panel-footer">
                            It is a long established fact that
                        </div>
                    </div>
                </div>
                <div class="vertical-timeline-block">
                    <div class="vertical-timeline-icon navy-bg">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="vertical-timeline-content">
                        <div class="p-sm">
                            <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                            <h2>The generated Lorem Ipsum</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                            </p>
                        </div>
                        <div class="panel-footer">
                            It is a long established fact that
                        </div>
                    </div>
                </div>
                <div class="vertical-timeline-block">
                    <div class="vertical-timeline-icon navy-bg">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="vertical-timeline-content">
                        <div class="p-sm">
                            <span class="vertical-date pull-right"> Saturday <br> <small>12:17:43 PM</small> </span>

                            <h2>The standard chunk</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                            </p>
                        </div>
                        <div class="panel-footer">
                            It is a long established fact that
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                </div>
            </div>
        </div>
    </div>


    <!--- Add class_remarks modal -->

    <div class="modal fade" id="class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="lesson_teach"  type="text"  class="form-control" name="lesson_teach" required />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Class Remaks</label>
                                                            <textarea id="class_remarks" type="text"  class="form-control" name="class_remarks" required /></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-class-remarks" class="btn btn-info" type="submit">Save</button>
                                                                <!--<button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end Add class remarks modal -->


    <!--- Add student notes modal -->
    <div class="modal fade" id="add_student_notes" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="notes_student_id"  type="hidden"  class="form-control" name="class_id" >      
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Notes</label>
                                                            <textarea id="student_notes" type="text"  class="form-control" name="student_notes" required /></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-5 col-sm-offset-4">
                                                                <button id="add-student-notes" class="btn btn-info" type="submit">Save</button>
                                                                <!--<button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end student notes modal -->

    <!--- teacher profile modal -->
    <div class="modal fade" id="edit_profile" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="text-center"><strong>Personal Bio Data</strong></div>
                                    <form method="get" class="form-horizontal">
                                        <div class="col-lg-6">
                                            <input id="edit-teacher-id" type="hidden" class="form-control">
                                            <div class="hr-line-dashed"></div>  
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Teacher Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-name" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">CNIC</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-cnic" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Telephone</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-landline" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Email</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-email" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Qualification</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-qualification" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Father Name</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-fname" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Address</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-address" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-mobile" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label">Experience</label>
                                                <div class="col-sm-8">
                                                    <input id="edit-teacher-experience" type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>
                                            <div class="pull-right">
                                                <button id="update-teacher-profile" type="button" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>     
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end teacher profile modal -->

    <!--- class modal -->
    <div class="modal fade" id="student_class_history" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="text-center"><strong>Class History</strong></div>
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="student-classes-history-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="example2_info">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Class Time</th>
                                                        <th>Student</th>
                                                        <th>Teacher</th>
                                                        <th>Course</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Duration</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end class history modal -->

    <!--- single notification modal -->
    <div class="modal fade" id="view_single_notification" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg custom-wd">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="hpanel">
                            <div class="panel-heading">
                                <div class="text-center"><strong>Class History</strong></div>
                            </div>
                            <div class="panel-body">
                                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
                </div>   
            </div>
        </div>
    </div>

    <!-- end single notification modal -->

    <!--- view class_remarks modal -->

    <div class="modal fade" id="view_class_remarks" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Lesson Teach</label>
                                                            <input id="view_lesson_teach"  type="text"  class="form-control" name="lesson_teach" disabled />
                                                        </div>  
                                                        <br>      
                                                        <div class="form-group col-lg-12 no-gap" style="padding-top: 26px;">
                                                            <label>Class Remaks</label>
                                                            <textarea id="view_class_end_remarks" type="text"  class="form-control" name="class_remarks" disabled /></textarea>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- end view class remarks modal -->

    <!--- Add lesson details modal -->

    <div class="modal fade" id="lesson_details" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="hpanel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form method="get" class="form-horizontal">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <input id="class_student_id"  type="hidden" >
                                                        <input id="class_teacher_id"  type="hidden" >
                                                        <input id="class_id"  type="hidden"  class="form-control" name="class_id" >
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Book</label>
                                                            <select id="book_teach" class="form-control" name="book" required="" >
                                                                <option></option>
                                                                <?php 
                                                                    $all_books = $this->Teacher_model->get_all_books();
                                                                    foreach ($all_books as $book) { ?>
                                                                        <option value="<?php echo $book['id']?>"><?php echo $book['book_name']?></option>
                                                                    <?php }
                                                                ?>
                                                            <select>
                                                        </div>  
                                                        <br><br>
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>Chapter</label>
                                                            <select id="chapter_teach" class="form-control" name="chapter" required="" disabled="disabled">
                                                                <option></option>
                                                                
                                                            <select>
                                                        </div>  
                                                        <br><br>
                                                        <div class="form-group col-lg-12 no-gap">
                                                            <label>page</label>
                                                            <select id="page_teach" class="form-control" name="page" required="" disabled="disabled">
                                                                <option></option>
                                                            <select>
                                                        </div>  
                                                        <br><br>
                                                        <div class="form-group">
                                                            <div class="col-sm-12 text-center mt-10">
                                                                <button id="go-to-lesson" class="btn btn-info" type="submit">Go</button>
                                                                <!--<button class="btn btn-default" type="button" data-dismiss="modal" >Cancel</button> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>        
                                            </form>  
                                        </div>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="mydiv" style="display:none;">
        <iframe id="frame" src="" width="100%" height="100%">
        </iframe>
    </div>

    <div id="readbook" style="display:none;">
        <iframe id="readbookframe" src="" width="100%" height="100%">
        </iframe>
    </div>

    <a class="btn max-frame" onclick="showIFrame()" style="display:none; background: #1d9c73;padding: 8px;width: 35px;text-align: center;color: #fff;font-size: 25px;line-height: 15px;right: 300px;position: absolute;top: 50px;"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></a>

    <!-- end lesson details modal  -->

    <!-- Footer-->
    <!--<footer class="footer">
        <span class="pull-right">
            Example text
        </span>
        Company 2015-2020
    </footer> -->

</div>

<!-- Vendor scripts -->
<script src="<?php echo base_url()?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.resize.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.flot.pie.js"></script>
<script src="<?php echo base_url()?>public/js/curvedLines.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/metisMenu.min.js"></script>
<script src="<?php echo base_url()?>public/js/icheck.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery.peity.min.js"></script>
<script src="<?php echo base_url()?>public/js/index.js"></script>
<script src="<?php echo base_url()?>public/js/moment.min.js"></script>
<script src="<?php echo base_url()?>public/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url()?>public/js/toastr.min.js"></script>
<script src="<?php echo base_url()?>public/js/sweet-alert.min.js"></script>
<script src="<?php echo base_url()?>public/js/bootstrap-clockpicker.min.js"></script>


<!-- App scripts -->
<script src="<?php echo base_url()?>public/js/homer.js"></script>
<script src="<?php echo base_url()?>public/js/charts.js"></script>
<!--<script src="<?php //echo base_url()?>public/js/app.js"></script> -->

<!-- DataTables -->
<script src="<?php echo base_url()?>public/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>

<script>

    $(function () {


        $('#classess-table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "https://learnquraan.co.uk/ci/index.php/teacher/today_classes",
                "type": "POST"
            },
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Course" },
                { "data": "History" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
                { "data": "Actions"},
            ],
        });

        $('#student-classes-history-table').dataTable({
            "columns": [
                { "data": "Date" },
                { "data": "Class Time" },
                { "data": "Student" },
                { "data": "Teacher" },
                { "data": "Course" },
                { "data": "Start Time" },
                { "data": "End Time" },
                { "data": "Duration" },
                { "data": "Status" },
            ],
            "order": [[ 1, "desc" ]]
        });

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('a[data-toggle="tab"]').removeClass('btn-primary');
            $('a[data-toggle="tab"]').addClass('btn-default');
            $(this).removeClass('btn-default');
            $(this).addClass('btn-primary');
        })

        
        $('.clockpicker').clockpicker({autoclose: true});

    });

</script>
<script>
    $(document).ready(function(){
        $('.j_all-parent').click(function(){
            $('.j_all-parent').removeClass('active');
            $(this).addClass('active');
            $(this).closest('body').find('.common-class').removeClass('active');
            var OpenTabDiv = $(this).attr('data-tab');
            $(this).closest('body').find('.'+OpenTabDiv).addClass('active'); 
        });

        $("#teacher-logout").on('click',function(e) {
            e.preventDefault();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/logout",
                type: "POST",
                dataType: "json",
                success: function(data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success);
                        setTimeout(function() {
                            window.location.href = "https://learnquraan.co.uk/ci/index.php/teacher";
                        }, 2100)
                    } else if (data.error) {
                        toastr.error(data.error);
                    }
                }
            });
        });


        $('#class_remarks').on('show.bs.modal',function(event){
            var button = $(event.relatedTarget);
            var id = button.data('id'); 
            $('#class_id').val(id);
        });


        $('#add_student_notes').on('show.bs.modal',function(event){
            var button = $(event.relatedTarget);
            var id = button.data('id'); 
            $('#notes_student_id').val(id);
        });

        $('#add-class-remarks').on('click',function(e){
            e.preventDefault();
            var class_id = $('input[name="class_id"]').val();
            var lesson_teach = $('input[name="lesson_teach"]').val();
            var Remarks = $('textarea[name="class_remarks"]').val();
            
            var formdata = 'class_id='+class_id+'&lesson='+lesson_teach+'&Remarks='+Remarks;
            if(lesson_teach != '' && Remarks != ''){
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/admin/add_class_remarks",
                    type: "POST",
                    dataType: "json",
                    data: formdata,
                    success: function (data) {
                        if (typeof(data.error) == "undefined") {
                            toastr.success(data.success);
                            $('#class_remarks').modal('hide');
                            $('input[name="class_id"]').val('');
                            $('input[name="lesson_teach"]').val('');
                            $('textarea[name="class_remarks"]').val('');
                            $('#class-end').remove();
                        } else if (data.error) {
                            toastr.error(data.error);
                        }
                    }    
                });
            }else{
                toastr.error('Please Fill up all the fields');
            }    
        });


        $('body').on('click','#class-start',function(){
            var check = $('#class-pause').length;
            if(check > 0){
                $('#lesson_details').modal({
                    show: 'false'
                });
                swal("Cancelled", "Please finish the class first !! :)", "error");
            }else{
                var id = $(this).attr('data-id');
                var start_time = new Date(),
                start_time = start_time.getHours()+':'+start_time.getMinutes()+':'+start_time.getSeconds();
                $(this).closest('tr').children('td:eq(5)').text(start_time);
                $(this).closest('tr').children('td:eq(8)').text('Started');
                $(this).attr('id','class-pause');
                $(this).text('Pause');
                $('#student-leave').attr('data-toggle','modal');
                $('#student-leave').attr('data-target','#class_remarks');
                $('#student-leave').text('End');
                $('#student-leave').attr('id','class-end');
                $.ajax({
                    url: "https://learnquraan.co.uk/ci/index.php/teacher/start_class",
                    type: "POST",
                    dataType: "json",
                    data: 'class-id='+id+'&start_time='+start_time,   
                });
            }
            
        });

        $('#view_class_remarks').on('show.bs.modal',function(event){
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var formdata = 'class_id='+id;
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_class_detail_data",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function(return_data) {
                    if (typeof(return_data.error) == "undefined"){
                        $('#view_lesson_teach').val(return_data.lesson);
                        $('#view_class_end_remarks').text(return_data.remarks);
                    }
                }
            });
        });

        $('body').on('click','#class-pause',function(){
            var id = $(this).attr('data-id');
            $(this).removeAttr('data-toggle');
            $(this).removeAttr('data-target');
            $(this).removeAttr('data-keyboard');
            $(this).removeAttr('data-backdrop');
            $(this).closest('tr').children('td:eq(7)').text('Waiting');
            $(this).attr('id','class-resume');
            $(this).text('Resume');
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/pause_class",
                type: "POST",
                dataType: "json",
                data: 'class-id='+id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                    }
                }    
            });
        });

        $('#update-teacher-profile').on('click',function(e){
            e.preventDefault();
            var id = $('#edit-teacher-id').val();
            var name = $('#edit-teacher-name').val();
            var fname = $('#edit-teacher-fname').val();
            var cnic = $('#edit-teacher-cnic').val();
            var address = $('#edit-teacher-address').val();
            var landline = $('#edit-teacher-landline').val();
            var mobile = $('#edit-teacher-mobile').val();
            var email = $('#edit-teacher-email').val();
            var qual = $('#edit-teacher-qualification').val();
            var expert = $('#edit-teacher-experience').val();
            var formdata = 'id='+id+'&name='+name+'&fname='+fname+'&cnic='+cnic+'&address='+address+'&landline='+landline+'&mobile='+mobile+'&email='+email+'&qual='+qual+'&expert='+expert;
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/update_teacher",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success,function(){
                            $('#edit_profile').modal('hide');
                        });
                    } else if(data.error) {
                        toastr.error(data.error);   
                    }
                }
            });
        });

        $('body').on('click','#class-resume',function(){
            var id = $(this).attr('data-id');
            $(this).closest('tr').children('td:eq(7)').text('Started');
            $(this).attr('id','class-pause');
            $(this).text('Pause');
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/resume_class",
                type: "POST",
                dataType: "json",
                data: 'class-id='+id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                    }
                }    
            });
        });

        $('body').on('click','#student-leave',function(){
            var id = $(this).attr('data-id');
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/set_leave",
                type: "POST",
                dataType: "json",
                data: 'class-id='+id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $('#classes-table').DataTable().ajax.reload();
                        $('#student-leave').remove();
                        $('#class-start').remove();
                    }
                }    
            });
        });

        $('body').on('keyup','#complaint-comment',function(e)
        {
            if(e.keyCode == 13)
            {
            var comment = $(this).val();
            var comp_id = $(this).attr('data-complaint-id');
            var comp_name = $('#login-name').val();
            var selector = $('.social-form-'+comp_id);
            var date = new Date().toDateString();;
            var formdata = 'id='+comp_id+'&comment='+comment+'&complaint_name='+comp_name;
                if(comment == "")
                {
                    alert("Please write something in comment.");
                }
                else
                {
                    selector.before('<div class="social-talk"> \
                                    <div class="media social-profile clearfix"> \
                                        <a class="pull-left"> \
                                            <!--<img src="images/a1.jpg" alt="profile-picture"> -->  \
                                        </a> \
                                        <div class="media-body"> \
                                            <span class="font-bold">'+ comp_name +'</span> \
                                            <small class="text-muted">'+ date +'</small> \
                                            <div class="social-content"> \
                                                '+ comment +' \
                                            </div> \
                                        </div></div></div>');
                    $(this).val("");

                    $.ajax({
                        url: "https://learnquraan.co.uk/ci/index.php/admin/add_complaint_responce",
                        type: "POST",
                        dataType: "json",
                        data: formdata,
                        success: function (data) {
                            if (typeof(data.error) == "undefined") {
                                
                            } else if (data.error) {
                            }
                        }    
                    });
                }
            }
        });   

        $('#edit_profile').on('show.bs.modal',function(event){
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var formdata = 'teacher_id='+id;
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_teacher",
                type: "POST",
                dataType: "json",
                data: formdata,
                success: function(return_data) {
                    if (typeof(return_data.error) == "undefined"){
                        $('#edit-teacher-id').val(return_data.id);
                        $('#edit-teacher-name').val(return_data.name);
                        $('#edit-teacher-fname').val(return_data.father_name);
                        $('#edit-teacher-cnic').val(return_data.cnic);
                        $('#edit-teacher-address').val(return_data.address);
                        $('#edit-teacher-landline').val(return_data.landline);
                        $('#edit-teacher-mobile').val(return_data.mobile);
                        $('#edit-teacher-email').val(return_data.email);
                        $('#edit-teacher-shift').val(return_data.shift_id);
                        $('#edit-teacher-gender').val(return_data.gender);
                        $('#edit-teacher-mat-status').val(return_data.martial_status);
                        $('#edit-teacher-qualification').val(return_data.qualification);
                        $('#edit-teacher-experience').val(return_data.experience);
                        $('#edit-teacher-designation').val(return_data.designation);
                        $('#edit-teacher-skype').val(return_data.skype_id);
                        $('#edit-teacher-skype-passwrd').val(return_data.skype_passwrd)
                        $('#edit-teacher-salary').val(return_data.salary);
                        $('#edit-teacher-username').val(return_data.user_name);
                        $('#edit-teacher-pass').val(return_data.passwrd);
                        $('#edit-teacher-interremarks').val(return_data.inter_remarks);
                    }
                }
            });
        });

        $('#student_class_history').on('show.bs.modal',function(event){
            //event.preventDefault();
            var button = $(event.relatedTarget);
            var student_id = button.data('id');
            var filters = 'student_id='+student_id;
            $('#student-classes-history-table').DataTable().ajax.url('https://learnquraan.co.uk/ci/index.php/teacher/classes_history?'+filters).load();
        });

        $('body').on('click','#class-end',function(){
            $('#class-pause').remove();
            $('#reopen-frame').remove();
            $(this).attr('data-backdrop','static');
            $(this).attr('data-keyboard','false');
            $(this).attr('data-toggle','modal');
            $(this).attr('data-target','#class_remarks');
            var select = $(this);
            var id = $(this).attr('data-id');
            var end_time = new Date(),
            end_time = end_time.getHours()+':'+end_time.getMinutes()+':'+end_time.getSeconds();
            $(this).closest('tr').children('td:eq(6)').text(end_time);
            $(this).closest('tr').children('td:eq(8)').text('Taken');
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/end_class",
                type: "POST",
                dataType: "json",
                data: 'class-id='+id+'&end_time='+end_time,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        select.closest('tr').children('td:eq(7)').text(data.duration);
                        select.remove();
                    }
                }    
            });
            
        });


        $('body').on('click','#add-student-notes',function(){
            var student_id = $('#notes_student_id').val();
            var student_notes = $('#student_notes').val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/student_notes",
                type: "POST",
                dataType: "json",
                data: 'student-id='+student_id+'&student-notes='+student_notes,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        toastr.success(data.success,function(){
                            $('#add_student_notes').modal('hide');
                        });
                    }else{
                        toastr.error(data.error);
                    }
                }    
            });
        });

        $('body').on('change','#book_teach',function(){
            var select = $('#chapter_teach');
            select.empty();
            select.append('<option></option>');
            select.attr('disabled',false);
            var book_id = $(this).val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_chapters",
                type: "POST",
                dataType: "json",
                data: 'book-id='+book_id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $.each(data , function( index, value ) {
                            select.append('<option value="'+value.id+'">'+value.chapter_name+'</option>');
                        });
                    }
                }    
            });
            
        });

        $('body').on('change','#chapter_teach',function(){
            var select = $('#page_teach');
            select.empty();
            select.append('<option></option>');
            select.attr('disabled',false);
            var chap_id = $(this).val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/get_pages",
                type: "POST",
                dataType: "json",
                data: 'chap-id='+chap_id,
                success: function (data) {
                    if (typeof(data.error) == "undefined") {
                        $.each(data , function( index, value ) {
                            select.append('<option value="'+value.id+'">'+value.page_no+'</option>');
                        });    
                    }
                }    
            });
            
        });

        $("#go-to-lesson").click(function (e) { 
            e.preventDefault();
            var book = $('#book_teach').val();
            var chapter = $('#chapter_teach').val();
            var page = $('#page_teach').val();
            var student = $('#class_student_id').val();
            var teacher = $('#class_teacher_id').val();
            $.ajax({
                url: "https://learnquraan.co.uk/ci/index.php/teacher/current_lesson",
                type: "POST",
                dataType: "json",
                data: 'book-id='+book+'&chap-id='+chapter+'&page-id='+page+'&student-id='+student+'&teacher-id='+teacher,
                success: function (data) {
                    
                }    
            });
            $('#lesson_details').modal('hide');
            $('#mydiv').css('display','block');
            $("#frame").attr("src", "https://learnquraan.co.uk/ci/index.php/lesson/tlesson?book="+book+"&chapter="+chapter+"&page="+page+'&student='+student+'&teacher='+teacher);
        });
    });

    $('#lesson_details').on('show.bs.modal',function(event){
        var button = $(event.relatedTarget);
        var student_id = button.data('student');
        var teacher_id = button.data('teacher');
        var data;
        $('#class_student_id').val(student_id);
        $('#class_teacher_id').val(teacher_id);
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/teacher/get_lesson_data",
            type: "POST",
            dataType: "json",
            data: 'student-id='+student_id+'&teacher-id='+teacher_id,
            success: function (dataaa) {
                data = dataaa;
                if (typeof(data.error) == "undefined") {
                    $('#book_teach').val(data.book_id).trigger('change');
                    setTimeout(function(){ 
                        $('#chapter_teach').val(data.chapter_id).trigger('change'); 
                    }, 500);
                    //$('#chapter_teach').val(data.chapter_id).trigger('change');
                    //$('#page_teach').val(data.page_id);
                    setTimeout(function(){ 
                        $('#page_teach').val(data.page_id);
                    }, 2000);
                }
            }    
        }).then(function(){
            $('#chapter_teach').val(data.chapter_id).trigger('change');
        }).then(function(){
            $('#page_teach').val(data.page_id);
        });
    });
    
    $('#frame').contents().find('.close-iframe').click(function (event) {
        event.preventDefault();
        $('#frame').remove();
    });

    $("body").on('click','#reopen-frame',function (e) { 
        e.preventDefault();
        $("#frame").show();
        $(this).remove();
    });

    $("#read-book").on('click',function (e) { 
        e.preventDefault();
        var book = $(this).attr('data-book');
        $('#readbook').css('display','block');
        $('#readbookframe').show();
        $("#readbookframe").attr("src", "https://learnquraan.co.uk/ci/index.php/lesson/rlesson?book="+book);
    });

    $(window).load(function(e) {
        e.preventDefault();
        $('.filledup').removeClass('table-box');
        $('.filledup').empty();
        $('.filledup').removeClass('filledup');
        $.ajax({
            url: "https://learnquraan.co.uk/ci/index.php/teacher/get_teacher_schedule",
            type: "POST",
            dataType: "json",
            success: function (data) {
                if (typeof(data.error) == "undefined") {
                    $.each(data, function( index, value ){
                        var timee = value.time.replace(":", "_");
                        timee = timee.replace(' ','_');
                        var select_box = '.'+value.day+'_'+timee; 
                        $(select_box).addClass('table-box');
                        $(select_box).addClass('filledup'); 
                        $('td'+select_box).append('<p>'+value.name+'</p>');
                    });
                } else if (data.error) {
                    toastr.error(data.error);
                }
            }    
        });
    });    

    function closeIFrame(){
        //$('#frame').remove();
        $('#frame').hide();
        $('button#class-pause').closest('td').append('<span id="reopen-frame" class="label label-success pull-right">D</span>');
    }
    function closeRFrame(){
        //$('#frame').remove();
        $('#readbookframe').hide();
    }

    function hideIFrame(){
        $('#frame').hide();
        $('.max-frame').css('display','block');
    }

    function showIFrame(){
        $('#frame').show();
        $('.max-frame').css('display','none');
    }

</script>

</body>
</html>