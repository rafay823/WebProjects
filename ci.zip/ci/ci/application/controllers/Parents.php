<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parents extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


    function __construct()
    {
        parent::__construct();
        $this->load->model('Parent_model');
    }

	public function index()
	{

		$this->load->view('parent/login');
	}

    public function testing()
    {

        $this->load->view('admin/test');
    }

    public function pay_test()
    {
        if(isset($_POST) && !empty($_POST)){
            $inv_id = $this->input->post("inv_id");
            $parent_id = $this->input->post("parent_id");
            $invoice_id = $this->input->post("invoice_id");
            $order_no = $this->input->post("order_number");
            $data['invoice_id'] = $invoice_id;
            $data['order_no'] = $invoice_id;
            $data['status'] = "Paid";
            $chek = $this->Parent_model->update_invoice_status($inv_id,$data); 
            if($chek){
                $this->load->view('parent/dashboard');
                header("location:https://learnquraan.co.uk/ci/index.php/Parents/panel");
            }else{
                header("location:https://learnquraan.co.uk/ci/index.php/Parents/panel");
            }
        }
    }   

    public function pay_paypal_success()
    {
        /*
         * Read POST data
         * reading posted data directly from $_POST causes serialization
         * issues with array data in POST.
         * Reading raw POST data from input stream instead.
         */        
        $raw_post_data = file_get_contents('php://input');
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode ('=', $keyval);
            if (count($keyval) == 2)
                $myPost[$keyval[0]] = urldecode($keyval[1]);
        }

        // Read the post from PayPal system and add 'cmd'
        $req = 'cmd=_notify-validate';
        if(function_exists('get_magic_quotes_gpc')) {
            $get_magic_quotes_exists = true;
        }
        foreach ($myPost as $key => $value) {
            if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                $value = urlencode(stripslashes($value));
            } else {
                $value = urlencode($value);
            }
            $req .= "&$key=$value";
        }

        /*
         * Post IPN data back to PayPal to validate the IPN data is genuine
         * Without this step anyone can fake IPN data
         */
        $paypalURL = "https://www.sandbox.paypal.com/cgi-bin/webscr";
        $ch = curl_init($paypalURL);
        if ($ch == FALSE) {
            return FALSE;
        }
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);

        // Set TCP timeout to 30 seconds
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close', 'User-Agent: company-name'));
        $res = curl_exec($ch);

        /*
         * Inspect IPN validation result and act accordingly
         * Split response headers and payload, a better way for strcmp
         */ 
        $tokens = explode("\r\n\r\n", trim($res));
        $res = trim(end($tokens));
        //echo json_encode($res);
        file_put_contents('test_file.json', json_encode($_POST));   
        if (strcmp($res, "VERIFIED") == 0 || strcasecmp($res, "VERIFIED") == 0) {
            $payment_status = $this->input->post('payment_status');
            if($payment_status == 'Completed'){
                $inv_id = $this->input->post("item_number");
                $invoice_id = $this->input->post("txn_id");
                $data['invoice_id'] = $invoice_id;
                $data['order_no'] = $invoice_id;
                $data['status'] = "Paid";
                $chek = $this->Parent_model->update_invoice_status($inv_id,$data); 
            }    
        } 
    }  

	public function panel()
	{

		$this->load->view('parent/dashboard');
	}

	public function login()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($this->Parent_model->check_login($username,$password)){
                $parent_info = $this->Parent_model->check_login($username,$password);
                $session_data = array(
                    'username' => $parent_info->name,
                    'parent_id' => $parent_info->id
                );
                $this->session->set_userdata('parent_logged_in', $session_data);
                echo json_encode(array('success'=>'login successfully'));

            }else{
                echo json_encode(array('error'=>'username or password incorrect'));
            }
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));

        }
    }

    public function logout()
    {
        $sess_array = array('username'=> '');
        $this->session->unset_userdata('parent_logged_in', $sess_array);
        echo json_encode(array('success'=>'logout successfully'));
    }

    public function get_invoice_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('invoice_id');
            $invoice_data = $this->Parent_model->get_invoice_data($id);
            echo json_encode($invoice_data);
        }
    }

    public function add_complaint()
    { 
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post('complaint-student-id');
            $teacher_id = $this->Parent_model->get_teacher_id_by_student_id($student_id);
            $data = array('student_id'=> $student_id,
                'parent_id'=> $this->session->userdata['parent_logged_in']['parent_id'],
                'teacher_id'=> $teacher_id->teacher_id,
                'for'=> $this->input->post('complaint-for'),
                'email'=> $this->input->post('complaint-email'),
                'status'=> 'open',
                'created_date'=> date("Y-m-d"),
                'complaint'=> $this->input->post('complaint'));
            $add_student = $this->Parent_model->save_complaint($data);
            if($add_student){
                echo json_encode(array('success'=>'Complaint Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function get_student_timetable_data()
    {
        date_default_timezone_set("UTC");
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('student_id');
            $timetable_data = $this->Parent_model->get_student_timetable($id);
            $timezone = $this->Parent_model->get_student_timezone($id);
            foreach ($timetable_data as $key => $value) {
                if(!empty($value)){
                    $time = new DateTime("@".strtotime($value->time));
                    $time->setTimezone(new DateTimeZone($timezone->timezone));
                    $value->time = $time->format('g:i A');
                    $end_time = strtotime($time->format('g:i A')) + 1800;
                    //$date = new DateTime("@".$end_time);
                    $value->etime = date('g:i A',$end_time);
                }    
            }
            echo json_encode($timetable_data);
        }
    }

    public function today_classes()
    {   $data = array();
        $day = date('l');
        $date = date("Y-m-d");
        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
        $today_classses = $this->Parent_model->get_today_classes($day,$date,$parent_id);
        foreach ($today_classses as $class) {
            $class_id = $class['id'];
            $course = $this->Parent_model->get_student_course($class['course_id']);
            $teacher = $this->Parent_model->get_student_teacher($class['Teacher_id']);
            $student = $this->Parent_model->get_student_name($class['student_id']);
            $history = $this->Parent_model->get_lesson_history($class['student_id']);
            if(!empty($history)){
                $book_id = $history[0]['book_id'];
                $chap_id = $history[0]['chap_id'];
                $page_id = $history[0]['page_id'];
            }else{
                $book_id = '';
                $chap_id = '';
                $page_id = '';
            }
            if($class['status'] == 'Taken' || $class['status'] == 'Teacher Leave' || $class['status'] == 'Student Leave'){
                $action = '';
            //}elseif ($class['status'] == 'Started') {
                 //$action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>';
            }else{
                $action = '<button id="go-to-lesson" data-id="'.$class_id.'" data-student-id="'.$class['student_id'].'" data-teacher-id="'.$class['Teacher_id'].'" data-book="'.$book_id.'" data-chap="'.$chap_id.'" data-pages="'.$page_id.'" class="btn btn-info btn-sm">Go To Lesson</button>';
            }
            $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),
                //'Class Time' => $class['class_time'],
                'Student' => $student->name,
                'Teacher' => $teacher->name,
                'Course' => $course->name,
                'Start Time' => $class['start_time'],
                //'End Time' => $class['end_time'],
                'Duration' => $class['duration'],
                'Status' => $class['status'],
                'Actions' => $action);
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function classes_history()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            $student_id = $_GET['student_id'];
            $all_classses = $this->Parent_model->get_all_classes_for_filters($student_id);    
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Parent_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = ''; 
                }
                $teacher = $this->Parent_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Parent_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name.'<span id="d_h_v" data-id="'.$class_id.'" data-toggle="modal" data-target="#view_class_remarks" class="label label-success pull-right">D</span>','Teacher' => $teacher_name,'Course' => $course_name,'Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }
    }

    public function get_class_detail_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('class_id');
            $class_data = $this->Parent_model->get_class_detail_data($id);
            echo json_encode($class_data);
        }
    }

    public function all_classes()
    {   $data = array();
        $parent_id = $this->session->userdata['parent_logged_in']['parent_id'];
        if(isset($_GET) && !empty($_GET)){
            $student = ($this->input->get('student') == 'all' ? '' : $this->input->get('student'));   
            $all_classses = $this->Parent_model->get_all_classes_filters($student,$parent_id);
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Parent_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $teacher = $this->Parent_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Parent_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name,'Teacher' => $teacher_name,'Course' => $course_name,'Lesson' => $class['lesson'],'Remarks' => $class['remarks'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }else{
            $all_classses = $this->Parent_model->get_all_classes($parent_id);
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Parent_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $teacher = $this->Parent_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Parent_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name,'Teacher' => $teacher_name,'Course' => $course_name,'Lesson' => $class['lesson'],'Remarks' => $class['remarks'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }  
    }
}
