<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


    function __construct()
    {
        parent::__construct();
        $this->load->model('Student_model');
    }

	public function index()
	{

		$this->load->view('student/login');
	}

    public function testing()
    {

        $this->load->view('admin/test');
    }

	public function panel()
	{

		$this->load->view('admin/dashboard');
	}

	public function login()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($username == $this->config->item('user_name') && $password == $this->config->item('pass')){
                echo json_encode(array('success'=>'login successfully'));
            }else{
            	echo json_encode(array('error'=>'Wrong Username or Password. Please Try Again !!!!'));
            }
            /*elseif($this->Admin_model->check_login($username,$password)){
                $user_info = $this->Admin_model->get_user_info($username,$password);
                $today = new DateTime('now');
                $date = new DateTime($user_info->expiry_date);
                $diff = $today->diff($date)->days;
                if($diff >= 1 ){
                    $session_data = array(
                    'username' => $user_info->name,
                    'useremail' => $username,
                    'role_id' => $user_info->role,
                    'role_name' => $user_info->role_name,
                    'roles' => $user_info->roles
                    );
                    $this->session->set_userdata('logged_in', $session_data);
                    echo json_encode(array('success'=>'login successfully'));
                }else{
                    echo json_encode(array('error'=>'Your  Account Expire. Please Contact your Administrator'));
                }
            }else{
                echo json_encode(array('error'=>'username or password incorrect'));

            }*/
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));

        }
    }

    public function logout()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($username == $this->config->item('user_name') && $password == $this->config->item('pass')){
                echo json_encode(array('success'=>'login successfully'));
            }else{
                echo json_encode(array('error'=>'Wrong Username or Password. Please Try Again !!!!'));
            }
            /*elseif($this->Admin_model->check_login($username,$password)){
                $user_info = $this->Admin_model->get_user_info($username,$password);
                $today = new DateTime('now');
                $date = new DateTime($user_info->expiry_date);
                $diff = $today->diff($date)->days;
                if($diff >= 1 ){
                    $session_data = array(
                    'username' => $user_info->name,
                    'useremail' => $username,
                    'role_id' => $user_info->role,
                    'role_name' => $user_info->role_name,
                    'roles' => $user_info->roles
                    );
                    $this->session->set_userdata('logged_in', $session_data);
                    echo json_encode(array('success'=>'login successfully'));
                }else{
                    echo json_encode(array('error'=>'Your  Account Expire. Please Contact your Administrator'));
                }
            }else{
                echo json_encode(array('error'=>'username or password incorrect'));

            }*/
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));

        }
    }
    

   
}
