<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manager extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


    function __construct()
    {
        parent::__construct();
        $this->load->model('Manager_model');
    }

	public function index()
	{

		$this->load->view('manager/login');
	}

    public function testing()
    {

        $this->load->view('admin/test');
    }

	public function panel()
	{

		$this->load->view('manager/dashboard');
	}

    public function timezone_test(){
        echo $this->ConvertTimezoneToAnotherTimezone(time(),'Asia/Karachi','Asia/Singapore');
    }

    public function ConvertTimezoneToAnotherTimezone($time, $currentTimezone, $timezoneRequired) {
        date_default_timezone_set("Asia/Karachi");
        $dayLightFlag = false;
        $dayLgtSecCurrent = $dayLgtSecReq = 0;
        echo $system_timezone = date_default_timezone_get();
        $local_timezone = $currentTimezone;
        date_default_timezone_set($local_timezone);
        $local = date("Y-m-d H:i:s");
        /* Uncomment if daylight is required */
        //        $daylight_flag = date("I", strtotime($time));
        //        if ($daylight_flag == 1) {
        //            $dayLightFlag = true;
        //            $dayLgtSecCurrent = -3600;
        //        }
        date_default_timezone_set("GMT");
        $gmt = date("Y-m-d H:i:s ");

        $require_timezone = $timezoneRequired;
        date_default_timezone_set($require_timezone);
        $required = date("Y-m-d H:i:s ");
        /* Uncomment if daylight is required */
        //        $daylight_flag = date("I", strtotime($time));
        //        if ($daylight_flag == 1) {
        //            $dayLightFlag = true;
        //            $dayLgtSecReq = +3600;
        //        }

        date_default_timezone_set($system_timezone);

        $diff1 = (strtotime($gmt) - strtotime($local));
        $diff2 = (strtotime($required) - strtotime($gmt));

        $date = new DateTime( "@" . $time);
        //$date->setTimestamp($time);

        $date->modify("+$diff1 seconds");
        $date->modify("+$diff2 seconds");

        if ($dayLightFlag) {
            $final_diff = $dayLgtSecCurrent + $dayLgtSecReq;
            $date->modify("$final_diff seconds");
        }

        $timestamp = $date->format("Y-m-d H:i:s ");

        return $timestamp;
    }

	public function login()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($this->Manager_model->check_login($username,$password)){
                $manager_info = $this->Manager_model->check_login($username,$password);
                $session_data = array(
                    'username' => $manager_info->name,
                    'manager_id' => $manager_info->id
                );
                $this->session->set_userdata('manager_logged_in', $session_data);
                echo json_encode(array('success'=>'login successfully'));
            }else{
                echo json_encode(array('error'=>'username or password incorrect'));
            }
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));

        }
    }

    public function logout()
    {
        $sess_array = array('username'=> '');
        $this->session->unset_userdata('manager_logged_in', $sess_array);
        echo json_encode(array('success'=>'logout successfully'));
    }

    public function all_teachers()
    {   $data = array();
        $all_teachers = $this->Manager_model->get_all_teachers();
        foreach ($all_teachers as $teacher) {
            $tech_id = $teacher['id'];
            $data[]=array('ID' => $teacher['id'],'Teacher Name' => $teacher['name'],'Email' => $teacher['email'],'No of Student' => "",'Shift' => $teacher['shift_id'],'Gender' => $teacher['gender'],'Skype ID' => $teacher['skype_id'],'Password' => '<span data-id="'.$tech_id.'"  data-toggle="modal" data-target="#change_teacher_password" class="badge bg-green">Change Password</span>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_parents()
    {   $data = array();
        $all_parents = $this->Manager_model->get_all_parents();
        foreach ($all_parents as $parent) {
            $parent_id = $parent['id'];
            $manager = $this->Manager_model->get_student_manager($parent['manage_id']);
            if($manager){
                $manager_name = $manager->name;
            }else{
                $manager_name = '';
            }
            $count_kids = $this->Manager_model->get_kids_count($parent['id']);
            if($count_kids){
                $count_kids = $count_kids ;
            }else{
                $count_kids = 'N/A';
            }
            $data[]=array('ID' => $parent['id'],'Name' => $parent['name'],'# of Kids' => $count_kids,'Contact #' => $parent['mobile_num'],'Fee' => $parent['fee'],'Email' => $parent['email'],'Username' => $parent['username'],'Password' => '<span data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_password" class="badge bg-green">Change Password</span>','Manager' => $manager_name,'Fee Date' => $parent['fee_date'],'Actions' => '<button data-id="'.$parent_id.'" data-toggle="modal" data-target="#add_student" class="btn btn-primary btn-sm">Add</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_status">Status</button>&nbsp;<button data-id="'.$parent_id.'" data-toggle="modal" data-target="#edit_parent" class="btn btn-info btn-sm">Edit</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_students()
    {   $data = array();
        $all_students = $this->Manager_model->get_all_students();
        foreach ($all_students as $student) {
            $student_id = $student['id'];
            $course = $this->Manager_model->get_student_course($student['course_id']);
             if($course){
                $course_name = $course->name;
            }else{
                $course_name = '';
            }
            $manager = $this->Manager_model->get_student_manager($student['manage_id']);
            if($manager){
                $manager_name = $manager->name;
            }else{
                $manager_name = '';
            }
            $teacher = $this->Manager_model->get_student_teacher($student['teacher_id']);
            if($teacher){
                $teacher_name = $teacher->name;
            }else{
                $teacher_name = '';
            }
            $country = $this->Manager_model->get_student_country($student['parent_id']);
            if($country){
                $country_code = $country->code;
            }else{
                $country_code = '';
            }
            $fname = $this->Manager_model->get_student_fname($student['parent_id']);
            if($fname){
                $father_name = $fname->name;
            }else{
                $father_name = '';
            }
            $classrecords = $this->Manager_model->get_student_classrecords($student['id']);
            $data[]=array('ID' => $student['id'],'Name' => $student['name'],'Fathername' => $father_name,'Country' => $country_code,'Gender' => $student['gender'],'Course' => $course_name,'Class Records' => $classrecords,'Teacher' => $teacher_name,'Manager' => $manager_name,'Actions' => '<button data-id="'.$student_id.'"  data-toggle="modal" data-target="#edit_student" class="btn btn-info btn-sm">Edit</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$student_id.'"  data-toggle="modal" data-target="#change_student_status">Status</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function today_classes()
    {   $data = array();
        $day = date('l');
        $date = date("Y-m-d");
        $today_classses = $this->Manager_model->get_today_classes($day,$date);
        foreach ($today_classses as $class) {
            $class_id = $class['id'];
            $course = $this->Manager_model->get_student_course($class['course_id']);
            $teacher = $this->Manager_model->get_student_teacher($class['Teacher_id']);
            $student = $this->Manager_model->get_student_name($class['student_id']);
            if($class['status'] == 'Taken' || $class['status'] == 'Teacher Leave' || $class['status'] == 'Student Leave'){
                $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
            }elseif ($class['status'] == 'Started') {
                 $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
            }else{
                $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>&nbsp;<button id="teacher-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">T-L</button>&nbsp;<button id="student-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">S-L</button>';
            }
            $data[]=array('Date' => date("d-m-Y", strtotime($class['t_date'])),'Class Time' => $class['t_class_time'],'Student' => $student->name,'Teacher' => $teacher->name,'Course' => $course->name,'Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status'],'Actions' => $action);
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_classes()
    {   $data = array();
        $student_id = $this->input->post('student_id');
        $all_classses = $this->Manager_model->get_all_classes($student_id);
        foreach ($all_classses as $class) {
            $class_id = $class['id'];
            $course = $this->Manager_model->get_student_course($class['course_id']);
            if($course){
                $course_name = $course->name;
            }else{
                $course_name = '';
            }
            $teacher = $this->Manager_model->get_student_teacher($class['Teacher_id']);
            if($teacher){
                $teacher_name = $teacher->name;
            }else{
                $teacher_name = '';
            }
            $student = $this->Manager_model->get_student_name($class['student_id']);
            if($student){
                $student_name = $student->name;
            }else{
                $student_name = '';
            }
            if($class['status'] == 'Taken'){
                $action = '<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
            }elseif ($class['status'] == 'Started') {
                 $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
            }else{
                $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
            }
            $data[]=array('Date' => date("d-m-Y", strtotime($class['t_date'])),'Class_Time' => $class['t_class_time'],'Student' => $student_name,'Teacher' => $teacher_name,'Course' => $course_name,'Start_Time' => $class['start_time'],'End_Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status']
                );
        }
        $data = array(
                    //"recordsTotal" => count($data),
                    //"recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function update_password()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            $role = $this->input->post('role');
            if($role == 'teacher'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                 $status =$this->Manager_model->update_teacher($id,$data);

            }elseif($role == 'parent'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                $status =$this->Manager_model->update_parent($id,$data);

            }elseif($role == 'manager'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                $status =$this->Manager_model->update_manager($id,$data);
            }
       
            if($status){
                echo json_encode(array('success' => 'Password updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_parent_status()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            if(!empty($_POST['holiday']) && isset($_POST['holiday']) && $_POST['holiday'] == 'yes'){
                $info['start_date'] = date("Y-m-d", strtotime($this->input->post('start_date')));
                $info['end_date']= date("Y-m-d", strtotime($this->input->post('end_date')));
                $info['parent_id'] = $this->input->post('id');
                $status =$this->Manager_model->save_holiday($info);
            }
            $data['status'] = $this->input->post('status');
            $status =$this->Manager_model->update_parent($id,$data);
            if($status){
                echo json_encode(array('success' => 'Status updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_student_status()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            if(!empty($_POST['holiday']) && isset($_POST['holiday']) && $_POST['holiday'] == 'yes'){
                $info['start_date'] = date("Y-m-d", strtotime($this->input->post('start_date')));
                $info['end_date']= date("Y-m-d", strtotime($this->input->post('end_date')));
                $info['student_id'] = $this->input->post('id');
                $status =$this->Manager_model->save_holiday($info);
            }
            $data['status'] = $this->input->post('status');
            $status =$this->Manager_model->update_student($id,$data);
            if($status){
                echo json_encode(array('success' => 'Status updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_parent()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('parent_id');
            $parent_data = $this->Manager_model->get_parent($id);
            echo json_encode($parent_data);
        }
    }

    public function get_messages()
    {
        
        $manager_id = $this->session->userdata('manager_id');
        $messages = $this->Manager_model->get_messages($manager_id);
        echo json_encode($messages);
        
    }

    public function update_parent()
    { 
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post("id");
            $data = array('name'=> $this->input->post("name"),
                'email'=> $this->input->post("email"),
                'username'=> $this->input->post("username"),
                'passwrd'=> md5($this->input->post("password")),
                'telephone_num'=> $this->input->post("landline"),
                'mobile_num'=> $this->input->post("mobile"),
                'sky_id'=> $this->input->post("skype"),
                'notes'=> $this->input->post("note"),
                'manage_id'=> $this->input->post("manager_id"),
                'country_id'=> $this->input->post("country_id"),
                'timezone'=> $this->input->post("timezone"),
                'invoiced'=> $this->input->post("invoiced"),
                'fee'=> $this->input->post("fee"),
                'fee_currency'=> $this->input->post("fee_currency"),
                'fee_type'=> $this->input->post("fee_type"),
                'fee_date'=> $this->input->post("fee_date"));

            $add_parent = $this->Manager_model->update_parent($id,$data);
            if($add_parent){
                
                echo json_encode(array('success'=>'Parent updated successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }
    public function update_student()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
           $id = $this->input->post('id');
            $data['name'] = $this->input->post('name');
            $data['age'] = $this->input->post('age');
            $data['days'] = $this->input->post('days');
            $data['gender'] = $this->input->post('gender');
            $data['course_id'] = $this->input->post('course_id');
            $data['skype'] = $this->input->post('skype_id');
            $data['trial_remarks'] = $this->input->post('trial_remarks');
            $data['manage_id'] = $this->input->post('manager');
            $data['teacher_id'] = $this->input->post('teacher');
            $data['status'] = $this->input->post('status');
            $status =$this->Manager_model->update_student($id,$data);
            if($status){
                echo json_encode(array('success' => 'Student updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_teacher_schedule()
    {   
        if(isset($_POST) && !empty($_POST)){
            $teacher_id = $this->input->post('teacher_id');
            $data = $this->Manager_model->get_teacher_schedule($teacher_id);
            echo json_encode($data);  
        }     
    }

    public function delete_schedule()
    { 
        if(isset($_POST) && !empty($_POST)){
            $schedule_id = $this->input->post("schedule-id");
            $delete_schedule = $this->Manager_model->delete_schedule($schedule_id);
            if($delete_schedule){
                echo json_encode(array('success'=>'Schedule Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

     public function add_schedule()
    {  
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post("student_id");
            $teacher_id = $this->input->post("teacher_id");
            $day = $this->input->post("day");
            $time = $this->input->post("time");
            $schedule_check = $this->Manager_model->schedule_check($student_id,$teacher_id,$time,$day);
            if($schedule_check){
                echo json_encode(array('error'=>'Schedule Already Exist'));
                return true;
            }
            $course_info = $this->Manager_model->get_student_course_id($student_id);
            $data = array('teacher_id'=> $teacher_id,
                'student_id'=> $student_id,
                'day'=> $day,
                'time'=> $time,
                'course_id'=> $course_info->course_id
                );

            $add_schedule = $this->Manager_model->save_schedule($data);
            if($add_schedule){
                echo json_encode(array('success'=>'Schedule Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_student()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $this->input->post('student-name'),
                'skype'=> $this->input->post('student-skype'),
                'age'=> $this->input->post('student-age'),
                'gender'=> $this->input->post('student-gender'),
                'course_id'=> $this->input->post('student-course'),
                'parent_id'=> $this->input->post('student-parent-id'),
                'days'=> $this->input->post('student-days'),
                'manage_id'=> $this->input->post('student-manager'),
                'teacher_id'=> $this->input->post('student-teacher'),
                'trial_remarks'=> $this->input->post('student-trial-remarks'),
                'status'=> $this->input->post('student-status') );
            $add_student = $this->Manager_model->save_student($data);
            if($add_student){
                echo json_encode(array('success'=>'Student Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

   
}
