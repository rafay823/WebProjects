<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lesson extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


    function __construct()
    {
        parent::__construct();
        $this->load->model('Teacher_model');
    }

	public function slesson()
	{
		$data['book_id'] = $this->input->get('book');
		if(!empty($data['book_id'])){
			$data['book_name'] = $this->Teacher_model->get_book_name($data['book_id'])->book_name;
		}else{
			$data['book_name'] = '';
		}
		$data['chapter_id'] = $this->input->get('chapter');
		if(!empty($data['chapter_id'])){
			$data['chap_name'] = $this->Teacher_model->get_chap_name($data['chapter_id'])->book_name;
		}else{
			$data['chap_name'] = '';
		}
		$data['page_id'] = $this->input->get('page');
		$this->load->view('lesson/student',$data);
	}

	public function get_current_lesson()
	{	
		$results = array();
		if(!empty($_POST['student-id']) && isset($_POST['student-id'])){
            $student_id = $this->input->post('student-id');
            $teacher_id = $this->input->post('teacher-id');
            $results =$this->Teacher_model->get_current_history($student_id,$teacher_id);
            if($results){
                echo json_encode($results);
            }
            else{
                echo json_encode($results);
            }
        }else{
            echo json_encode($results);
        }
	}

    public function tlesson()
    {
        $data['book_id'] = $this->input->get('book');
		$data['chapter_id'] = $this->input->get('chapter');
		$data['page_id'] = $this->input->get('page');
		$this->load->view('lesson/teacher',$data);
    }

    public function rlesson()
    {
        $data['book_id'] = $this->input->get('book');
		$this->load->view('lesson/readlesson',$data);
    }

    public function current_lesson()
    {
        if(!empty($_POST['student-id']) && isset($_POST['student-id'])){
            $data['student_id'] = $this->input->post('student-id');
            $data['teacher_id'] = $this->input->post('teacher-id');
            $data['book_id'] = $this->input->post('book-id');
            $data['chapter_id'] = $this->input->post('chap-id');
            $data['page_id'] = $this->input->post('page-id');
            $status =$this->Teacher_model->save_current_history($data);
            if($status){
                echo json_encode(array('success' => 'History saved Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }
   
}
