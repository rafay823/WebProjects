<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
    }

	public function index()
	{

		$this->load->view('admin/login');
	}

    public function testing()
    {   
        //date_default_timezone_set("Asia/Karachi");
        //$timezone = date_default_timezone_get();
        //echo "The current server timezone is: " . $timezone;
        //echo '<br/>';
        //echo date('m/d/Y h:i:s a', time());
        $date = new DateTime('7:10pm', new DateTimeZone('America/Montreal'));
        $date->setTimezone(new DateTimeZone('Europe/Paris'));
        echo $date->format('Y-m-d H:i:sP');

        //$timezone = $this->Admin_model->get_student_timezone($student_id);
        //$timezone = $timezone->timezone;
        //$checkkk = new DateTime($time, new DateTimeZone($timezone));
        //print_r($checkkk);
    }

	public function panel()
	{

		$this->load->view('admin/dashboard');
	}

    public function process_form_seven()
    {
        $this->Admin_model->process_form_seven();
    }

	public function login()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($username == $this->config->item('user_name') && $password == $this->config->item('pass')){
                $session_data = array(
                    'username' => 'Admin',
                    'useremail' => 'admin@comparebox.com',
                );
                $this->session->set_userdata('logged_in', $session_data);
                echo json_encode(array('success'=>'login successfully'));
            }else{
            	echo json_encode(array('error'=>'Wrong Username or Password. Please Try Again !!!!'));
            }
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));
        }
    }

    public function logout()
    {
        $sess_array = array('username'=> '');
        $this->session->unset_userdata('logged_in', $sess_array);
        echo json_encode(array('success'=>'logout successfully'));
    }

    public function check_manager_username()
    {
        if(isset($_POST) && !empty($_POST)){
            $name = $this->input->post('username');
            $check_name = $this->Admin_model->check_manager_username($name);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function set_call_status()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->set_query_call_status($id,$state);
            if($set_status){
                echo json_encode(array('success'=>'Call Status Updated successfully'));
            } else {
                echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function delete_query()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->query_spam($id,$state);
            if($set_status){
                echo json_encode(array('success'=>'Query Spammed successfully'));
            } else {
                echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function close_query()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->query_close($id,$state);
            if($set_status){
                echo json_encode(array('success'=>'Query Close successfully'));
            } else {
                echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function done_query()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->query_done($id,$state);
            if($set_status){
                echo json_encode(array('success'=>'Query Done successfully'));
            } else {
                echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function show_close_query()
    {   $data = array();
        $close_querries = $this->Admin_model->show_close_querys();
        echo json_encode($close_querries);     
    } 

    public function show_open_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_open_querys();
        echo json_encode($open_querries);     
    } 

    public function show_today_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_today_querys();
        echo json_encode($open_querries);     
    } 

    public function show_pending_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_pending_querys();
        echo json_encode($open_querries);     
    } 

    public function show_trial_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_trial_querys();
        echo json_encode($open_querries);     
    } 

    public function show_done_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_done_querys();
        echo json_encode($open_querries);     
    } 

    public function show_spam_query()
    {   $data = array();
        $open_querries = $this->Admin_model->show_spam_querys();
        echo json_encode($open_querries);     
    } 

    public function set_email_status()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->set_query_email_status($id,$state);
            if($set_status){
                echo json_encode(array('success'=>'Email Status Updated successfully'));
            } else {
                echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function set_trial_status()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('id');
            $state = $this->input->post('state');
            $set_status = $this->Admin_model->set_query_trial_status($id,$state);
            if($set_status){
                 echo json_encode(array('success'=>'Trial Status Updated successfully'));
            } else {
                 echo json_encode(array('error'=>'Something bad happened please try again!!!'));
            }
        }
    }

    public function check_manager_email()
    {
        if(isset($_POST) && !empty($_POST)){
            $email = $this->input->post('username');
            $check_name = $this->Admin_model->check_manager_email($email);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function check_manager_cnic()
    {
        if(isset($_POST) && !empty($_POST)){
            $cnic = $this->input->post('cnic');
            $check_name = $this->Admin_model->check_manager_cnic($cnic);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function check_teacher_username()
    {
        if(isset($_POST) && !empty($_POST)){
            $name = $this->input->post('username');
            $check_name = $this->Admin_model->check_teacher_username($name);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function check_teacher_email()
    {
        if(isset($_POST) && !empty($_POST)){
            $email = $this->input->post('email');
            $check_name = $this->Admin_model->check_teacher_email($email);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function check_teacher_cnic()
    {
        if(isset($_POST) && !empty($_POST)){
            $cnic = $this->input->post('cnic');
            $check_name = $this->Admin_model->check_teacher_cnic($cnic);
            if($check_name){
                echo  'yes';
            } else {
                echo  'No';
            }
        }
    }

    public function add_year()
    { 
        if(isset($_POST) && !empty($_POST)){
            $name = $this->input->post("name");
            $year = array('year'=> $name);
            $add_year = $this->Admin_model->save_year($year);
            if($add_year){
                echo json_encode(array('success'=>'Year Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_year()
    { 
        if(isset($_POST) && !empty($_POST)){
            $year_id = $this->input->post("year-id");
            $delete_year = $this->Admin_model->delete_year($year_id);
            if($delete_year){
                echo json_encode(array('success'=>'Year Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function add_course()
    { 
        if(isset($_POST) && !empty($_POST)){
            $name = $this->input->post("name");
            $incharge = $this->input->post("incharge");
            $title = $this->input->post("title");
            $data = array('name'=> $name,'incharge'=> $incharge,'title'=> $title);
            $add_year = $this->Admin_model->save_course($data);
            if($add_year){
                echo json_encode(array('success'=>'Course Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_course()
    { 
        if(isset($_POST) && !empty($_POST)){
            $course_id = $this->input->post("course-id");
            $delete_course = $this->Admin_model->delete_course($course_id);
            if($delete_course){
                echo json_encode(array('success'=>'Course Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function all_courses()
    {   $data = array();
        $all_courses = $this->Admin_model->get_all_years();
        foreach ($all_courses as $course) {
            $data[]=array($course['id'],$course['year'],'testing');
        }
        $data = array('data' =>$data);
        echo json_encode($data);     
    } 

    public function all_managers()
    {   $data = array();
        $all_managers = $this->Admin_model->get_all_managers();
        foreach ($all_managers as $manager) {
            $man_id = $manager['id'];
            $data[]=array('ID' => $manager['id'],'Name' => '<a data-id="'.$man_id.'"  data-toggle="modal" data-target="#view_manager">'.$manager['name'].'</a>','Email' => $manager['email'],'Skype ID' => $manager['skype_id'],'Username' => $manager['username'],'Password' => '<span data-id="'.$man_id.'"  data-toggle="modal" data-target="#change_manager_password" class="badge bg-green">Change Password</span>','Actions' => '<button data-id="'.$man_id.'"  data-toggle="modal" data-target="#edit_manager" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-manager" data-id="'.$man_id.'">Delete</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    } 


    public function all_course_books()
    {   $data = array();
        $all_books = $this->Admin_model->get_course_books();
        foreach ($all_books as $book) {
            $book_id = $book['id'];
            $course = $this->Admin_model->get_student_course($book['course_id']);
            if($course){
                $course_name = $course->name;
            }else{
                $course_name = '';
            }
            $chap_nums = $this->Admin_model->get_chap_num($book['id']);
            if($chap_nums){
                $chap_nums = $chap_nums;
            }else{
                $chap_nums = '0';
            }
            $total_pages = $this->Admin_model->get_total_pages($book['id']);
            if($total_pages){
                $total_pages = $total_pages;
            }else{
                $total_pages = '0';
            }
            $data[]=array('ID' => $book['id'],'Book Name' => $book['book_name'],'Course' => $course_name,'Chap Nums' => $chap_nums,'Total Pages' => $total_pages,'Actions' => '<button data-id="'.$book_id.'"  data-toggle="modal" data-target="#add_book_chapter" class="btn btn-info btn-sm">Add Chapter</button>&nbsp;&nbsp;<button data-id="'.$book_id.'"  data-toggle="modal" data-target="#add_chapter_pages" class="btn btn-info btn-sm">Add chapter Pages</button>&nbsp;&nbsp;<button data-id="'.$book_id.'"  data-toggle="modal" data-target="#edit_book" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-book" data-id="'.$book_id.'">Delete</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    } 

    public function all_teachers()
    {   $data = array();
        $all_teachers = $this->Admin_model->get_all_teachers();
        foreach ($all_teachers as $teacher) {
            $tech_id = $teacher['id'];
            $no_of_student = $this->Admin_model->get_students_nums($tech_id);
            $data[]=array('ID' => $teacher['id'],'Teacher Name' => '<a data-id="'.$tech_id.'"  data-toggle="modal" data-target="#view_teacher">'.$teacher['name'].'</a>','Email' => $teacher['email'],'Username' => $teacher['user_name'],'No of Student' => '<a id="teacher-students" data-id="'.$tech_id.'">'.$no_of_student.'</a>','Shift' => $teacher['shift'],'Gender' => $teacher['gender'],'Skype ID' => $teacher['skype_id'],'Skype Password' => $teacher['skype_passwrd'],'Password' => '<span data-id="'.$tech_id.'"  data-toggle="modal" data-target="#change_teacher_password" class="badge bg-green">Change Password</span>','Actions' => '<button data-id="'.$tech_id.'"  data-toggle="modal" data-target="#edit_teacher" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-teacher" data-id="'.$tech_id.'">Delete</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_years()
    {   $data = array();
        $all_years = $this->Admin_model->get_all_years();
        $i = 1;
        foreach ($all_years as $year) {
            $year_id = $year['id'];
            $data[]=array('No' => $i,'School Year' => $year['year'],'Actions' => '<button data-id="'.$year_id.'"  data-toggle="modal" data-target="#edit_year" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-year" data-id="'.$year_id.'">Delete</button>');
            $i++;
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_shifts()
    {   $data = array();
        $all_shifts = $this->Admin_model->get_all_shifts();
        foreach ($all_shifts as $shift) {
            $shift_id = $shift['id'];
            $data[]=array('ID' => $shift['id'],'Shift' => $shift['shift'],'Start Time' => $shift['s_time'],'End Time' => $shift['e_time'],'Actions' => '<button data-id="'.$shift_id.'"  data-toggle="modal" data-target="#edit_shift" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-shift" data-id="'.$shift_id.'">Delete</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_countires()
    {   $data = array();
        $all_countries = $this->Admin_model->get_all_countries();
        foreach ($all_countries as $country) {
            $country_id = $country['id'];
            $data[]=array('ID' => $country['id'],'Country' => $country['name'],'Code' => $country['code'],'Currency' => $country['currency'],'Actions' => '<button data-id="'.$country_id.'"  data-toggle="modal" data-target="#edit_country" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-country" data-id="'.$country_id.'">Delete</button>');
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function all_students(){   
        $data = array();
        if(isset($_GET) && !empty($_GET)){
            $country = ($this->input->get('country') == 'all' ? '' : $this->input->get('country'));
            $manager = ($this->input->get('manager') == 'all' ? '' : $this->input->get('manager'));
            $teacher = ($this->input->get('teacher') == 'all' ? '' : $this->input->get('teacher'));
            $parent = ($this->input->get('parent') == 'all' ? '' : $this->input->get('parent'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            $all_students = $this->Admin_model->get_all_students_filters($country,$manager,$status,$teacher,$parent);
            foreach ($all_students as $student) {
                $student_id = $student['id'];
                $course = $this->Admin_model->get_student_course($student['course_id']);
                 if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $manager = $this->Admin_model->get_student_manager($student['manage_id']);
                if($manager){
                    $manager_name = $manager->name;
                }else{
                    $manager_name = '';
                }
                $teacher = $this->Admin_model->get_student_teacher($student['teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $country = $this->Admin_model->get_student_country($student['parent_id']);
                if($country){
                    $country_code = $country->code;
                }else{
                    $country_code = '';
                }
                $fname = $this->Admin_model->get_student_fname($student['parent_id']);
                if($fname){
                    $father_name = $fname->name;
                }else{
                    $father_name = '';
                }
                $schedulee = $this->Admin_model->get_student_schedule($student['id']);
                if($schedulee > 0){
                    $schedule = 'Yes';
                }else{
                    $schedule = 'No';
                }
                $classrecords = $this->Admin_model->get_student_classrecords($student['id']);
                $data[]=array('ID' => $student['id'],'Name' => '<a data-id="'.$student_id.'"  data-toggle="modal" data-target="#view_student">'.$student['name'].'</a>','Fathername' => '<a data-id="'.$student['parent_id'].'"  data-toggle="modal" data-target="#view_parent">'.$father_name.'</a>','Schedule' => '<div class="action-buttons"><a data-id="'.$student_id.'"  data-toggle="modal" data-target="#show_schedule" class="green bigger-140 show-details-btn" title="Show Schedule">Show</a></div>','Country' => $country_code,'Gender' => $student['gender'],'Course' => $course_name,'Class Records' => '<a id="students-classes" data-id="'.$student_id.'">'.$classrecords.'</a>','Teacher' => $teacher_name,'Manager' => $manager_name,'Actions' => '<button data-id="'.$student_id.'"  data-toggle="modal" data-target="#edit_student" class="btn btn-info btn-sm">Edit</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$student_id.'" data-parent-id="'.$student['parent_id'].'"  data-toggle="modal" data-target="#change_student_status">Status</button>&nbsp;<button class="btn btn-danger btn-sm demo4 delete-student" data-id="'.$student_id.'">Delete</button>','Schedule_check' => $schedule);
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }else{
            $all_students = $this->Admin_model->get_all_students();
            foreach ($all_students as $student) {
                $student_id = $student['id'];
                $course = $this->Admin_model->get_student_course($student['course_id']);
                 if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $manager = $this->Admin_model->get_student_manager($student['manage_id']);
                if($manager){
                    $manager_name = $manager->name;
                }else{
                    $manager_name = '';
                }
                $teacher = $this->Admin_model->get_student_teacher($student['teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $country = $this->Admin_model->get_student_country($student['parent_id']);
                if($country){
                    $country_code = $country->code;
                }else{
                    $country_code = '';
                }
                $fname = $this->Admin_model->get_student_fname($student['parent_id']);
                if($fname){
                    $father_name = $fname->name;
                }else{
                    $father_name = '';
                }
                $schedulee = $this->Admin_model->get_student_schedule($student['id']);
                if($schedulee > 0){
                    $schedule = 'Yes';
                }else{
                    $schedule = 'No';
                }
                $classrecords = $this->Admin_model->get_student_classrecords($student['id']);
                $data[]=array('ID' => $student['id'],'Name' => '<a data-id="'.$student_id.'"  data-toggle="modal" data-target="#view_student">'.$student['name'].'</a>','Fathername' => '<a data-id="'.$student['parent_id'].'"  data-toggle="modal" data-target="#view_parent">'.$father_name.'</a>','Schedule' => '<div class="action-buttons"><a data-id="'.$student_id.'"  data-toggle="modal" data-target="#show_schedule" class="green bigger-140 show-details-btn" title="Show Schedule">Show</a></div>','Country' => $country_code,'Gender' => $student['gender'],'Course' => $course_name,'Class Records' => '<a id="students-classes" data-id="'.$student_id.'">'.$classrecords.'</a>','Teacher' => $teacher_name,'Manager' => $manager_name,'Actions' => '<button data-id="'.$student_id.'"  data-toggle="modal" data-target="#edit_student" class="btn btn-info btn-sm">Edit</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$student_id.'" data-parent-id="'.$student['parent_id'].'" data-toggle="modal" data-target="#change_student_status">Status</button>&nbsp;<button class="btn btn-danger btn-sm demo4 delete-student" data-id="'.$student_id.'">Delete</button>','Schedule_check' => $schedule);
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }
    }

    public function all_invoices()
    {   
        $data = array();
        $months = array('1' => 'Jan',
            '2' => 'Feb',
            '3' => 'Mar',
            '4' => 'April',
            '5' => 'May',
            '6' => 'June',
            '7' => 'July',
            '8' => 'Aug',
            '9' => 'Sep',
            '10' => 'Oct',
            '11' => 'Nov',
            '12' => 'Dec');
        if(isset($_GET) && !empty($_GET)){
            $month = ($this->input->get('month') == 'all' ? '' : $this->input->get('month'));
            $manager = ($this->input->get('manager') == 'all' ? '' : $this->input->get('manager'));
            $year = ($this->input->get('year') == 'all' ? '' : $this->input->get('year'));
            $ftype = ($this->input->get('ftype') == 'all' ? '' : $this->input->get('ftype'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            if(isset($_GET['parent']) && !empty($_GET['parent'])){
            	$parent = $this->input->get('parent');
            }else{
            	$parent = '';
            }
            $all_invoices = $this->Admin_model->get_all_invoices_filters($month,$manager,$year,$ftype,$status,$parent);
            foreach ($all_invoices as $invoice) {
                $invoice_id = $invoice['id'];
                $mon = $invoice['month'];
                $month = $months[$mon];
                $data[]=array('ID' => $invoice['id'],'Name' => $invoice['name'],'Invoice Type' => $invoice['type'],'Month Year' => $month.'/'.$invoice['year'],'Fee Amt' => $invoice['amount'],'Fee Adj' => $invoice['adjustment'],'Full Amt' => $invoice['amount']+$invoice['adjustment'],'Due Date' => $invoice['due_date'],'Inv SaleNo' => '','Status' => $invoice['status'],'Fee Type' => $invoice['fee_type'],'Actions' => '<button data-id="'.$invoice_id.'"  data-toggle="modal" data-target="#edit_invoice" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-warning btn-sm demo4 remind-invoice" data-id="'.$invoice_id.'">Remind</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-invoice" data-id="'.$invoice_id.'">Delete</button>');
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }    
        else{
            $all_invoices = $this->Admin_model->get_all_invoices();
            foreach ($all_invoices as $invoice) {
                $invoice_id = $invoice['id'];
                $mon = $invoice['month'];
                $month = $months[$mon];
                $data[]=array('ID' => $invoice['id'],'Name' => $invoice['name'],'Invoice Type' => $invoice['type'],'Month Year' => $month.'/'.$invoice['year'],'Fee Amt' => $invoice['amount'],'Fee Adj' => $invoice['adjustment'],'Full Amt' => $invoice['amount']+$invoice['adjustment'],'Due Date' => $invoice['due_date'],'Inv SaleNo' => '','Status' => $invoice['status'],'Fee Type' => $invoice['fee_type'],'Actions' => '<button data-id="'.$invoice_id.'"  data-toggle="modal" data-target="#edit_invoice" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-warning btn-sm demo4 remind-invoice" data-id="'.$invoice_id.'">Remind</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-invoice" data-id="'.$invoice_id.'">Delete</button>');
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }         
    }

    public function all_parents()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            $country = ($this->input->get('country') == 'all' ? '' : $this->input->get('country'));
            $manager = ($this->input->get('manager') == 'all' ? '' : $this->input->get('manager'));
            $fdate = ($this->input->get('fdate') == 'all' ? '' : $this->input->get('fdate'));
            $ftype = ($this->input->get('ftype') == 'all' ? '' : $this->input->get('ftype'));
            $invoice = ($this->input->get('invoice') == 'all' ? '' : $this->input->get('invoice'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            $all_parents = $this->Admin_model->get_all_parents_filters($country,$manager,$fdate,$ftype,$invoice,$status);
            foreach ($all_parents as $parent) {
                $parent_id = $parent['id'];
                $manager = $this->Admin_model->get_student_manager($parent['manage_id']);
                if($manager){
                    $manager_name = $manager->name;
                }else{
                    $manager_name = '';
                }
                $country = $this->Admin_model->get_country_name($parent['country_id']);
                if($country){
                    $country_code = $country->code;
                }else{
                    $country_code = '';
                }
                $students_num = $this->Admin_model->get_student_num($parent['id']);
                if($students_num){
                    $student_num = $students_num;
                }else{
                    $student_num = '0';
                }
                $data[]=array('ID' => $parent['id'],'Name' => '<a data-id="'.$parent_id.'"  data-toggle="modal" data-target="#view_parent">'.$parent['name'].'</a>','Email' => $parent['email'],'Phone' => $parent['telephone_num'],'Mobile' => $parent['mobile_num'],'Skype' => $parent['sky_id'],'Country' => $country_code,'Username' => $parent['username'],'Manager' => $manager_name,'Students' => '<a id="parent-students" data-id="'.$parent_id.'">'.$student_num.'</a>','Fee' => $parent['fee'].'<span id="v_p_fee" data-id="'.$parent_id.'" class="label label-success pull-right">v</span>','Fee Date' => $parent['fee_date'],'Password' => '<span data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_password" class="badge bg-green">Change Password</span>','Actions' => '<button data-id="'.$parent_id.'" data-toggle="modal" data-target="#add_student" class="btn btn-primary btn-sm">Add</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_status">Status</button>&nbsp;<button data-id="'.$parent_id.'"  data-toggle="modal" data-target="#edit_parent" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-parent" data-id="'.$parent_id.'">Del</button>');
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }
        else{
            $all_parents = $this->Admin_model->get_all_parents();
            foreach ($all_parents as $parent) {
                $parent_id = $parent['id'];
                $manager = $this->Admin_model->get_student_manager($parent['manage_id']);
                if($manager){
                    $manager_name = $manager->name;
                }else{
                    $manager_name = '';
                }
                $country = $this->Admin_model->get_country_name($parent['country_id']);
                if($country){
                    $country_code = $country->code;
                }else{
                    $country_code = '';
                }
                $students_num = $this->Admin_model->get_student_num($parent['id']);
                if($students_num){
                    $student_num = $students_num;
                }else{
                    $student_num = '0';
                }
                $data[]=array('ID' => $parent['id'],'Name' => '<a data-id="'.$parent_id.'"  data-toggle="modal" data-target="#view_parent">'.$parent['name'].'</a>','Email' => $parent['email'],'Phone' => $parent['telephone_num'],'Mobile' => $parent['mobile_num'],'Skype' => $parent['sky_id'],'Country' => $country_code,'Username' => $parent['username'],'Manager' => $manager_name,'Students' => '<a id="parent-students" data-id="'.$parent_id.'">'.$student_num.'</a>','Fee' => $parent['fee'].'<span id="v_p_fee" data-id="'.$parent_id.'" class="label label-success pull-right">v</span>','Fee Date' => $parent['fee_date'],'Password' => '<span data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_password" class="badge bg-green">Change Password</span>','Actions' => '<button data-id="'.$parent_id.'" data-toggle="modal" data-target="#add_student" class="btn btn-primary btn-sm">Add</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_status">Status</button>&nbsp;<button data-id="'.$parent_id.'"  data-toggle="modal" data-target="#edit_parent" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-parent" data-id="'.$parent_id.'">Del</button>');
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }     
    }

    public function all_complaints()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            $country = ($this->input->get('country') == 'all' ? '' : $this->input->get('country'));
            $manager = ($this->input->get('manager') == 'all' ? '' : $this->input->get('manager'));
            $fdate = ($this->input->get('fdate') == 'all' ? '' : $this->input->get('fdate'));
            $ftype = ($this->input->get('ftype') == 'all' ? '' : $this->input->get('ftype'));
            $invoice = ($this->input->get('invoice') == 'all' ? '' : $this->input->get('invoice'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            $all_parents = $this->Admin_model->get_all_parents_filters($country,$manager,$fdate,$ftype,$invoice,$status);
            foreach ($all_parents as $parent) {
                $parent_id = $parent['id'];
                $manager = $this->Admin_model->get_student_manager($parent['manage_id']);
                if($manager){
                    $manager_name = $manager->name;
                }else{
                    $manager_name = '';
                }
                $country = $this->Admin_model->get_country_name($parent['country_id']);
                if($country){
                    $country_code = $country->code;
                }else{
                    $country_code = '';
                }
                $students_num = $this->Admin_model->get_student_num($parent['id']);
                if($students_num){
                    $student_num = $students_num;
                }else{
                    $student_num = '0';
                }
                $data[]=array('ID' => $parent['id'],'Name' => '<a data-id="'.$parent_id.'"  data-toggle="modal" data-target="#view_parent">'.$parent['name'].'</a>','Email' => $parent['email'],'Phone' => $parent['telephone_num'],'Mobile' => $parent['mobile_num'],'Skype' => $parent['sky_id'],'Country' => $country_code,'Username' => $parent['username'],'Manager' => $manager_name,'Students' => '<a id="parent-students" data-id="'.$parent_id.'">'.$student_num.'</a>','Fee' => $parent['fee'],'Fee Date' => $parent['fee_date'],'Password' => '<span data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_password" class="badge bg-green">Change Password</span>','Actions' => '<button data-id="'.$parent_id.'" data-toggle="modal" data-target="#add_student" class="btn btn-primary btn-sm">Add</button>&nbsp;<button class="btn btn-warning2 btn-sm demo4" data-id="'.$parent_id.'"  data-toggle="modal" data-target="#change_parent_status">Status</button>&nbsp;<button data-id="'.$parent_id.'"  data-toggle="modal" data-target="#edit_parent" class="btn btn-info btn-sm">Edit</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-parent" data-id="'.$parent_id.'">Del</button>');
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }
        else{
            $all_complaints = $this->Admin_model->get_all_complaints();
            foreach ($all_complaints as $complaint) {
                $complaint_id = $complaint['id'];
                $data[]=array('ID' => $complaint_id,'Student Name' => $complaint['sname'],'Parent Name' => $complaint['pname'],'Teacher Name' => $complaint['tname'],'Complaint' => $complaint['complaint'],'Remarks' => $complaint['remarks'],'Status' => $complaint['status'],'Actions' => '<button class="btn btn-warning2 btn-sm demo4" data-id="'.$complaint_id.'"  data-toggle="modal" data-target="#change_parent_status">Done</button>&nbsp;<button data-id="'.$complaint_id.'"  data-toggle="modal" data-target="#edit_parent" class="btn btn-info btn-sm">Discuss</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 delete-parent" data-id="'.$complaint_id.'">Del</button>'); 
            }

            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }     
    }

    public function get_all_cmts(){
        $all_courses = $this->Admin_model->get_all_courses();
        $all_managers = $this->Admin_model->get_all_managers();
        $all_teachers = $this->Admin_model->get_all_teachers();
        $data = array('courses' => $all_courses,
            'managers' => $all_managers,
            'teachers' => $all_teachers
            );
        echo json_encode($data);
    }

    public function get_student_status(){
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post('student_id');
            $data = $this->Admin_model->get_student_status($student_id);
            echo json_encode($data);  
        }  
    }

    public function get_teacher_schedule()
    {   
        date_default_timezone_set("UTC");
        if(isset($_POST) && !empty($_POST)){
            $teacher_id = $this->input->post('teacher_id');
            $data = $this->Admin_model->get_teacher_schedule($teacher_id);
            $i = 0;
            foreach ($data as $key => $value) {
                if(!empty($value)){
                    $time = new DateTime("@".strtotime($value['time']));
                    $time->setTimezone(new DateTimeZone('Asia/Karachi'));
                    $data[$i]['time'] = $time->format('g:i A');
                } 
                $i++;   
            }
            echo json_encode($data);  
        }     
    }

    public function get_student_by_teacher()
    {   
        if(isset($_POST) && !empty($_POST)){
            $teacher_id = $this->input->post('teacher_id');
            $data = $this->Admin_model->get_student_by_teacher($teacher_id);
            echo json_encode($data);  
        }     
    }

    public function get_student_days()
    {   
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post('student_id');
            $data = $this->Admin_model->get_student_days($student_id);
            $days = explode(',',$data[0]['days']);
            $final_days = array();
            foreach ($days as $d) {
                if($d == 'mon'){
                    $final_days['Monday'] = 'Monday';
                }
                if($d == 'tues'){
                    $final_days['Tuesday'] = 'Tuesday';
                }
                if($d == 'wed'){
                    $final_days['Wednesday'] = 'Wednesday';
                }
                if($d == 'thur'){
                    $final_days['Thursday'] = 'Thursday';
                }
                if($d == 'fri'){
                    $final_days['Friday'] = 'Friday';
                }
                if($d == 'sat'){
                    $final_days['Saturday'] = 'Saturday';
                }
                if($d == 'sun'){
                    $final_days['Sunday'] = 'Sunday';
                }
            }
            echo json_encode($final_days);  
        }     
    }


    public function add_manager()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $this->input->post("manager_name"),
                'skype_id'=> $this->input->post("manager_skype_id"),
                'salary_pack'=> $this->input->post("manager_sal_pack"),
                'email'=> $this->input->post("manager_email"),
                'username'=> $this->input->post("manager_username"),
                'passwrd'=> md5($this->input->post("manager_password")),
                'address'=> $this->input->post("manager_address"),
                'telephone'=> $this->input->post("manager_landline"),
                'mobile'=> $this->input->post("manager_mobile"),
                'shift_id'=> $this->input->post("shift_id"),
                'cnic'=> $this->input->post("manager_cnic"));

            $add_teacher = $this->Admin_model->save_manager($data);
            if($add_teacher){
                echo json_encode(array('success'=>'Manager Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_complaint_responce()
    {
        if(isset($_POST) && !empty($_POST)){
            $comp_id = $this->input->post("id");
            $comp_name = $this->input->post("complaint_name");
            $comment = $this->input->post("comment");
            $comment_date = date('Y-m-d');
            $complaint_comments = $this->Admin_model->get_comments($comp_id); 
            $new_comment = array('name' => $comp_name, 'date' => $comment_date , 'remarks' => $comment);
            if(!empty($complaint_comments->remarks)){
                $remarks = json_decode($complaint_comments->remarks);
                array_push($remarks,$new_comment);
            }else{
                $remarks = array();
                array_push($remarks,$new_comment);
            }
            $data['remarks'] = json_encode($remarks);
            $update_complaint_comments = $this->Admin_model->update_comments($comp_id,$data); 
            if($update_complaint_comments){
                echo json_encode(array('success'=>'Remarks Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }

        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_query_responce()
    {
        if(isset($_POST) && !empty($_POST)){
            $query_id = $this->input->post("id");
            $query_name = $this->input->post("query_name");
            $comment = $this->input->post("comment");
            $comment_date = date('Y-m-d');
            $query_comments = $this->Admin_model->get_query($query_id); 
            $new_comment = array('name' => $query_name, 'date' => $comment_date , 'comments' => $comment);
            if(!empty($query_comments->comments)){
                $remarks = json_decode($query_comments->comments);
                array_push($remarks,$new_comment);
            }else{
                $remarks = array();
                array_push($remarks,$new_comment);
            }
            $data['comments'] = json_encode($remarks);
            $update_query_comments = $this->Admin_model->update_qurries($query_id,$data); 
            if($update_query_comments){
                echo json_encode(array('success'=>'Note Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }

        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_query()
    {
        if(isset($_POST) && !empty($_POST) && isset($_POST['name']) && !empty($_POST['name']) && isset($_POST['message']) && !empty($_POST['message'])){
            $data['name'] = $this->input->post("name");
            $data['email'] = $this->input->post("email");
            $data['phone'] = $this->input->post("phone");
            $data['country'] = $this->input->post("country");
            $data['message'] = $this->input->post("message");
            $data['source'] = $this->input->post("source");
            $data['status'] = 'Pending';
            $data['date'] = date('Y-m-d');
            $add_query = $this->Admin_model->save_query($data); 
            if($add_query){
                echo json_encode(array('success'=>'Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_manager()
    { 
        if(isset($_POST) && !empty($_POST)){
            $manager_id = $this->input->post("manager-id");
            $delete_manager = $this->Admin_model->delete_manager($manager_id);
            if($delete_manager){
                echo json_encode(array('success'=>'Manager Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function get_manager()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('manager_id');
            $manager_data = $this->Admin_model->get_manager($id);
            echo json_encode($manager_data);
        }
    }

    public function daily_class_schedule()
    {
        $day = date('l');
        $date = date("Y-m-d");
        $day_data = $this->Admin_model->get_today_schedule($day);
        foreach ($day_data as $data) {
            $student_course = $this->Admin_model->get_student_course_id($data['student_id']);
            $teacher_leave = $this->Admin_model->get_teacher_leave($data['teacher_id'],$date);
            if($teacher_leave){
                $status = 'Teacher Leave';
            }else{
                $status = 'Pending';
            }
            $info = array('student_id'=> $data['student_id'] ,
                'Teacher_id'=> $data['teacher_id'] ,
                'day'=> $data['day'],
                'class_time'=> $data['time'],  
                'course_id'=> $student_course->course_id,
                'status'=> $status,
                'date'=> date("Y-m-d"),
                );
            $this->Admin_model->save_class($info);
        } 
        echo json_encode($info);
    }

    public function update_class_from_schedule()
    {
        $day = date('l');
        $student_ids = $this->input->post('student_ids');
        $student_ids = explode(',', $student_ids);
        $day_data = $this->Admin_model->updated_studnet_schedule($day,$student_ids);
        foreach ($day_data as $data) {
            $student_course = $this->Admin_model->get_student_course_id($data['student_id']);
            $info = array('student_id'=> $data['student_id'] ,
                'Teacher_id'=> $data['teacher_id'] ,
                'day'=> $data['day'],
                'class_time'=> $data['time'],  
                'course_id'=> $student_course->course_id,
                'status'=> "Pending",
                'date'=> date("Y-m-d"),
                );
            $this->Admin_model->save_class($info);
        } 
        echo json_encode($day_data);
    }

    public function class_reschedule()
    {
        date_default_timezone_set("Asia/Karachi");
        if(!empty($_POST['class_id']) && isset($_POST['class_id'])){
            $id = $this->input->post('class_id');
            $time = $this->input->post("time");
            $s_time = new DateTime($time);
            $s_time->setTimezone(new DateTimeZone("UTC"));
            $data['lesson'] = '';
            $data['remarks'] = '';
            $data['end_time'] = '';
            $data['status'] = 'Pending';
            $data['start_time'] = '';
            $data['duration'] = '';
            $data['date'] = date("Y-m-d",strtotime($_POST['date']));
            $data['class_time'] = $s_time->format('h:i A');
            $data['day'] = date('l', strtotime($data['date']));
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class Reschedule Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function today_classes()
    {   $data = array();
        $day = date('l');
        $date = date("Y-m-d");
        date_default_timezone_set("UTC");    
        if(isset($_GET) && !empty($_GET)){
            //$manager = ($this->input->get('manager') == 'all' ? '' : $this->input->get('manager'));
            $teacher = ($this->input->get('teacher') == 'all' ? '' : $this->input->get('teacher'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            $today_classses = $this->Admin_model->get_today_classes_filters($day,$date,$status,$teacher);
            foreach ($today_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                $student = $this->Admin_model->get_student_name($class['student_id']);
                $time = new DateTime("@".strtotime($class['class_time']));
                $time->setTimezone(new DateTimeZone('Asia/Karachi'));
                $class_time = $time->format('g:i A');
                if($class['status'] == 'Taken' || $class['status'] == 'Student Leave'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<!--<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;--><button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Teacher Leave') {
                        $action = '<button class="btn btn-danger btn-sm demo4 class-teacher-assign" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_teacher_assign">Assign</button>';
                }else{
                    $action = '<!--<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;--><button class="btn btn-danger btn-sm demo4 class-reschedule" data-toggle="modal" data-target="#class_reschedule" data-id="'.$class_id.'">R-S</button>&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>&nbsp;<button id="teacher-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">T-L</button>&nbsp;<button id="student-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">S-L</button>';
                }
                if($class['status'] == 'Student Leave Approval'){
                    $action .= '&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-student-approve" data-id="'.$class_id.'">Approve</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class_time,'Student' => $student->name,'Teacher' => $teacher->name,'Course' => $course->name,'History' => '<a id="students-classes" data-id="'.$class['student_id'].'">History</a>','Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status'],'Actions' => $action);
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data);
        }
        else{
            $today_classses = $this->Admin_model->get_today_classes($day,$date);
            foreach ($today_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                $student = $this->Admin_model->get_student_name($class['student_id']);
                $time = new DateTime("@".strtotime($class['class_time']));
                $time->setTimezone(new DateTimeZone('Asia/Karachi'));
                $class_time = $time->format('g:i A');
                if($class['status'] == 'Taken' || $class['status'] == 'Teacher Leave' || $class['status'] == 'Student Leave'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<!--<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;--><button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }else{
                    $action = '<!--<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;--><button class="btn btn-danger btn-sm demo4 class-reschedule" data-toggle="modal" data-target="#class_reschedule" data-id="'.$class_id.'">R-S</button>&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>&nbsp;<button id="teacher-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">T-L</button>&nbsp;<button id="student-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">S-L</button>';
                }
                if($class['status'] == 'Student Leave Approval'){
                    $action .= '&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-student-approve" data-id="'.$class_id.'">Approve</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class_time,'Student' => $student->name,'Teacher' => $teacher->name,'Course' => $course->name ,'History' => '<a id="students-classes" data-id="'.$class['student_id'].'">History</a>','Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status'],'Actions' => $action);
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }    
    }

    public function all_classes()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            //echo date("d-m-Y", strtotime($this->input->get('date')));
            $teacher = ($this->input->get('teacher') == 'all' ? '' : $this->input->get('teacher'));
            $status = ($this->input->get('status') == 'all' ? '' : $this->input->get('status'));
            $date = ($this->input->get('date') == '' ? '' : date("Y-m-d", strtotime($this->input->get('date'))));
            $all_classses = $this->Admin_model->get_all_classes_filters($date,$status,$teacher);    
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = ''; 
                }
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Admin_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name.'<span id="d_h_v" data-id="'.$class_id.'" data-toggle="modal" data-target="#view_class_remarks" class="label label-success pull-right">D</span>','Teacher' => $teacher_name,'Course' => $course_name,'Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }else{
            $all_classses = $this->Admin_model->get_all_classes();
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Admin_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">R-S</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-reschedule" data-id="'.$class_id.'">R-S</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name.'<span id="d_h_v" data-id="'.$class_id.'" data-toggle="modal" data-target="#view_class_remarks" class="label label-success pull-right">D</span>','Teacher' => $teacher_name,'Course' => $course_name,'Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }    
    }

    public function classes_history()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            $student = $this->input->get('student');
            $all_classses = $this->Admin_model->get_all_classes_filters($student);    
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = ''; 
                }
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Admin_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Student' => $student_name,'Teacher' => $teacher_name,'Lesson' => $class['lesson'],'Remarks' => $class['remarks'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }else{
            $all_classses = $this->Admin_model->get_all_classes();
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Admin_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = '';
                }
                $teacher = $this->Admin_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Admin_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name,'Teacher' => $teacher_name,'Lesson' => $class['lesson'],'Remarks' => $class['remarks'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }    
    }

    public function start_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['start_time'] = $this->input->post('start_time');
            $data['status'] = 'Started';
            $status =$this->Admin_model->update_class($id,$data);
       
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function end_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['end_time'] = $this->input->post('end_time');
            $data['status'] = 'Taken';
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                $calc_duration =$this->Admin_model->get_class_times($id);
                $start_time = $calc_duration->start_time;
                $end_time = $calc_duration->end_time;
                $Duration = strtotime($end_time) - strtotime($start_time);
                $hour = $Duration / 3600 % 24;
                $minute = $Duration / 60 % 60;    
                $second = $Duration % 60;
                $Duration = $hour.':'.$minute.':'.$second;
                $info['duration'] = $Duration;
                $this->Admin_model->update_class($id,$info);
                echo json_encode(array('duration' => $Duration));
                //echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function set_leave()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['status'] = $this->input->post('leave');
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function add_class_remarks()
    {
        if(!empty($_POST['class_id']) && isset($_POST['class_id'])){
            $id = $_POST['class_id'];
            $data['lesson'] = $this->input->post('lesson');
            $data['remarks'] = $this->input->post('Remarks');
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class Completed Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function assign_class_teacher()
    {
        if(!empty($_POST['class_id']) && isset($_POST['class_id'])){
            $id = $_POST['class_id'];
            $data['Teacher_id'] = $this->input->post('teacher_id');
            $data['status'] = 'Pending';
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Teacher Asssign Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }


    public function class_validate()
    {
        if(!empty($_POST['class_id']) && isset($_POST['class_id'])){
            $id = $_POST['class_id'];
            $data['lesson'] = '';
            $data['remarks'] = '';
            $data['end_time'] = '';
            $data['status'] = 'Pending';
            $data['start_time'] = '';
            $data['duration'] = '';
            $status =$this->Admin_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class validated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_manager()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['name'] = $_POST['name'];
            $data['cnic'] = $_POST['cnic'];
            $data['address'] = $_POST['address'];
            $data['telephone'] = $_POST['landline'];
            $data['mobile'] = $_POST['mobile'];
            $data['email'] = $_POST['email'];
            $data['skype_id'] = $_POST['skype'];
            $data['salary_pack'] = $_POST['salary'];   
            $data['shift_id'] = $_POST['shift'];
            $data['username'] = $_POST['username'];
            $data['passwrd'] = $_POST['pass'];
            
            $status =$this->Admin_model->update_manager($id,$data);
       
            if($status){
                echo json_encode(array('success' => 'Manager updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_password()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            $role = $this->input->post('role');
            if($role == 'teacher'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                 $status =$this->Admin_model->update_teacher($id,$data);

            }elseif($role == 'parent'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                $status =$this->Admin_model->update_parent($id,$data);

            }elseif($role == 'manager'){
                $data['passwrd'] = md5($this->input->post('new_pass'));
                $status =$this->Admin_model->update_manager($id,$data);
            }
       
            if($status){
                echo json_encode(array('success' => 'Password updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function add_teacher()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $this->input->post("teacher_name"),
                'father_name'=> $this->input->post("father_name"),
                'skype_id'=> $this->input->post("skype_id"),
                'skype_passwrd'=> $this->input->post("skype_passwrd"),
                'salary'=> $this->input->post("sal_pack"),
                'email'=> $this->input->post("teacher_email"),
                'designation'=> $this->input->post("designation"),
                'shift_id'=> $this->input->post("shift_id"),
                'user_name'=> $this->input->post("teacher_username"),
                'passwrd'=> md5($this->input->post("password")),
                'qualification'=> $this->input->post("qualification"),
                'address'=> $this->input->post("address"),
                'landline'=> $this->input->post("landline"),
                'mobile'=> $this->input->post("mobile"),
                'gender'=> $this->input->post("gender"),
                'experience'=> $this->input->post("experience"),
                'inter_remarks'=> $this->input->post("inter_remarks"),
                'martial_status'=> $this->input->post("martial_status"),
                'cnic'=> $this->input->post("teacher_cnic"));

            $add_teacher = $this->Admin_model->save_teacher($data);
            if($add_teacher){
                echo json_encode(array('success'=>'Teacher Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function teacher_leaves()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('teacher_id'=> $this->input->post("leave_teacher_id"),
                'date'=> date("Y-m-d", strtotime($this->input->post("teacher-leave-date"))),
                'reason'=> $this->input->post("leave-reason"));
            $teacher_leave = $this->Admin_model->save_teacher_leave($data);
            if($teacher_leave){
                echo json_encode(array('success'=>'Teacher Leave Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_teacher()
    { 
        if(isset($_POST) && !empty($_POST)){
            $teacher_id = $this->input->post("teacher-id");
            $delete_teacher = $this->Admin_model->delete_teacher($teacher_id);
            if($delete_teacher){
                echo json_encode(array('success'=>'Teacher Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function add_country()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $this->input->post("count-name"),
                'code'=> $this->input->post("count-code"),
                'currency'=> $this->input->post("count-currency"));

            $add_country = $this->Admin_model->save_country($data);
            if($add_country){
                echo json_encode(array('success'=>'Country Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_country()
    { 
        if(isset($_POST) && !empty($_POST)){
            $country_id = $this->input->post("country-id");
            $delete_country = $this->Admin_model->delete_country($country_id);
            if($delete_country){
                echo json_encode(array('success'=>'Country Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function add_shift()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('shift'=> $this->input->post("shift"),
                's_time'=> $this->input->post("shift-start-time"),
                'e_time'=> $this->input->post("shift-end-time"));

            $add_shift = $this->Admin_model->save_shift($data);
            if($add_shift){
                echo json_encode(array('success'=>'Shift Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_shift()
    { 
        if(isset($_POST) && !empty($_POST)){
            $shift_id = $this->input->post("shift-id");
            $delete_shift = $this->Admin_model->delete_shift($shift_id);
            if($delete_shift){
                echo json_encode(array('success'=>'Shift Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function add_parent()
    { 
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $this->input->post("parent-name"),
                'email'=> $this->input->post("parent-email"),
                'username'=> $this->input->post("username"),
                'passwrd'=> md5($this->input->post("password")),
                'telephone_num'=> $this->input->post("landline"),
                'mobile_num'=> $this->input->post("mobile"),
                'sky_id'=> $this->input->post("parent-skype"),
                'notes'=> $this->input->post("notes"),
                'manage_id'=> $this->input->post("parent-manager"),
                'country_id'=> $this->input->post("country"),
                'fee'=> $this->input->post("fee"),
                'fee_currency'=> $this->input->post("fee-currency"),
                'fee_type'=> $this->input->post("fee-type"),
                'timezone'=> $this->input->post("parent-timezone"),
                'invoiced'=> $this->input->post("parent-invoiced"),
                'status'=> 'active',
                'fee_date'=> $this->input->post("fee-date"));

            $add_parent = $this->Admin_model->save_parent($data);
            if($add_parent){
                $parent_id = $add_parent;
                $zn = 0;
                if(isset($_POST['student-name']) && !empty($_POST['student-name'])){
                    foreach($_POST['student-name'] as $student_name){
                        $days = array();
                        if(isset($_POST['mon-day'][$zn])){
                            array_push($days,$_POST['mon-day'][$zn]);
                        }
                        if(isset($_POST['tues-day'][$zn])){
                            array_push($days,$_POST['tues-day'][$zn]); 
                        }
                        if(isset($_POST['wed-day'][$zn])){
                            array_push($days,$_POST['wed-day'][$zn]); 
                        }
                        if(isset($_POST['thur-day'][$zn])){
                            array_push($days,$_POST['thur-day'][$zn]); 
                        }
                        if(isset($_POST['fri-day'][$zn])){
                            array_push($days,$_POST['fri-day'][$zn]); 
                        }
                        if(isset($_POST['sat-day'][$zn])){
                            array_push($days,$_POST['sat-day'][$zn]); 
                        }
                        $data = array('name'=> $student_name,
                            'skype'=> $_POST['student-skype'][$zn],
                            'age'=> $_POST['student-age'][$zn],
                            'gender'=> $_POST['student-gender'][$zn],
                            'course_id'=> $_POST['course'][$zn],
                            'parent_id'=> $parent_id,
                            'days'=> implode(",",$days),
                            //'fees'=> $_POST['student-fee'][$zn],
                            'manage_id'=> $_POST['student-manager'][$zn],
                            'teacher_id'=> $_POST['student-teacher'][$zn],
                            'trial_remarks'=> $_POST['trial-class-remarks'][$zn],
                            'status'=> $_POST['status'][$zn]);
                        $add_student = $this->Admin_model->save_student($data);
                        if($add_student){
                            $teacher_notification = array(
                                'type' => 'Add Student',
                                'content' => 'teeacher notification testing'
                                );

                            $parent_notification = array(
                                'type' => 'Add Student',
                                'content' => 'parent notification testing'
                                );
                            $manager_notification = array(
                                'type' => 'Add Student',
                                'content' => 'manager notification testing'
                                );
                            $this->Admin_model->save_teacher_notification($data['teacher_id'],$teacher_notification);
                            $this->Admin_model->save_parent_notification($data['parent_id'],$parent_notification);
                        }
                        $zn++;
                    }

                }

                echo json_encode(array('success'=>'Parent Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_course_book()
    { 
        if(isset($_POST) && !empty($_POST)){
            $data = array('book_name'=> $this->input->post("course-book-name"),
                'course_id'=> $this->input->post("course-id"));
            $add_book = $this->Admin_model->save_book($data);
            if($add_book){
                $book_id = $add_book;
                if(isset($_POST['book-chapter-name']) && !empty($_POST['book-chapter-name'])){
                    foreach($_POST['book-chapter-name'] as $chapter_name){
                        $data = array('chapter_name'=> $chapter_name,
                            'book_id'=> $book_id);
                        $add_chapter = $this->Admin_model->save_book_chapter($data);
                    }
                }
                echo json_encode(array('success'=>'Book Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function instant_invoiced()
    { 
        if(isset($_POST) && !empty($_POST)){
            $parent_id = $this->input->post("invoiced-parent-id");
            $month_id = $this->input->post("invoiced-month");
            $year = $this->input->post("invoiced-year");
            $due_date = $this->input->post("invoiced-due-date");
            $due_date = date("Y-m-d", strtotime($due_date));
            $parent_data = $this->Admin_model->get_parent_fee($parent_id);
            //$year_data = $this->Admin_model->get_year_year($year_id);
            $check_invoice = $this->Admin_model->check_instant_invoice($parent_id,$month_id,$year);
            if($check_invoice){
                echo json_encode(array('error'=>'Invoice Already Exist'));
            }else{
                $data = array('parent_id'=> $parent_id,
                    'month'=> $this->input->post("invoiced-month"),
                    'year'=> $this->input->post("invoiced-year"),
                    'due_date'=> $due_date,
                    'type'=> 'Instant',
                    'amount'=> $parent_data->fee,
                    'status'=> 'Pending',
                    'notes'=> 'Testing');

                $add_invoice = $this->Admin_model->save_instant_invoice($data);
                if($add_invoice){
                    echo json_encode(array('success'=>'Invoice Sent successfully'));
                }else{
                    echo json_encode(array('error'=>'Something went wrong plz try again'));
                }
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function update_parent()
    { 
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post("id");
            $data = array('name'=> $this->input->post("name"),
                'email'=> $this->input->post("email"),
                'username'=> $this->input->post("username"),
                'telephone_num'=> $this->input->post("landline"),
                'mobile_num'=> $this->input->post("mobile"),
                'sky_id'=> $this->input->post("skype"),
                'notes'=> $this->input->post("note"),
                'manage_id'=> $this->input->post("manager_id"),
                'country_id'=> $this->input->post("country_id"),
                'timezone'=> $this->input->post("timezone"),
                'invoiced'=> $this->input->post("invoiced"),
                'fee'=> $this->input->post("fee"),
                'fee_currency'=> $this->input->post("fee_currency"),
                'fee_type'=> $this->input->post("fee_type"),
                'fee_date'=> $this->input->post("fee_date"));

            $add_parent = $this->Admin_model->update_parent($id,$data);
            if($add_parent){
                
                echo json_encode(array('success'=>'Parent updated successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function add_student_record()
    { 
        if(isset($_POST) && !empty($_POST)){
            
            $data = array('name'=> $this->input->post('name'),
                'skype'=> $this->input->post('skype'),
                'age'=> $this->input->post('age'),
                'gender'=> $this->input->post('gender'),
                'course_id'=> $this->input->post('course_id'),
                'parent_id'=> $this->input->post('parent_id'),
                'days'=> $this->input->post('days'),
                'fees'=> $this->input->post('fee'),
                'manage_id'=> $this->input->post('manager_id'),
                'teacher_id'=> $this->input->post('teacher_id'),
                'trial_remarks'=> $this->input->post('trial_remarks'),
                'status'=> $this->input->post('status'));
            $add_student = $this->Admin_model->save_student($data);
            if($add_student){
                $teacher_notification = array(
                    'type' => 'Add Student',
                    'content' => 'teeacher notification testing'
                    );

                $parent_notification = array(
                    'type' => 'Add Student',
                    'content' => 'parent notification testing'
                    );
                $manager_notification = array(
                    'type' => 'Add Student',
                    'content' => 'manager notification testing'
                    );
                $this->Admin_model->save_teacher_notification($teacher_notification);
                $this->Admin_model->save_parent_notification($parent_notification);
                echo json_encode(array('success'=>'Student Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_parent()
    { 
        if(isset($_POST) && !empty($_POST)){
            $parent_id = $this->input->post("parent-id");
            $delete_parent = $this->Admin_model->delete_parent($parent_id);
            if($delete_parent){
                echo json_encode(array('success'=>'Parent Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function get_parent()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('parent_id');
            $parent_data = $this->Admin_model->get_parent($id);
            if(! isset($_POST['edit_parent']) && empty($_POST['edit_parent'])){
                $parent_data->manage_id = $this->Admin_model->get_parent_manager($parent_data->manage_id)->name;
                $parent_data->country_id = $this->Admin_model->get_parent_country($parent_data->country_id)->name;
                if($parent_data->invoiced){
                    $parent_data->invoiced = 'Yes';
                }else{
                    $parent_data->invoiced = 'No';
                }
            }
            echo json_encode($parent_data);
        }
    }

    public function get_book()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('book_id');
            $book_data = $this->Admin_model->get_book($id);
            
            echo json_encode($book_data);
        }
    }

    public function add_student()
    {
        if(isset($_POST) && !empty($_POST)){
            $data = array('name'=> $_POST['student-name'],
                'skype'=> $_POST['student-skype'],
                'age'=> $_POST['student-age'],
                'gender'=> $_POST['student-gender'],
                'course_id'=> $_POST['course'],
                'parent_id'=> $_POST['parent_id'],
                'days'=> $_POST['days'],
                'fees'=> $_POST['student-fee'],
                'trial_remarks'=> $_POST['trial-class-remarks'],
                'status'=> $_POST['student-status']);
            $add_student = $this->Admin_model->save_student($data);
            if($add_student){
                $teacher_notification = array(
                    'type' => 'Add Student',
                    'content' => 'teeacher notification testing'
                    );

                $parent_notification = array(
                    'type' => 'Add Student',
                    'content' => 'parent notification testing'
                    );
                $manager_notification = array(
                    'type' => 'Add Student',
                    'content' => 'manager notification testing'
                    );
                $this->Admin_model->save_teacher_notification($teacher_notification);
                $this->Admin_model->save_parent_notification($parent_notification);
                echo json_encode(array('success'=>'Student Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_student()
    { 
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post("student-id");
            $delete_student = $this->Admin_model->delete_student($student_id);
            if($delete_student){
                echo json_encode(array('success'=>'Student Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function delete_book()
    { 
        if(isset($_POST) && !empty($_POST)){
            $book_id = $this->input->post("book-id");
            $delete_book = $this->Admin_model->delete_book($book_id);
            if($delete_book){
                echo json_encode(array('success'=>'Book Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function delete_invoice()
    { 
        if(isset($_POST) && !empty($_POST)){
            $invoice_id = $this->input->post("invoice-id");
            $delete_invoice = $this->Admin_model->delete_invoice($invoice_id);
            if($delete_invoice){
                echo json_encode(array('success'=>'Invoice Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function get_shift()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('shift_id');
            $shift_data = $this->Admin_model->get_shift($id);
            echo json_encode($shift_data);
        }
    }

    public function get_invoice_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('invoice_id');
            $invoice_data = $this->Admin_model->get_invoice_data($id);
            echo json_encode($invoice_data);
        }
    }

    public function invoice_reminder()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('invoice_id');
            $invoice_data = $this->Admin_model->get_invoice_data($id);
            $mailaddress = 'From: Accounts <accounts@learnquraan.co.uk>'; 
            $m =$invoice_data->month;
            $due =$invoice_data->due_date;
            $y =$invoice_data->year;
            $fmail = $this->Admin_model->get_pmail($invoice_data->parent_id)->email;
            $fname = $this->Admin_model->get_student_fname($invoice_data->parent_id);
            if($fname){
                $father_name = $fname->name;
            }else{
                $father_name = '';
            }
            $fee = $invoice_data->amount + $invoice_data->adjustment;
            $subject = 'Reminder Learn Quran Fee Request';
            $message="Assalam-o-Aliakum $father_name!\r\n";
            $message.=" \r\n";
            $message.="This is a reminder for payment from: learnquraan.co.uk. \r\n";
            $message.=" \r\n";
            $message.="Billing Details: \r\n";
            $message.="Month: $m-$y \r\n";
            $message.="Amount: $ $fee.00 \r\n";
            $message.="Due Date: $due \r\n";
            $message.=" \r\n";
            $message.="Once you logged in to your account, you will found your invoice under the 'Invoice(s)'. Kindly follow the 'Pay Now' link to fill your order to checkout. \r\n";
            $message.="Your secure order will be processed by 2Checkout.com, Inc.  \r\n";
            $message.="You will have the option to pay in the currency of your choice during checkout.  \r\n";
            $message.="If the payment link does not work properly, please contact accounts@learnquraan.co.uk  \r\n";
            $message.=" \r\n";
            $message.="We sincerely thank you for choosing us to be your online Quran Learning Institute. \r\n";
            $message.=" \r\n";
            $message.="This is a software generated request. If you already pay your invoice please ignore this email. \r\n";
            $message.="www.learnquraan.co.uk \r\n";
            $message.="E-mail:accounts@learnquraan.co.uk \r\n";
            $message.="Phone: \r\n";
            $message.="US:+1 (031) 0933 3319 \r\n";
            $message.="UK:+44 (020) 8144 4409 \r\n";
            $message.="AU:+61 (02) 8003 5454 \r\n";
            $status = mail($fmail,$subject,$message,"From:".$mailaddress);
            if($status){
                echo json_encode(array('success' => 'Reminder sent Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again Later'));
            }
        }
    }

    public function get_class_detail_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('class_id');
            $class_data = $this->Admin_model->get_class_detail_data($id);
            echo json_encode($class_data);
        }
    }

    public function update_shift()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['shift'] = $_POST['name'];
            $data['s_time'] = $_POST['s_time'];
            $data['e_time'] = $_POST['e_time'];
            $status = $this->Admin_model->update_shift($id,$data);
            if($status){
                echo json_encode(array('success' => 'Shift updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_invoice()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['due_date'] = $this->input->post('due_date');
            $data['adjustment'] = $this->input->post('adjustment');
            $data['status'] = $this->input->post('status');
            $status =$this->Admin_model->update_invoice($id,$data);
            if($status){
                echo json_encode(array('success' => 'Invoice updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_course_book()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['book_name'] = $this->input->post('name');
            $data['course_id'] = $this->input->post('course');
            $status =$this->Admin_model->update_course_book($id,$data);
            if($status){
                echo json_encode(array('success' => 'Book updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    

    public function get_country()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('country_id');
            $country_data = $this->Admin_model->get_country($id);
            echo json_encode($country_data);
        }
    }

    public function update_country()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['name'] = $_POST['name'];
            $data['code'] = $_POST['code'];
            $data['currency'] = $_POST['currency'];
            $status =$this->Admin_model->update_country($id,$data);
            if($status){
                echo json_encode(array('success' => 'Country updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_year()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('year_id');
            $year_data = $this->Admin_model->get_year($id);
            echo json_encode($year_data);
        }
    }

    public function update_year()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['year'] = $_POST['year'];
            $status =$this->Admin_model->update_year($id,$data);
            if($status){
                echo json_encode(array('success' => 'Year updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_student()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('student_id');
            $student_data = $this->Admin_model->get_student($id);
            if(!empty($student_data->course_id)){
                $student_data->coursee_id = $student_data->course_id; 
                $student_data->course_id = $this->Admin_model->get_student_course($student_data->course_id)->name;
            }
            echo json_encode($student_data);
        }
    }

    public function update_student()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['name'] = $this->input->post('name');
            $data['age'] = $this->input->post('age');
            $data['fees'] = $this->input->post('fee');
            $data['days'] = $this->input->post('days');
            $data['gender'] = $this->input->post('gender');
            $data['course_id'] = $this->input->post('course_id');
            $data['skype'] = $this->input->post('skype_id');
            $data['teacher_id'] = $this->input->post('teacher');
            $data['manage_id'] = $this->input->post('manager');
            $data['status'] = $this->input->post('status');
            $data['trial_remarks'] = $_POST['trial_remarks'];
            $status =$this->Admin_model->update_student($id,$data);
            if($status){
                echo json_encode(array('success' => 'Student updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_teacher()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('teacher_id');
            $teacher_data = $this->Admin_model->get_teacher($id);
            echo json_encode($teacher_data);
        }
    }

    public function update_teacher()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['name'] = $_POST['name'];
            $data['father_name'] = $_POST['fname'];
            $data['cnic'] = $_POST['cnic'];
            $data['address'] = $_POST['address'];
            $data['landline'] = $_POST['landline'];
            $data['mobile'] = $_POST['mobile'];
            $data['email'] = $_POST['email'];
            $data['shift_id'] = $_POST['shift'];
            $data['gender'] = $_POST['gender'];
            $data['martial_status'] = $_POST['matstatus'];
            $data['qualification'] = $_POST['qual'];
            $data['experience'] = $_POST['expert'];
            $data['designation'] = $_POST['designation'];
            $data['skype_id'] = $_POST['skype'];
            $data['skype_passwrd'] = $_POST['skype_pass'];
            $data['salary'] = $_POST['salary'];
            $data['user_name'] = $_POST['username'];
            $data['passwrd'] = md5($_POST['pass']);
            $data['inter_remarks'] = $_POST['interremarks'];
            
            $status =$this->Admin_model->update_teacher($id,$data);
       
            if($status){
                echo json_encode(array('success' => 'Teacher updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function add_schedule()
    {  	
    	date_default_timezone_set("Asia/Karachi");
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post("student_id");
            $teacher_id = $this->input->post("teacher_id");
            $days = explode(',',$this->input->post("day"));
            $time = $this->input->post("time");
            foreach($days as $day){
            	$schedule_check = $this->Admin_model->schedule_check($student_id,$teacher_id,$time,$day);
            	if($schedule_check){
                	echo json_encode(array('error'=>'Schedule Already Exist'));
                	return true;
            	}
            	$course_info = $this->Admin_model->get_student_course_id($student_id);
            	//$s_time = new DateTime("@".strtotime($time));
            	$s_time = new DateTime($time);
            	$s_time->setTimezone(new DateTimeZone("UTC"));
            	$data = array('teacher_id'=> $teacher_id,
                	'student_id'=> $student_id,
                	'day'=> $day,
                	'time'=> $s_time->format('h:i A'),
                	'course_id'=> $course_info->course_id
                	);

            	$add_schedule = $this->Admin_model->save_schedule($data);
            }
            if($add_schedule){
                echo json_encode(array('success'=>'Schedule Added successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Please Fill all the fields and Try Again!!'));
        }
    }

    public function delete_schedule()
    { 
        if(isset($_POST) && !empty($_POST)){
            $schedule_id = $this->input->post("schedule-id");
            $delete_schedule = $this->Admin_model->delete_schedule($schedule_id);
            if($delete_schedule){
                echo json_encode(array('success'=>'Schedule Delete successfully'));
            }else{
                echo json_encode(array('error'=>'Something went wrong plz try again'));
            }
        }else{
            echo json_encode(array('error'=>'Error Occured Try Again!!'));
        }
    }

    public function update_parent_status()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            if(!empty($_POST['holiday']) && isset($_POST['holiday']) && $_POST['holiday'] == 'yes'){
                $info['start_date'] = date("Y-m-d", strtotime($this->input->post('start_date')));
                $info['end_date']= date("Y-m-d", strtotime($this->input->post('end_date')));
                $info['parent_id'] = $this->input->post('id');
                $status =$this->Admin_model->save_holiday($info);
            }
            $data['status'] = $this->input->post('status');
            $status =$this->Admin_model->update_parent($id,$data);
            if($status){
                echo json_encode(array('success' => 'Status updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function update_student_status()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $this->input->post('id');
            if(!empty($_POST['holiday']) && isset($_POST['holiday']) && $_POST['holiday'] == 'yes'){
                $info['start_date'] = date("Y-m-d", strtotime($this->input->post('start_date')));
                $info['end_date']= date("Y-m-d", strtotime($this->input->post('end_date')));
                $info['student_id'] = $this->input->post('id');
                $info['parent_id'] = $this->input->post('parent_id');
                $status =$this->Admin_model->save_holiday($info);
            }
            $data['status'] = $this->input->post('status');
            $status =$this->Admin_model->update_student($id,$data);
            if($status){
                echo json_encode(array('success' => 'Status updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function student_holiday_status()
    {	
    	$today = date('Y-m-d');
        $holidays =$this->Admin_model->get_holiday_by_end_date($today);
        foreach ($holidays as $holiday) {
            $id = $holiday['student_id'];
            $data['status'] = 'active';
            $status =$this->Admin_model->update_student($id,$data);
        }

    }

    public function get_all_managers()
    {   
        $all_managers = $this->Admin_model->get_all_managers();
        foreach ($all_managers as $manager) {
            $data[]=array('id' => $manager['id'],'Name' => $manager['name']);
        }
        echo json_encode($data);     
    } 

    public function get_all_teachers()
    {   
        $all_teachers = $this->Admin_model->get_all_teachers();
        foreach ($all_teachers as $teacher) {
            $data[]=array('id' => $teacher['id'],'Name' => $teacher['name']);
        }
        echo json_encode($data);     
    } 

    public function get_all_parents()
    {   
        $all_parents = $this->Admin_model->get_all_parents();
        foreach ($all_parents as $parent) {
            $data[]=array('id' => $parent['id'],'Name' => $parent['name']);
        }
        echo json_encode($data);     
    } 

    public function send_message()
    {   
        if(!empty($_POST['receiver_id']) && isset($_POST['receiver_id'])){
            $info['receiver_id'] = $this->input->post('receiver_id');
            $info['sender_id'] = 007;
            $info['sender_title'] = 'admin';
            $info['receiver_title']= $this->input->post('send_to');
            $info['message'] = $this->input->post('message');
            $info['status'] = 0;
            $status =$this->Admin_model->save_message($info);
            if($status){
                echo json_encode(array('success' => 'Message sent Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }     
    } 

    public function get_all_chapters()
    {   
        $book_id= $this->input->post('book_id');
        $course_id = $this->input->post('course_id');
        $all_chaps = $this->Admin_model->get_all_chapters($book_id,$course_id);
        $data = array(); 
        foreach ($all_chaps as $chap) {
            $data[]=array('id' => $chap['id'],'Name' => $chap['chapter_name']);
        }
        echo json_encode($data);     
    } 

    public function get_course_books()
    {   
        $course_id = $this->input->post('course_id');
        $all_chaps = $this->Admin_model->get_selected_books($course_id);
        $data = array(); 
        foreach ($all_chaps as $chap) {
            $data[]=array('id' => $chap['id'],'Name' => $chap['book_name']);
        }
        echo json_encode($data);     
    } 

    public function get_detail_student_schedule()
    {   
        $student_id = $this->input->post('student_id');
        $detail_schedule = $this->Admin_model->get_detail_student_schedule($student_id);
        $data = array(); 
        $i = 0;
        foreach ($detail_schedule as $schedule) {
            $s_time = new DateTime("@".strtotime($schedule['time']));
            $s_time->setTimezone(new DateTimeZone("Asia/Karachi"));
            //echo $s_time->format('H:i A');
            $detail_schedule[$i]['time'] = $s_time->format('H:i A');
            $i++;
        }
        echo json_encode($detail_schedule);     
    } 

    public function get_chap_page_num()
    {   
        $chap_id = $this->input->post('chap_id');
        $all_chaps = $this->Admin_model->get_chap_page_num($chap_id);
        if(count($all_chaps) > 0 ) {
            $data=array('page' => $all_chaps[0]['page_no']);
            echo json_encode(array('page' => $all_chaps[0]['page_no']));
        }else{
            $data=array('page' => 1);
            echo json_encode(array('page' => 1));
        }
    } 

    public function upload_chap_page()
    {   
        $pages = 0;
        $data = array();
        if($_FILES['chap-page-img'] && !empty($_FILES['chap-page-img']['name'])){
            $filesCount = count($_FILES['chap-page-img']['name']);
            for($i = 0 ; $i < $filesCount ; $i++){
                $_FILES['chap-page']['name'] = $_FILES['chap-page-img']['name'][$i];
                $_FILES['chap-page']['type'] = $_FILES['chap-page-img']['type'][$i];
                $_FILES['chap-page']['tmp_name'] = $_FILES['chap-page-img']['tmp_name'][$i];
                $_FILES['chap-page']['error'] = $_FILES['chap-page-img']['error'][$i];
                $_FILES['chap-page']['size'] = $_FILES['chap-page-img']['size'][$i];


                $configUpload['upload_path']    = '../uploads/chap/pages/';                 #the folder placed in the root of project
                $configUpload['allowed_types']  = 'gif|jpg|png|bmp|jpeg';       #allowed types description
                $configUpload['max_size']       = '0';                          #max size
                $configUpload['max_width']      = '0';                          #max width
                $configUpload['max_height']     = '0';                          #max height
                $configUpload['encrypt_name']   = true;                         #encrypt name of the uploaded file
                $this->load->library('upload', $configUpload);
                $this->upload->initialize($configUpload);
                if($this->upload->do_upload('chap-page')){
                    $fileData = $this->upload->data();
                    $uploadData[$i]['file_name'] = $fileData['file_name'];
                    $data['chapter_id'] = $this->input->post('chapter-book-name');
                    $data['page_no'] = $_POST['chap-page-num'][$i];
                    $data['image'] = $fileData['file_name'];
                    $add_page = $this->Admin_model->save_chap_page($data);
                    if($add_page){
                        $pages++;
                    }
                }
            }
        }
        $msg = array('success' => $pages." uploaded Successfully" ); 
        echo json_encode($msg);
    } 

    public function send_mail()
    {   
        // the message
        $msg = "First line of text\nSecond line of text";

        // use wordwrap() if lines are longer than 70 characters
        $msg = wordwrap($msg,70);

        // send email
        $check = mail("engrumair_sabir@yahoos.com","My subject",$msg);    
        if($check){
            echo "sent successfully";
        }else{
            echo "not sent successfully";
        }
    } 

}
