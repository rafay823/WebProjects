<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


    function __construct()
    {
        parent::__construct();
        $this->load->model('Teacher_model');
    }

	public function index()
	{

		$this->load->view('teacher/login');
	}


	public function panel()
	{

		$this->load->view('teacher/dashboard');
	}

	public function login()
    { 
        if(isset($_POST) && !empty($_POST)){
            $username = $this->input->post("username");
            $password = md5($this->input->post("pwd"));
            if($this->Teacher_model->check_login($username,$password)){
                $teacher_info = $this->Teacher_model->check_login($username,$password);
                $session_data = array(
                    'username' => $teacher_info->name,
                    'teacher_id' => $teacher_info->id
                );
                $this->session->set_userdata('teacher_logged_in', $session_data);
                echo json_encode(array('success'=>'login successfully'));

            }else{
                echo json_encode(array('error'=>'username or password incorrect'));
            }
        }else{
            echo json_encode(array('error'=>'Something went wrong plz try again'));

        }
    }

    public function logout()
    {
        $sess_array = array('username'=> '');
        $this->session->unset_userdata('teacher_logged_in', $sess_array);
        echo json_encode(array('success'=>'logout successfully'));
    }

    public function today_classes()
    {   $data = array();
        $day = date('l');
        $date = date("Y-m-d");
        $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
        $today_classses = $this->Teacher_model->get_today_classes($day , $date , $teacher_id);
        foreach ($today_classses as $class) {
            $class_id = $class['id'];
            $course = $this->Teacher_model->get_student_course($class['course_id']);
            $teacher = $this->Teacher_model->get_student_teacher($class['Teacher_id']);
            $student = $this->Teacher_model->get_student_name($class['student_id']);
            if($class['status'] == 'Taken' || $class['status'] == 'Teacher Leave' || $class['status'] == 'Student Leave'){
                $action = '';
            }elseif ($class['status'] == 'Started') {
                $action = '<button id="class-pause" data-id="'.$class_id.'" class="btn btn-info btn-sm">Pause</button>&nbsp;&nbsp;<button id="class-end" class="btn btn-danger btn-sm demo4" data-toggle="modal" data-target="#class_remarks" data-id="'.$class_id.'">End</button>';
            }elseif($class['status'] == 'Waiting'){
                $action = '<button id="class-resume" data-id="'.$class_id.'" class="btn btn-info btn-sm">Resume</button>&nbsp;&nbsp;<button id="class-end" class="btn btn-danger btn-sm demo4" data-toggle="modal" data-target="#class_remarks" data-id="'.$class_id.'">End</button>';
            }else{
                $action = '<button id="class-start" data-id="'.$class_id.'" data-student="'.$class['student_id'].'" data-teacher="'.$class['Teacher_id'].'" data-backdrop="static" data-keyboard="false" data-target="#lesson_details" data-toggle="modal" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button id="student-leave" class="btn btn-danger btn-sm demo4" data-id="'.$class_id.'">S-L</button>';
            }
            $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student->name,'Course' => $course->name,'History' =>  '<a data-toggle="modal" data-target="#student_class_history" data-id="'.$class['student_id'].'">History</a>','Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status'],'Actions' => $action);
        }
        $data = array(
                    "recordsTotal" => count($data),
                    "recordsFiltered" => count($data),
                    'data' =>$data);
        echo json_encode($data);     
    }

    public function get_teacher_schedule()
    {   
        date_default_timezone_set("UTC");
        $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
        $data = $this->Teacher_model->get_teacher_schedule($teacher_id);
        $i = 0;
        foreach ($data as $key => $value) {
            if(!empty($value)){
                $time = new DateTime("@".strtotime($value['time']));
                $time->setTimezone(new DateTimeZone('Asia/Karachi'));
                $data[$i]['time'] = $time->format('g:i A');
            } 
            $i++;   
        }
        echo json_encode($data); 
    }

    public function get_teacher()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('teacher_id');
            $teacher_data = $this->Teacher_model->get_teacher($id);
            echo json_encode($teacher_data);
        }
    }

    public function get_lesson_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $student_id = $this->input->post('student-id');
            $teacher_id = $this->session->userdata['teacher_logged_in']['teacher_id'];
            $lesson_data = $this->Teacher_model->get_teacher_lesson_data($teacher_id,$student_id);
            if($lesson_data){
                echo json_encode($lesson_data[0]);
            }
        }    
    }

    public function classes_history()
    {   $data = array();
        if(isset($_GET) && !empty($_GET)){
            $student_id = $_GET['student_id'];
            $all_classses = $this->Teacher_model->get_all_classes_filters($student_id);    
            foreach ($all_classses as $class) {
                $class_id = $class['id'];
                $course = $this->Teacher_model->get_student_course($class['course_id']);
                if($course){
                    $course_name = $course->name;
                }else{
                    $course_name = ''; 
                }
                $teacher = $this->Teacher_model->get_student_teacher($class['Teacher_id']);
                if($teacher){
                    $teacher_name = $teacher->name;
                }else{
                    $teacher_name = '';
                }
                $student = $this->Teacher_model->get_student_name($class['student_id']);
                if($student){
                    $student_name = $student->name;
                }else{
                    $student_name = '';
                }
                if($class['status'] == 'Taken'){
                    $action = '<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }elseif ($class['status'] == 'Started') {
                     $action = '<button id="class-end" data-id="'.$class_id.'" data-toggle="modal" data-target="#class_remarks" class="btn btn-info btn-sm">End</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }else{
                    $action = '<button id="class-start" data-id="'.$class_id.'" class="btn btn-info btn-sm">Start</button>&nbsp;&nbsp;<button class="btn btn-danger btn-sm demo4 class-validate" data-id="'.$class_id.'">V</button>';
                }
                $data[]=array('Date' => date("d-m-Y", strtotime($class['date'])),'Class Time' => $class['class_time'],'Student' => $student_name.'<span id="d_h_v" data-id="'.$class_id.'" data-toggle="modal" data-target="#view_class_remarks" class="label label-success pull-right">D</span>','Teacher' => $teacher_name,'Course' => $course_name,'Start Time' => $class['start_time'],'End Time' => $class['end_time'],'Duration' => $class['duration'],'Status' => $class['status']
                    );
            }
            $data = array(
                        "recordsTotal" => count($data),
                        "recordsFiltered" => count($data),
                        'data' =>$data);
            echo json_encode($data); 
        }
    }

    public function start_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['start_time'] = $this->input->post('start_time');
            $data['status'] = 'Started';
            $status =$this->Teacher_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function get_class_detail_data()
    {
        if(isset($_POST) && !empty($_POST)){
            $id = $this->input->post('class_id');
            $class_data = $this->Teacher_model->get_class_detail_data($id);
            echo json_encode($class_data);
        }
    }

    public function get_chapters()
    {
        if(!empty($_POST['book-id']) && isset($_POST['book-id'])){
            $id = $_POST['book-id'];
            $chapters =$this->Teacher_model->get_book_chaps($id);
            echo json_encode($chapters);
        }
    }

    public function get_pages()
    {
        if(!empty($_POST['chap-id']) && isset($_POST['chap-id'])){
            $id = $_POST['chap-id'];
            $pages =$this->Teacher_model->get_chap_pages($id);
            echo json_encode($pages);
        }
    }

    public function update_teacher()
    {
        if(!empty($_POST['id']) && isset($_POST['id'])){
            $id = $_POST['id'];
            $data['name'] = $_POST['name'];
            $data['father_name'] = $_POST['fname'];
            $data['cnic'] = $_POST['cnic'];
            $data['address'] = $_POST['address'];
            $data['landline'] = $_POST['landline'];
            $data['mobile'] = $_POST['mobile'];
            $data['email'] = $_POST['email'];
            $data['qualification'] = $_POST['qual'];
            $data['experience'] = $_POST['expert'];
            $status =$this->Teacher_model->update_teacher($id,$data);
       
            if($status){
                echo json_encode(array('success' => 'Profile updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }


    public function pause_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['status'] = 'Waiting';
            $status =$this->Teacher_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function resume_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['status'] = 'Started';
            $status =$this->Teacher_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function end_class()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $_POST['class-id'];
            $data['end_time'] = $this->input->post('end_time');
            $data['status'] = 'Taken';
            $status =$this->Teacher_model->update_class($id,$data);
            if($status){
                $calc_duration =$this->Teacher_model->get_class_times($id);
                $start_time = $calc_duration->start_time;
                $end_time = $calc_duration->end_time;
                $Duration = strtotime($end_time) - strtotime($start_time);
                $hour = $Duration / 3600 % 24;
                $minute = $Duration / 60 % 60;    
                $second = $Duration % 60;
                $Duration = $hour.':'.$minute.':'.$second;
                $info['duration'] = $Duration;
                $this->Teacher_model->update_class($id,$info);
                echo json_encode(array('duration' => $Duration));
                //echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function student_notes()
    {
        if(!empty($_POST['student-id']) && isset($_POST['student-id'])){
            $data['student_id'] = $this->input->post('student-id');
            $data['notes'] = $this->input->post('student-notes');
            $status =$this->Teacher_model->insert_notes($data);
            if($status){
                echo json_encode(array('success' => 'Notes Added Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function current_lesson()
    {
        if(!empty($_POST['student-id']) && isset($_POST['student-id'])){
            $data['student_id'] = $this->input->post('student-id');
            $data['teacher_id'] = $this->input->post('teacher-id');
            $data['book_id'] = $this->input->post('book-id');
            $data['chapter_id'] = $this->input->post('chap-id');
            $data['page_id'] = $this->input->post('page-id');
            $status =$this->Teacher_model->save_current_history($data);
            if($status){
                echo json_encode(array('success' => 'History saved Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }

    public function set_leave()
    {
        if(!empty($_POST['class-id']) && isset($_POST['class-id'])){
            $id = $this->input->post('class-id');
            $data['status'] = 'Student Leave Approval';
            $status =$this->Teacher_model->update_class($id,$data);
            if($status){
                echo json_encode(array('success' => 'Class updated Successfully'));
            }
            else{
                echo json_encode(array('error' => 'Something went wrong please try again'));
            }
        }else{
            echo json_encode(array('error' => 'Something went wrong please try again'));
        }
    }
    

   
}
